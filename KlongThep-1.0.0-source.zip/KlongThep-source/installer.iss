; Inno Setup 6 script for KlongThep  (built by tools/build_exe.py, or run ISCC manually)
;   ISCC /DMyAppVersion=1.0.0 /DSourceDir=dist\KlongThep /DOutputDir=dist installer.iss
;
; Installs per-user into %LOCALAPPDATA%\Programs\KlongThep so that the data\ folder
; (database, crops, rendered videos) stays writable without admin rights.

#ifndef MyAppVersion
  #define MyAppVersion "1.0.0"
#endif
#ifndef SourceDir
  #define SourceDir "dist\KlongThep"
#endif
#ifndef OutputDir
  #define OutputDir "dist"
#endif
#define MyAppName "KlongThep"
#define MyAppExe "KlongThep.exe"

[Setup]
AppId={{0AB09202-E924-4072-B4CD-FF4D49525F73}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher=KlongThep
DefaultDirName={localappdata}\Programs\{#MyAppName}
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
DisableProgramGroupPage=yes
OutputDir={#OutputDir}
OutputBaseFilename={#MyAppName}-{#MyAppVersion}-setup
Compression=lzma2/fast
SolidCompression=no
LZMAUseSeparateProcess=yes
DiskSpanning=no
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExe}
WizardStyle=modern
SetupIconFile={#SourceDir}\_internal\app\web\icon.ico
LicenseFile={#SourceDir}\THIRD_PARTY.md

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
; Everything from the PyInstaller output. data\ is excluded so an upgrade never touches
; the user's database; it is created empty on first run.
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "data\*"
; config.yaml: keep the user's edited copy on upgrade
Source: "{#SourceDir}\config.yaml"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall

[Dirs]
Name: "{app}\data"; Flags: uninsneveruninstall

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"
Name: "{group}\{#MyAppName} (command line)"; Filename: "{app}\klongthep-cli.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Leave data\ alone on purpose: it holds the station's evidence database.
Type: filesandordirs; Name: "{app}\_internal"
