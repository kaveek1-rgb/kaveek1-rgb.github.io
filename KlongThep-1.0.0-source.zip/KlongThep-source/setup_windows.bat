@echo off
REM ============================================================
REM  KlongThep installer launcher.
REM  IMPORTANT: keep this file ASCII-only. Windows cmd.exe
REM  mis-parses .bat files that contain Thai characters.
REM  All Thai text lives in tools\setup.py instead.
REM ============================================================
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title KlongThep Setup

set "PY=python"
python --version >nul 2>nul
if errorlevel 1 set "PY=py"
%PY% --version >nul 2>nul
if errorlevel 1 goto NOPYTHON

%PY% "tools\setup.py"
echo.
pause
exit /b 0

:NOPYTHON
echo.
echo [ERROR] Python was not found on this computer.
echo.
echo   1. Download Python 3.10 or newer from python.org/downloads
echo   2. During the install, TICK the box: Add python.exe to PATH
echo   3. Close this window, then run setup_windows.bat again
echo.
pause
exit /b 1
