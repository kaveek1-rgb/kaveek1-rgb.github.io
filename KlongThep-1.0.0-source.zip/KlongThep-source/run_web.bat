@echo off
REM ASCII-only on purpose. See the note in setup_windows.bat.
REM Browser mode: opens KlongThep in your default web browser (old behaviour).
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title KlongThep (web)

if not exist ".venv\Scripts\python.exe" goto NOTSETUP
".venv\Scripts\python.exe" cli.py serve
echo.
pause
exit /b 0

:NOTSETUP
echo.
echo Not installed yet.
echo Please double-click  setup_windows.bat  first.
echo.
pause
exit /b 1
