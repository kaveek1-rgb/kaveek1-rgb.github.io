# -*- mode: python ; coding: utf-8 -*-
"""สูตรสร้างโปรแกรม .exe ด้วย PyInstaller  (รันผ่าน build_exe.bat หรือ tools/build_exe.py)

ผลลัพธ์อยู่ใน dist/KlongThep/
  KlongThep.exe        หน้าต่างโปรแกรม (ดับเบิลคลิกใช้งาน) ไม่มีจอดำ
  klongthep-cli.exe    ตัวคอนโซล ใช้สั่งงานจาก command line / ประมวลผลเบื้องหลัง
  _internal/           ไลบรารีทั้งหมด (torch, ultralytics, opencv, ...)
  config.yaml models/  อยู่ข้าง .exe แก้ไข/เปลี่ยนโมเดลได้โดยไม่ต้องสร้างใหม่

ของที่ต้องอยู่ "ข้าง" exe (แก้ได้) กับของที่ "ฝัง" ใน _internal (โค้ด/หน้าเว็บ) แยกกันชัด:
  config.PKG  -> _internal  (app/web, app/trackers)
  config.ROOT -> โฟลเดอร์ที่มี exe (config.yaml, models, data, ffmpeg)
"""
import os
import sys
from pathlib import Path

from PyInstaller.utils.hooks import collect_all, collect_submodules, collect_data_files

HERE = Path(os.path.abspath(SPECPATH))
sys.path.insert(0, str(HERE))
from app.version import __version__, APP_NAME  # noqa: E402

block_cipher = None

# โค้ดของกล้องเทพเอง (app/, cli.py) ไม่ถูกอัดเข้า .exe แต่วางเป็นไฟล์ธรรมดาใน _internal/
# เพื่อให้ตัวอัปเดตเปลี่ยนได้โดยไม่ต้องสร้าง .exe ใหม่ (ดู app/updater.py)
datas = [
    (str(HERE / "cli.py"), "."),
]
binaries = []
hiddenimports = [
    "webbrowser", "sqlite3", "winreg",
    "uvicorn.logging", "uvicorn.loops", "uvicorn.loops.auto", "uvicorn.loops.asyncio",
    "uvicorn.protocols", "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl", "uvicorn.protocols.http.httptools_impl",
    "uvicorn.protocols.websockets", "uvicorn.protocols.websockets.auto",
    "uvicorn.lifespan", "uvicorn.lifespan.on", "uvicorn.lifespan.off",
    "multipart", "python_multipart",
    "app.desktop", "app.ingest", "app.synopsis", "app.search", "app.stitch", "app.riders",
    "app.paths", "app.gate", "app.guard", "app.dataset", "app.maintain", "app.stats",
    "app.detect", "app.media", "app.version",
]

# แพ็กเกจที่มีไฟล์ข้อมูล/ไลบรารีเสริมเยอะ ต้องเก็บมาให้ครบ ไม่งั้นพังตอนรัน
for pkg in ("ultralytics", "webview", "lap", "cv2"):
    try:
        d, b, h = collect_all(pkg)
        datas += d
        binaries += b
        hiddenimports += h
    except Exception as exc:  # noqa: BLE001
        print(f"[spec] ข้าม {pkg}: {exc}")

# torch/torchvision มี hook ของ PyInstaller อยู่แล้ว แต่โมดูลย่อยบางตัวถูกเรียกแบบ dynamic
for pkg in ("torch", "torchvision"):
    try:
        hiddenimports += collect_submodules(pkg)
    except Exception as exc:  # noqa: BLE001
        print(f"[spec] ข้าม submodules {pkg}: {exc}")

a = Analysis(
    [str(HERE / "launcher.py")],
    pathex=[str(HERE)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # ของที่ไม่ได้ใช้ แต่ torch/ultralytics ลากมา ทำให้ชุดโปรแกรมบวมโดยเปล่าประโยชน์
        "tkinter", "matplotlib", "IPython", "jupyter", "notebook", "pytest",
        "tensorboard", "wandb", "mlflow", "comet_ml", "clearml", "neptune",
        "onnx", "onnxruntime", "openvino", "tensorflow", "tensorrt", "coremltools", "paddle",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
# ถอดโมดูล app.* และ cli ออกจากตัวที่อัดรวม (วิเคราะห์ dependency ไปแล้ว จึงยังได้ไลบรารีครบ)
a.pure = [m for m in a.pure if not (m[0] == "app" or m[0].startswith("app.") or m[0] == "cli")]
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)
app_tree = Tree(str(HERE / "app"), prefix="app", excludes=["__pycache__", "*.pyc"])

icon = str(HERE / "app" / "web" / "icon.ico")
if not os.path.exists(icon):
    icon = None

exe_gui = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name=APP_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,              # หน้าต่างโปรแกรม ไม่มีจอดำ
    disable_windowed_traceback=False,
    icon=icon,
    version=str(HERE / "build" / "version_info.txt") if (HERE / "build" / "version_info.txt").exists() else None,
)

exe_cli = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="klongthep-cli",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,               # ตัวคอนโซล ไว้สั่งงานและดูล็อกสด ๆ
    icon=icon,
)

coll = COLLECT(
    exe_gui,
    exe_cli,
    a.binaries,
    a.zipfiles,
    a.datas,
    app_tree,
    strip=False,
    upx=False,
    name=APP_NAME,
)
