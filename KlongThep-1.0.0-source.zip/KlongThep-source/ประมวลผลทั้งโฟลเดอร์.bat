@echo off
REM ASCII-only on purpose. See the note in setup_windows.bat.
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title KlongThep - batch ingest

if not exist ".venv\Scripts\python.exe" goto NOTSETUP

echo ============================================================
echo   Batch ingest: process every video in one folder.
echo   This takes a long time - you can leave it running overnight.
echo ============================================================
echo.
set "FOLDER="
set /p FOLDER=Drag the video folder here, then press Enter: 
if not defined FOLDER goto NOFOLDER
set FOLDER=%FOLDER:"=%

".venv\Scripts\python.exe" cli.py ingest-dir "%FOLDER%"
echo.
echo Finished. Open run.bat to search and build synopsis videos.
pause
exit /b 0

:NOFOLDER
echo No folder was given.
pause
exit /b 1

:NOTSETUP
echo Not installed yet. Please run setup_windows.bat first.
pause
exit /b 1
