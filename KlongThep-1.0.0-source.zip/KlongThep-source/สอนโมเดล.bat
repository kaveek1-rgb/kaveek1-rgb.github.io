@echo off
REM ASCII-only on purpose. See the note in setup_windows.bat.
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title KlongThep - train custom model

if not exist ".venv\Scripts\python.exe" goto NOTSETUP
".venv\Scripts\python.exe" "tools\train.py" %*
echo.
pause
exit /b 0

:NOTSETUP
echo Not installed yet. Please run setup_windows.bat first.
pause
exit /b 1
