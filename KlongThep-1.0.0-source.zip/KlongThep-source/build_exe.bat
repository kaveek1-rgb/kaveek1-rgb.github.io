@echo off
REM ASCII-only on purpose. See the note in setup_windows.bat.
REM Builds the distributable KlongThep.exe package into dist\ (see tools\build_exe.py).
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title KlongThep Build

if not exist ".venv\Scripts\python.exe" goto NOTSETUP
".venv\Scripts\python.exe" "tools\build_exe.py"
echo.
pause
exit /b 0

:NOTSETUP
echo.
echo Not installed yet.
echo Please double-click  setup_windows.bat  first.
echo.
pause
exit /b 1
