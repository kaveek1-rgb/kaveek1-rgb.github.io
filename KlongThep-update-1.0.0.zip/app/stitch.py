"""ต่อร่องรอยที่ขาดให้เป็นเส้นเดียว

ตัวติดตามวัตถุ (ByteTrack) จะ "ทำหลุด" เป็นระยะ เช่นตอนวัตถุถูกเสาบัง
ตอนแสงเปลี่ยน หรือตอนอยู่ไกลจนโมเดลตรวจไม่เจอสองสามเฟรม พอกลับมาเจออีกที
มันถือว่าเป็นวัตถุตัวใหม่ ผลคือคนเดินข้ามถนนหนึ่งคนถูกบันทึกเป็น 3-4 รายการสั้น ๆ
เวลาเอาไปทำวิดีโอย่อจึงเห็นแค่ช่วงกลาง ไม่เห็นตอนเดินเข้ามาและตอนเดินออกไป

ตัวนี้เอาชิ้นส่วนที่ "เกือบแน่ว่าเป็นตัวเดียวกัน" มาต่อกลับเป็นเส้นเดียว
โดยดูจากการทำนายตำแหน่ง: ถ้าชิ้นก่อนหน้าเคลื่อนที่ด้วยความเร็วเท่านี้
พอเวลาผ่านไปเท่านี้ มันควรไปโผล่ตรงไหน ถ้าชิ้นถัดไปเริ่มตรงนั้นพอดี
และขนาดกับประเภทตรงกัน ก็ถือว่าเป็นตัวเดียวกัน

ทำงานกับข้อมูลที่วิเคราะห์ไว้แล้ว ไม่ต้องเปิดไฟล์วิดีโอใหม่
"""
from __future__ import annotations

import math
import os
from collections import defaultdict

import numpy as np

from . import db, tubestore

MAX_GAP_SEC = 2.5        # ห่างกันเกินนี้ไม่ต่อ เสี่ยงต่อผิดตัว
MIN_TOL_PX = 24.0        # ความคลาดเคลื่อนขั้นต่ำที่ยอมรับได้
SIZE_LO, SIZE_HI = 0.45, 2.2     # ขนาดต้องใกล้เคียงกัน
ANGLE_MAX = 70.0         # องศาที่ทิศทางเบี่ยงได้


def _tol(a: dict, gap: float) -> float:
    """ยิ่งวัตถุใหญ่และยิ่งขาดช่วงนาน ยิ่งต้องยอมให้คลาดเคลื่อนมากขึ้น"""
    return max(MIN_TOL_PX, 1.3 * float(a["h_avg"] or 10) + 0.45 * float(a["speed_px"] or 0) * gap)


def _angle_ok(vx: float, vy: float, dx: float, dy: float) -> bool:
    na = math.hypot(vx, vy)
    nb = math.hypot(dx, dy)
    if na < 1e-3 or nb < 1e-3:
        return True                      # ตัวที่แทบไม่ขยับ ไม่ต้องเช็คทิศ
    cos = (vx * dx + vy * dy) / (na * nb)
    return cos >= math.cos(math.radians(ANGLE_MAX))


def _cost(a: dict, b: dict) -> float | None:
    """คืนค่าความน่าจะเป็นตัวเดียวกัน (ยิ่งน้อยยิ่งใช่) หรือ None ถ้าไม่เข้าเกณฑ์"""
    if a["cls"] != b["cls"]:
        return None
    gap = float(b["start_sec"]) - float(a["end_sec"])
    if gap <= 0 or gap > MAX_GAP_SEC:
        return None

    ha, hb = float(a["h_avg"] or 1), float(b["h_avg"] or 1)
    ratio = hb / max(ha, 1e-6)
    if not (SIZE_LO <= ratio <= SIZE_HI):
        return None

    # ทำนายว่าชิ้นแรกน่าจะไปอยู่ตรงไหนเมื่อเวลาผ่านไป gap วินาที
    dur = max(1e-3, float(a["end_sec"]) - float(a["start_sec"]))
    vx = (float(a["cx_end"]) - float(a["cx_start"])) / dur
    vy = (float(a["cy_end"]) - float(a["cy_start"])) / dur
    px = float(a["cx_end"]) + vx * gap
    py = float(a["cy_end"]) + vy * gap
    d = math.hypot(float(b["cx_start"]) - px, float(b["cy_start"]) - py)
    tol = _tol(a, gap)
    if d > tol:
        return None

    if not _angle_ok(vx, vy,
                     float(b["cx_start"]) - float(a["cx_end"]),
                     float(b["cy_start"]) - float(a["cy_end"])):
        return None
    return d / tol + 0.25 * (gap / MAX_GAP_SEC)


def _merge_files(keep: dict, drop: list[dict]) -> None:
    """รวมไฟล์ข้อมูลราย tube เข้าด้วยกัน เรียงตามเวลา

    อ่านไบต์ของภาพออกมาตรง ๆ ไม่ถอดรหัสแล้วเข้ารหัสใหม่
    จะได้ไม่เสียคุณภาพและเร็วกว่ามาก
    """
    paths = [keep.get("data_path")] + [d.get("data_path") for d in drop]
    paths = [p for p in paths if p and os.path.exists(p)]
    if len(paths) < 2:
        return
    frames, secs, boxes, pats, msks = [], [], [], [], []
    for p in paths:
        try:
            z = np.load(p)
        except Exception:  # noqa: BLE001
            continue
        try:
            f, s, b = z["frames"], z["secs"], z["boxes"]
            pbuf, poff = z["pbuf"], z["poff"]
            mbuf, moff = z["mbuf"], z["moff"]
            for i in range(len(f)):
                frames.append(int(f[i]))
                secs.append(float(s[i]))
                boxes.append(b[i])
                pats.append(pbuf[int(poff[i]):int(poff[i + 1])].tobytes())
                msks.append(mbuf[int(moff[i]):int(moff[i + 1])].tobytes())
        finally:
            z.close()
    if not frames:
        return
    order = np.argsort(np.asarray(frames), kind="stable")
    tubestore.save(keep["data_path"],
                   [frames[i] for i in order], [secs[i] for i in order],
                   [boxes[i] for i in order],
                   [pats[i] for i in order], [msks[i] for i in order])
    for p in paths[1:]:
        try:
            os.remove(p)
        except OSError:
            pass


def stitch(video_id: int, con=None) -> dict:
    own = con is None
    con = con or db.connect()
    try:
        rows = [dict(r) for r in con.execute(
            "SELECT * FROM tubes WHERE video_id=? ORDER BY start_sec, id", (int(video_id),))]
        if len(rows) < 2:
            return {"video_id": int(video_id), "before": len(rows), "after": len(rows), "merged": 0}
        by_id = {int(r["id"]): r for r in rows}

        # จับคู่ ชิ้นก่อน -> ชิ้นถัดไป แบบตัวต่อตัว เลือกคู่ที่ค่าใช้จ่ายต่ำสุดก่อน
        cands = []
        for i, a in enumerate(rows):
            for b in rows[i + 1:]:
                if float(b["start_sec"]) - float(a["end_sec"]) > MAX_GAP_SEC:
                    break                 # เรียงตามเวลาแล้ว ตัวถัด ๆ ไปยิ่งห่าง
                c = _cost(a, b)
                if c is not None:
                    cands.append((c, int(a["id"]), int(b["id"])))
        cands.sort()

        nxt: dict[int, int] = {}
        prv: dict[int, int] = {}
        for c, ai, bi in cands:
            if ai in nxt or bi in prv:
                continue
            nxt[ai] = bi
            prv[bi] = ai

        # ร้อยเป็นสาย
        chains = []
        for r in rows:
            i = int(r["id"])
            if i in prv:
                continue
            chain = [i]
            while chain[-1] in nxt:
                chain.append(nxt[chain[-1]])
            if len(chain) > 1:
                chains.append(chain)

        merged = 0
        for chain in chains:
            keep = by_id[chain[0]]
            drop = [by_id[i] for i in chain[1:]]
            _merge_files(keep, drop)

            ids = [int(i) for i in chain]
            pts = con.execute(
                "SELECT cx, cy, x1, y1, x2, y2, sec FROM tube_points WHERE tube_id IN (%s)"
                " ORDER BY sec" % ",".join("?" * len(ids)), ids).fetchall()
            if not pts:
                continue
            cx = np.array([p["cx"] for p in pts], float)
            cy = np.array([p["cy"] for p in pts], float)
            hs = np.array([p["y2"] - p["y1"] for p in pts], float)
            ws = np.array([p["x2"] - p["x1"] for p in pts], float)
            dist = float(np.sum(np.hypot(np.diff(cx), np.diff(cy)))) if len(pts) > 1 else 0.0
            s0, s1 = float(pts[0]["sec"]), float(pts[-1]["sec"])
            dur = max(s1 - s0, 1e-3)
            ang = math.degrees(math.atan2(cy[-1] - cy[0], cx[-1] - cx[0])) % 360.0
            con.execute(
                "UPDATE tubes SET start_sec=?, end_sec=?, duration=?, n_frames=?,"
                " start_frame=(SELECT MIN(frame) FROM tube_points WHERE tube_id IN (%s)),"
                " end_frame=(SELECT MAX(frame) FROM tube_points WHERE tube_id IN (%s)),"
                " x1=?, y1=?, x2=?, y2=?, area_avg=?, h_avg=?,"
                " cx_start=?, cy_start=?, cx_end=?, cy_end=?, dir_deg=?, dist_px=?, speed_px=?"
                " WHERE id=?" % (",".join("?" * len(ids)), ",".join("?" * len(ids))),
                (s0, s1, dur, len(pts), *ids, *ids,
                 int(min(p["x1"] for p in pts)), int(min(p["y1"] for p in pts)),
                 int(max(p["x2"] for p in pts)), int(max(p["y2"] for p in pts)),
                 float(np.mean(ws * hs)), float(np.mean(hs)),
                 float(cx[0]), float(cy[0]), float(cx[-1]), float(cy[-1]),
                 ang, dist, dist / dur, keep["id"]))
            con.execute("UPDATE tube_points SET tube_id=? WHERE tube_id IN (%s)"
                        % ",".join("?" * len(drop)),
                        [keep["id"]] + [int(d["id"]) for d in drop])
            for d in drop:
                cp = d.get("crop_path")
                if cp and os.path.exists(cp):
                    try:
                        os.remove(cp)
                    except OSError:
                        pass
            con.execute("DELETE FROM tubes WHERE id IN (%s)" % ",".join("?" * len(drop)),
                        [int(d["id"]) for d in drop])
            merged += len(drop)

        con.execute("UPDATE videos SET n_tubes=(SELECT COUNT(*) FROM tubes WHERE video_id=?)"
                    " WHERE id=?", (int(video_id), int(video_id)))
        con.commit()
        after = con.execute("SELECT COUNT(*) FROM tubes WHERE video_id=?",
                            (int(video_id),)).fetchone()[0]
        return {"video_id": int(video_id), "before": len(rows), "after": int(after),
                "merged": merged, "chains": len(chains)}
    finally:
        if own:
            con.close()


def stitch_all() -> list[dict]:
    con = db.connect()
    try:
        vids = [int(r["id"]) for r in con.execute(
            "SELECT id FROM videos WHERE status='done' ORDER BY id")]
    finally:
        con.close()
    return [stitch(v) for v in vids]
