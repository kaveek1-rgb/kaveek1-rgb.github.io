"""งานดูแลข้อมูล - ลบวิดีโอ, ลบข้อมูลเก่าตามอายุ, สำรองฐานข้อมูล

แยกออกมาเป็นโมดูลของตัวเอง เพราะทั้งหน้าเว็บและคำสั่งบรรทัดคำสั่งใช้ร่วมกัน
"""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

from . import config, db


# ------------------------------------------------------------ ลบวิดีโอ
def video_files(con: sqlite3.Connection, video_id: int) -> list[str]:
    """ไฟล์ทั้งหมดที่ระบบสร้างขึ้นจากวิดีโอนี้ (ไม่รวมไฟล์วิดีโอต้นฉบับ)"""
    files: list[str] = []
    for r in con.execute("SELECT data_path, crop_path FROM tubes WHERE video_id=?", (video_id,)):
        files += [r["data_path"], r["crop_path"]]
    for r in con.execute("SELECT path FROM backgrounds WHERE video_id=?", (video_id,)):
        files.append(r["path"])
    v = db.get_video(con, video_id)
    if v:
        keys = v.keys()
        for k in ("proxy_path", "src_path"):
            if k in keys and v[k]:
                files.append(v[k])
    for pat in (f"synopsis_{video_id}_*.mp4", f"synopsis_{video_id}_*.json"):
        files += [str(x) for x in config.DIR_OUT.glob(pat)]
    for r in con.execute("SELECT result FROM jobs WHERE video_id=? AND result IS NOT NULL",
                         (video_id,)):
        try:
            name = json.loads(r["result"]).get("file")
        except Exception:  # noqa: BLE001
            name = None
        if name:
            stem = Path(name).stem
            files += [str(config.DIR_OUT / f"{stem}.mp4"), str(config.DIR_OUT / f"{stem}.json")]
    return sorted({f for f in files if f and os.path.exists(f)})


def usage(video_id: int) -> dict | None:
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            return None
        n = con.execute("SELECT COUNT(*) n FROM tubes WHERE video_id=?", (video_id,)).fetchone()["n"]
        files = video_files(con, video_id)
    finally:
        con.close()
    size = 0
    for f in files:
        try:
            size += os.path.getsize(f)
        except OSError:
            pass
    return {"id": video_id, "name": v["name"], "path": v["path"], "n_tubes": int(n),
            "n_files": len(files), "bytes": size,
            "processed_at": v["processed_at"] or v["created_at"],
            "source_exists": bool(v["path"] and os.path.exists(v["path"]))}


def delete_video(video_id: int, reason: str = "manual") -> dict | None:
    """ลบผลวิเคราะห์ของวิดีโอหนึ่ง - ไม่แตะไฟล์วิดีโอต้นฉบับเด็ดขาด"""
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            return None
        name = v["name"]
        files = video_files(con, video_id)
        freed = 0
        for f in files:
            try:
                sz = os.path.getsize(f)
                os.remove(f)
                freed += sz
            except OSError:
                pass
        con.execute("DELETE FROM tube_points WHERE video_id=?", (video_id,))
        con.execute("DELETE FROM tubes WHERE video_id=?", (video_id,))
        con.execute("DELETE FROM backgrounds WHERE video_id=?", (video_id,))
        con.execute("DELETE FROM jobs WHERE video_id=?", (video_id,))
        con.execute("DELETE FROM videos WHERE id=?", (video_id,))
        con.commit()
    finally:
        con.close()
    db.log("delete_video", {"video_id": video_id, "name": name, "reason": reason,
                            "files": len(files), "freed_bytes": freed})
    return {"ok": True, "id": video_id, "name": name, "files": len(files), "freed": freed}


# --------------------------------------------------- ลบข้อมูลเก่าตามอายุ
def expired(days: int) -> list[dict]:
    """รายการวิดีโอที่เก่ากว่าจำนวนวันที่กำหนด"""
    if not days or days <= 0:
        return []
    cutoff = (datetime.now() - timedelta(days=int(days))).strftime("%Y-%m-%d %H:%M:%S")
    con = db.connect()
    try:
        rows = con.execute(
            "SELECT id, name, COALESCE(processed_at, created_at) AS ts FROM videos"
            " WHERE COALESCE(processed_at, created_at) IS NOT NULL"
            "   AND COALESCE(processed_at, created_at) < ?"
            " ORDER BY id", (cutoff,)
        ).fetchall()
    finally:
        con.close()
    return [dict(r) for r in rows]


def cleanup(days: int, dry_run: bool = False) -> dict:
    """ลบวิดีโอที่เก็บไว้เกินอายุที่กำหนด"""
    items = expired(days)
    if dry_run or not items:
        return {"days": days, "found": len(items), "deleted": 0, "freed": 0,
                "items": [i["name"] for i in items]}
    freed = 0
    done = []
    for it in items:
        r = delete_video(int(it["id"]), reason=f"เกินอายุเก็บ {days} วัน")
        if r:
            freed += r["freed"]
            done.append(r["name"])
    db.log("retention_cleanup", {"days": days, "deleted": len(done), "freed_bytes": freed})
    return {"days": days, "found": len(items), "deleted": len(done), "freed": freed,
            "items": done}


# --------------------------------------------------------- สำรองฐานข้อมูล
def backup_dir() -> Path:
    d = config.DATA / "backup"
    d.mkdir(parents=True, exist_ok=True)
    return d


def backup_db(keep: int = 7, force: bool = False) -> dict:
    """สำรองฐานข้อมูลด้วยกลไก backup ของ sqlite (ปลอดภัยแม้โปรแกรมกำลังเปิดอยู่)

    วันละครั้งพอ ถ้าวันนี้สำรองไว้แล้วจะข้าม เว้นแต่สั่ง force
    """
    if not config.DB_PATH.exists():
        return {"ok": False, "reason": "ยังไม่มีฐานข้อมูล"}
    d = backup_dir()
    stamp = datetime.now().strftime("%Y%m%d")
    dest = d / f"klongthep-{stamp}.db"
    if dest.exists() and not force:
        return {"ok": True, "skipped": True, "path": str(dest),
                "bytes": dest.stat().st_size}
    try:
        src = sqlite3.connect(str(config.DB_PATH))
        dst = sqlite3.connect(str(dest))
        with dst:
            src.backup(dst)
        dst.close()
        src.close()
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "reason": str(exc)}

    # เก็บย้อนหลังเท่าที่กำหนด ที่เหลือลบทิ้ง
    olds = sorted(d.glob("klongthep-*.db"), reverse=True)
    removed = 0
    for p in olds[max(1, int(keep)):]:
        try:
            p.unlink()
            removed += 1
        except OSError:
            pass
    return {"ok": True, "skipped": False, "path": str(dest),
            "bytes": dest.stat().st_size, "removed_old": removed,
            "kept": min(len(olds), max(1, int(keep)))}


def disk_usage() -> dict:
    """ขนาดข้อมูลที่ระบบใช้อยู่ แยกตามประเภท"""
    def size_of(d: Path) -> int:
        try:
            return sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
        except OSError:
            return 0

    parts = {
        "ฐานข้อมูล": config.DB_PATH.stat().st_size if config.DB_PATH.exists() else 0,
        "ข้อมูลวัตถุ": size_of(config.DIR_TUBES),
        "ภาพตัวอย่าง": size_of(config.DIR_CROPS),
        "ภาพพื้นหลัง": size_of(config.DIR_BG),
        "วิดีโอย่อ": size_of(config.DIR_OUT),
        "ไฟล์แปลง": size_of(config.DIR_PROXY),
        "สำรองข้อมูล": size_of(backup_dir()),
    }
    return {"parts": parts, "total": sum(parts.values())}


def startup(cfg: dict) -> dict:
    """งานที่ทำตอนเปิดโปรแกรม: สำรองข้อมูล แล้วลบของเก่าถ้าตั้งไว้"""
    m = cfg.get("maintenance") or {}
    out: dict = {}
    if m.get("backup_on_start", True):
        out["backup"] = backup_db(int(m.get("backup_keep", 7)))
    days = int(m.get("retention_days", 0) or 0)
    if days > 0:
        out["cleanup"] = cleanup(days)
    else:
        out["cleanup"] = {"days": 0, "found": 0, "deleted": 0, "freed": 0, "items": []}
    return out
