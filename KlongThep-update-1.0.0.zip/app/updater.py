"""อัปเดตโปรแกรมจากเว็บ — โดยไม่ต้องดาวน์โหลดชุดใหญ่ 4 GB ใหม่ทุกครั้ง

หลักการ: ตัว .exe ที่แจก แยกเป็นสองส่วน
  _internal/            ไลบรารีหนัก ๆ (torch, ultralytics, opencv) — แทบไม่เปลี่ยน
  app/ cli.py launcher.py   โค้ดของกล้องเทพเอง — ไม่กี่ร้อย KB และเปลี่ยนบ่อย
โค้ดส่วนหลังไม่ได้ถูกอัดรวมไว้ใน .exe แต่วางเป็นไฟล์ธรรมดาใน _internal/app
และ launcher จะ "มองหาโฟลเดอร์ app ข้าง .exe ก่อน" ถ้ามีจะใช้ตัวนั้นแทน
การอัปเดตจึงเป็นแค่ดาวน์โหลด zip เล็ก ๆ แล้ววางไฟล์ไว้ข้าง .exe

ไฟล์ประกาศรุ่น (klongthep.json บนเว็บ) มีอย่างน้อย:
  version       "1.0.1"
  update_url    ลิงก์ zip ของโค้ด (KlongThep-update-1.0.1.zip)
  update_sha256 ค่าตรวจสอบของ zip นั้น (แนะนำ — กันไฟล์เสีย/ถูกสลับ)
  update_size   ขนาดเป็นไบต์ (ไว้แสดง)
  notes         ข้อความบอกว่ารุ่นนี้เปลี่ยนอะไร
  url           ลิงก์ชุดเต็ม (ไว้บอกผู้ใช้ถ้าอัปเดตย่อยใช้ไม่ได้)
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import ssl
import time
import urllib.request
import zipfile
from pathlib import Path

from . import config
from .version import __version__

DEFAULT_URL = "https://kaveek1-rgb.github.io/klongthep.json"
# ไฟล์/โฟลเดอร์ระดับบนสุดที่ยอมให้ zip อัปเดตเขียนทับ — นอกเหนือจากนี้ไม่แตะ (กัน zip แปลก ๆ)
ALLOWED_ROOTS = ("app", "tools", "cli.py", "launcher.py", "README.md", "THIRD_PARTY.md",
                 "run.bat", "run_web.bat", "build_exe.bat", "klongthep.spec", "installer.iss",
                 "requirements.txt")
UA = f"KlongThep/{__version__}"

_cache: dict = {"at": 0.0, "info": None}


def _vtuple(v: str) -> tuple:
    out = []
    for part in str(v or "0").strip().lstrip("vV").split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out[:4])


def _fetch(url: str, timeout: float = 8.0) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Cache-Control": "no-cache"})
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()


def check(url: str | None = None, force: bool = False, timeout: float = 8.0) -> dict:
    """ถามเว็บว่ามีรุ่นใหม่ไหม (จำผลไว้ 10 นาที ไม่ยิงเน็ตทุกครั้งที่หน้าเว็บถาม)"""
    url = url or DEFAULT_URL
    now = time.time()
    if not force and _cache["info"] and now - _cache["at"] < 600:
        return _cache["info"]
    base = {"current": __version__, "url": url, "checked_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    try:
        data = json.loads(_fetch(url, timeout).decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        info = {**base, "ok": False, "available": False,
                "error": f"ติดต่อเว็บไม่ได้ ({type(exc).__name__}) — ต้องต่ออินเทอร์เน็ตตอนตรวจสอบ"}
        _cache.update(at=now, info=info)
        return info
    latest = str(data.get("version") or "").strip()
    info = {
        **base, "ok": True,
        "latest": latest,
        "available": bool(latest) and _vtuple(latest) > _vtuple(__version__),
        "released": data.get("released") or "",
        "notes": data.get("notes") or "",
        "update_url": data.get("update_url") or "",
        "update_size": int(data.get("update_size") or 0),
        "update_sha256": (data.get("update_sha256") or "").lower(),
        "full_url": data.get("url") or "",
    }
    _cache.update(at=now, info=info)
    return info


def _safe_members(z: zipfile.ZipFile) -> list[tuple[zipfile.ZipInfo, str]]:
    """คัดเฉพาะไฟล์ที่ปลอดภัยและอยู่ในรายการที่อนุญาต ตัด prefix โฟลเดอร์ชั้นนอกออกให้"""
    names = [m.filename for m in z.infolist() if not m.is_dir()]
    # zip อาจห่อไว้ในโฟลเดอร์ชั้นเดียว เช่น KlongThep-update-1.0.1/app/... -> ตัดออก
    prefix = ""
    tops = {n.split("/")[0] for n in names}
    if len(tops) == 1 and (t := next(iter(tops))) not in ALLOWED_ROOTS and all("/" in n for n in names):
        prefix = t + "/"
    out = []
    for m in z.infolist():
        if m.is_dir():
            continue
        rel = m.filename[len(prefix):] if m.filename.startswith(prefix) else m.filename
        rel = rel.replace("\\", "/")
        if not rel or rel.startswith("/") or ".." in rel.split("/") or ":" in rel:
            continue
        top = rel.split("/")[0]
        if top not in ALLOWED_ROOTS or "__pycache__" in rel or rel.endswith(".pyc"):
            continue
        out.append((m, rel))
    return out


def apply(info: dict | None = None, on_status=None) -> dict:
    """ดาวน์โหลด zip อัปเดต ตรวจสอบ แล้ววางไฟล์ข้าง .exe (หรือทับซอร์สถ้ารันจากซอร์ส)

    ไฟล์เดิมที่ถูกทับจะถูกสำรองไว้ใน data/update/backup-<รุ่นเดิม>/ เผื่อต้องย้อนกลับ
    """
    def say(msg: str):
        print(f"[อัปเดต] {msg}")
        if on_status:
            on_status(msg)

    info = info or check(force=True)
    if not info.get("ok"):
        raise SystemExit(info.get("error") or "ตรวจสอบรุ่นไม่สำเร็จ")
    if not info.get("available"):
        raise SystemExit(f"เป็นรุ่นล่าสุดอยู่แล้ว ({__version__})")
    url = info.get("update_url")
    if not url:
        raise SystemExit("รุ่นใหม่นี้ไม่มีไฟล์อัปเดตย่อย ต้องดาวน์โหลดชุดเต็มจากเว็บ"
                         + (f": {info['full_url']}" if info.get("full_url") else ""))

    workdir = config.DATA / "update"
    workdir.mkdir(parents=True, exist_ok=True)
    say(f"กำลังดาวน์โหลดรุ่น {info['latest']} …")
    t0 = time.time()
    blob = _fetch(url, timeout=120)
    say(f"ดาวน์โหลดแล้ว {len(blob) / 1048576:.1f} MB ใน {time.time() - t0:.0f} วินาที")
    want = info.get("update_sha256") or ""
    if want:
        got = hashlib.sha256(blob).hexdigest()
        if got != want:
            raise SystemExit("ไฟล์อัปเดตไม่ตรงกับค่าตรวจสอบบนเว็บ (ไฟล์เสียหรือถูกแก้ระหว่างทาง) ยกเลิกเพื่อความปลอดภัย")
    try:
        z = zipfile.ZipFile(io.BytesIO(blob))
    except zipfile.BadZipFile:
        raise SystemExit("ไฟล์ที่ดาวน์โหลดมาไม่ใช่ zip — ลิงก์อัปเดตบนเว็บอาจผิด")
    members = _safe_members(z)
    if not any(rel == "app/version.py" for _m, rel in members):
        raise SystemExit("zip อัปเดตไม่มี app/version.py — ไม่ใช่ไฟล์อัปเดตของกล้องเทพ")

    # แตกลงที่พักก่อน แล้วค่อยย้ายเข้าที่ทีเดียว จะได้ไม่ค้างครึ่ง ๆ กลาง ๆ ถ้าดิสก์เต็ม
    stage = workdir / "stage"
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True)
    for m, rel in members:
        dest = stage / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        with z.open(m) as src, open(dest, "wb") as fh:
            shutil.copyfileobj(src, fh)

    backup = workdir / f"backup-{__version__}"
    shutil.rmtree(backup, ignore_errors=True)
    root = config.ROOT
    n = 0
    say("กำลังวางไฟล์รุ่นใหม่ …")
    for src in sorted(stage.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(stage)
        dst = root / rel
        if dst.exists():
            b = backup / rel
            b.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(dst, b)
            except OSError:
                pass
        dst.parent.mkdir(parents=True, exist_ok=True)
        # บน Windows ไฟล์ .py/.html ที่โปรแกรมโหลดไปแล้วเขียนทับได้ (ไม่ถูกล็อกเหมือน .exe/.dll)
        tmp = dst.with_suffix(dst.suffix + ".new")
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
        n += 1
    shutil.rmtree(stage, ignore_errors=True)
    say(f"วางไฟล์แล้ว {n} ไฟล์ — ปิดแล้วเปิดโปรแกรมใหม่เพื่อใช้รุ่น {info['latest']}")
    _cache.update(at=0.0, info=None)
    return {"ok": True, "files": n, "version": info["latest"], "backup": str(backup),
            "needs_restart": True}


def rollback() -> dict:
    """ย้อนกลับไปรุ่นก่อนหน้า (จากสำเนาที่เก็บไว้ตอนอัปเดต)"""
    workdir = config.DATA / "update"
    cands = sorted(workdir.glob("backup-*"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not cands:
        raise SystemExit("ไม่มีสำเนารุ่นก่อนหน้าให้ย้อนกลับ")
    b = cands[0]
    n = 0
    for src in b.rglob("*"):
        if src.is_file():
            dst = config.ROOT / src.relative_to(b)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            n += 1
    return {"ok": True, "files": n, "from": b.name}
