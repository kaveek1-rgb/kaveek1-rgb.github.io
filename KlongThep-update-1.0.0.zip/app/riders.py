"""จับคู่คนขับกับรถสองล้อ

YOLO มองรถจักรยานยนต์กับคนขับเป็นวัตถุคนละตัว พอเอาไปทำวิดีโอย่อ
ตัวจัดเรียงเวลาจึงวางมันคนละช่วง กลายเป็นรถวิ่งเองโดยไม่มีคนขับ
และคนลอยอยู่กลางถนน ซึ่งใช้เป็นหลักฐานไม่ได้เลยเพราะไม่รู้ว่าใครขับคันไหน

ตัวนี้หาว่าคนไหน "อยู่บน" รถคันไหน แล้วผูกเข้าเป็นกลุ่มเดียวกัน
จากนั้นวิดีโอย่อจะวางทั้งกลุ่มพร้อมกันเสมอ โดยคงระยะเวลาระหว่างกันไว้

เกณฑ์การจับคู่ - ดูจากเฟรมที่ทั้งคู่ปรากฏพร้อมกัน
  1. จุดกึ่งกลางคนต้องอยู่ในแนวกึ่งกลางรถ (ไม่เกิน 0.6 เท่าของความกว้างรถ)
  2. กรอบคนกับกรอบรถต้องซ้อนกันในแนวตั้ง
  3. เงื่อนไขข้างบนต้องเป็นจริงอย่างน้อย 60% ของเฟรมที่อยู่ร่วมกัน
  4. ต้องอยู่ร่วมกันอย่างน้อยครึ่งหนึ่งของช่วงเวลาของตัวที่สั้นกว่า

รถหนึ่งคันมีคนได้หลายคน (คนขับ + คนซ้อน) แต่คนหนึ่งคนสังกัดรถได้คันเดียว
ถ้าเข้าเกณฑ์หลายคัน จะเลือกคันที่คะแนนดีที่สุด
"""
from __future__ import annotations

from collections import defaultdict

from . import db

RIDE_CLASSES = ("motorcycle", "bicycle")
MIN_FRAC = 0.60          # สัดส่วนเฟรมที่ท่าทางเข้าเกณฑ์
MIN_SHARE = 0.50         # สัดส่วนเวลาที่อยู่ร่วมกัน
MIN_COMMON = 3           # เฟรมร่วมขั้นต่ำ กันการจับคู่จากการบังเอิญผ่านกัน
MAX_RIDERS = 3           # คนขับ + คนซ้อน (เผื่อไว้ 3)


def _score(rp: dict, pp: dict) -> tuple[float, float, int]:
    common = set(rp) & set(pp)
    if len(common) < MIN_COMMON:
        return 0.0, 0.0, 0
    ok = 0
    for f in common:
        rx, _, rx1, ry1, rx2, ry2 = rp[f]
        px, _, _, py1, _, py2 = pp[f]
        rw = max(1.0, rx2 - rx1)
        if abs(px - rx) < 0.6 * rw and py1 < ry2 and py2 > ry1:
            ok += 1
    frac = ok / len(common)
    share = len(common) / max(1, min(len(rp), len(pp)))
    return frac, share, len(common)


def pair(video_id: int, con=None) -> dict:
    """ผูกคนขับเข้ากับรถสองล้อของวิดีโอนี้ คืนสรุปจำนวนที่จับคู่ได้"""
    own = con is None
    con = con or db.connect()
    try:
        rows = con.execute(
            "SELECT id, cls FROM tubes WHERE video_id=?", (int(video_id),)).fetchall()
        rides = [int(r["id"]) for r in rows if r["cls"] in RIDE_CLASSES]
        people = [int(r["id"]) for r in rows if r["cls"] == "person"]
        # ล้างของเดิมก่อนเสมอ เพื่อให้สั่งซ้ำได้โดยผลไม่เพี้ยน
        con.execute("UPDATE tubes SET group_id=NULL WHERE video_id=?", (int(video_id),))
        if not rides or not people:
            con.commit()
            return {"video_id": int(video_id), "groups": 0, "riders": 0,
                    "rides": len(rides), "people": len(people)}

        want = set(rides) | set(people)
        pts: dict[int, dict] = defaultdict(dict)
        for r in con.execute(
                "SELECT tube_id, frame, cx, cy, x1, y1, x2, y2 FROM tube_points"
                " WHERE video_id=?", (int(video_id),)):
            tid = int(r["tube_id"])
            if tid in want:
                pts[tid][int(r["frame"])] = (r["cx"], r["cy"],
                                             r["x1"], r["y1"], r["x2"], r["y2"])

        # คะแนนของทุกคู่ที่ผ่านเกณฑ์ แล้วให้คนแต่ละคนเลือกรถที่ดีที่สุดคันเดียว
        best: dict[int, tuple] = {}
        for rid in rides:
            rp = pts.get(rid) or {}
            if not rp:
                continue
            for pid in people:
                pp = pts.get(pid) or {}
                if not pp:
                    continue
                frac, share, n = _score(rp, pp)
                if frac < MIN_FRAC or share < MIN_SHARE:
                    continue
                key = (frac, share, n)
                if pid not in best or key > best[pid][1]:
                    best[pid] = (rid, key)

        by_ride: dict[int, list] = defaultdict(list)
        for pid, (rid, key) in best.items():
            by_ride[rid].append((key, pid))

        n_groups = n_riders = 0
        for rid, lst in by_ride.items():
            lst.sort(reverse=True)
            keep = [pid for _, pid in lst[:MAX_RIDERS]]
            ids = [rid] + keep
            con.executemany("UPDATE tubes SET group_id=? WHERE id=?",
                            [(rid, i) for i in ids])
            n_groups += 1
            n_riders += len(keep)
        con.commit()
        return {"video_id": int(video_id), "groups": n_groups, "riders": n_riders,
                "rides": len(rides), "people": len(people)}
    finally:
        if own:
            con.close()


def pair_all() -> list[dict]:
    """สั่งจับคู่ทุกวิดีโอที่ประมวลผลเสร็จแล้ว ใช้กับข้อมูลเก่าที่มีอยู่"""
    con = db.connect()
    try:
        vids = [int(r["id"]) for r in con.execute(
            "SELECT id FROM videos WHERE status='done' ORDER BY id")]
    finally:
        con.close()
    return [pair(v) for v in vids]


def members(con, group_id: int) -> list[dict]:
    return db.rows_to_dicts(con.execute(
        "SELECT * FROM tubes WHERE group_id=? ORDER BY cls DESC", (int(group_id),)).fetchall())
