"""แปลงตัวกรองจากหน้าเว็บเป็น SQL

ทุกการค้นหาอ่านจากตาราง tubes/tube_points เท่านั้น ไม่แตะวิดีโอและไม่รันโมเดล
จึงตอบได้ในเสี้ยววินาทีไม่ว่าวิดีโอจะยาวแค่ไหน
"""
from __future__ import annotations

from typing import Any

from . import db

SORTS = {
    "time": "t.start_sec ASC",
    "time_desc": "t.start_sec DESC",
    "duration": "t.duration DESC",
    "size": "t.area_avg DESC",
    "speed": "t.speed_px DESC",
}

# โหมดทุกกล้องต้องเรียงตามเวลานาฬิกาจริง ไม่ใช่เวลาในไฟล์
# ไม่งั้นเหตุการณ์จากคนละกล้องจะสลับกันมั่วจนอ่านไม่รู้เรื่อง
_ABS = "(COALESCE(CAST(strftime('%s', v.started_at) AS INTEGER), 0) + t.start_sec)"
SORTS_ABS = dict(SORTS, time=f"{_ABS} ASC", time_desc=f"{_ABS} DESC")


ALL = "all"          # ค่าพิเศษของ video_id ที่แปลว่า "ทุกกล้อง"


def _resolve_line(f: dict[str, Any]) -> dict[str, Any]:
    """แปลงตัวกรอง "เส้นทาง" เป็นรายการ id ก่อนสร้าง SQL"""
    line = f.get("line")
    if not line or len(line) != 4 or f.get("_line_ids") is not None:
        return f
    from . import paths as _paths        # นำเข้าตรงนี้เพื่อเลี่ยงวงจรนำเข้า
    f = dict(f)
    f["_line_ids"] = _paths.crossing_tube_ids(f.get("video_id"), [float(x) for x in line])
    return f


def build_query(f: dict[str, Any]) -> tuple[str, list, str]:
    where: list[str] = []
    args: list[Any] = []

    vid = f.get("video_id")
    if vid not in (None, "", ALL):
        where.append("t.video_id = ?")
        args.append(int(vid))

    # โหมดทุกกล้อง: กรองด้วยเวลานาฬิกาจริง เพราะแต่ละกล้องเริ่มบันทึกคนละเวลา
    # (SQLite เทียบเวลาผ่าน strftime ได้ตรง ๆ ถ้ารูปแบบเป็น YYYY-MM-DD HH:MM:SS)
    # ต้อง CAST เป็นตัวเลขทั้งสองฝั่ง — strftime ของ SQLite คืนค่าเป็นข้อความ
    # ถ้าเทียบตรง ๆ SQLite จะถือว่าตัวเลขน้อยกว่าข้อความเสมอ แล้วผลลัพธ์จะว่างเปล่า
    if f.get("abs_t0"):
        where.append("v.started_at IS NOT NULL AND "
                     "(CAST(strftime('%s', v.started_at) AS INTEGER) + t.end_sec)"
                     " >= CAST(strftime('%s', ?) AS INTEGER)")
        args.append(str(f["abs_t0"]))
    if f.get("abs_t1"):
        where.append("v.started_at IS NOT NULL AND "
                     "(CAST(strftime('%s', v.started_at) AS INTEGER) + t.start_sec)"
                     " <= CAST(strftime('%s', ?) AS INTEGER)")
        args.append(str(f["abs_t1"]))

    classes = f.get("classes") or []
    if classes:
        where.append("t.cls IN (%s)" % ",".join("?" * len(classes)))
        args += list(classes)

    if f.get("t0") is not None:
        where.append("t.end_sec >= ?")
        args.append(float(f["t0"]))
    if f.get("t1") is not None:
        where.append("t.start_sec <= ?")
        args.append(float(f["t1"]))

    cols = [c for c in (f.get("colors") or []) if c]
    if cols:
        ors = []
        for c in cols:
            ors.append("(t.color_main=? OR t.color_upper=? OR t.color_lower=?)")
            args += [c, c, c]
        where.append("(" + " OR ".join(ors) + ")")

    if f.get("min_duration"):
        where.append("t.duration >= ?")
        args.append(float(f["min_duration"]))
    if f.get("max_duration"):
        where.append("t.duration <= ?")
        args.append(float(f["max_duration"]))
    if f.get("min_speed"):
        where.append("t.speed_px >= ?")
        args.append(float(f["min_speed"]))
    if f.get("max_speed"):
        where.append("t.speed_px <= ?")
        args.append(float(f["max_speed"]))
    # วัตถุที่ขยับน้อยกว่าตัวเองราวหนึ่งเท่า ถือว่า "ไม่ได้เคลื่อนที่"
    # (รถจอด ป้าย เงา หรือของที่โมเดลเห็นค้างไว้ทั้งคลิป)
    # พวกนี้ทำให้วิดีโอย่อสั้นลงไม่ได้ เพราะกินเวลาเต็มความยาวคลิป
    if f.get("moving_only"):
        where.append("t.dist_px >= 30 AND t.dist_px >= 1.2 * t.h_avg")

    if f.get("min_height"):
        where.append("t.h_avg >= ?")
        args.append(float(f["min_height"]))
    if f.get("max_height"):
        where.append("t.h_avg <= ?")
        args.append(float(f["max_height"]))

    # ลักษณะบุคคล: สีเสื้อและสีกางเกงแยกกัน ต่างจากช่อง "สี" ด้านบน
    # ที่ยอมให้ตรงสีไหนก็ได้ ตรงนี้ระบุตำแหน่งชัดเจนว่าท่อนบนหรือท่อนล่าง
    # ใช้ได้เฉพาะกับคน เพราะระบบแยกสีบน/ล่างให้เฉพาะวัตถุประเภทคน
    ups = [c for c in (f.get("upper_colors") or []) if c]
    if ups:
        where.append("t.color_upper IN (%s)" % ",".join("?" * len(ups)))
        args += ups
    los = [c for c in (f.get("lower_colors") or []) if c]
    if los:
        where.append("t.color_lower IN (%s)" % ",".join("?" * len(los)))
        args += los

    # ทิศทาง: ส่งมาเป็นช่วงองศา [lo, hi] รองรับช่วงที่คร่อม 0
    d = f.get("direction")
    if d and len(d) == 2:
        lo, hi = float(d[0]) % 360, float(d[1]) % 360
        where.append("t.dist_px >= 25")
        if lo <= hi:
            where.append("t.dir_deg BETWEEN ? AND ?")
            args += [lo, hi]
        else:
            where.append("(t.dir_deg >= ? OR t.dir_deg <= ?)")
            args += [lo, hi]

    # เส้นทาง: ผู้ใช้ลากเส้นบนภาพ เอาเฉพาะวัตถุที่เดินข้ามเส้นนั้น
    # การหาจุดตัดทำใน Python (paths.crossing_tube_ids) เพราะ SQL ทำเรขาคณิตไม่ไหว
    # แล้วส่งรายการ id กลับเข้ามาที่นี่ เพื่อให้การนับผลรวมยังถูกต้อง
    ids = f.get("_line_ids")
    if ids is not None:
        if not ids:
            where.append("0")
        else:
            where.append("t.id IN (%s)" % ",".join("?" * len(ids)))
            args += [int(i) for i in ids]

    # พื้นที่สนใจ: กรอบในพิกัดสัมพัทธ์ 0-1 ของภาพ
    roi = f.get("roi")
    join = ""
    if roi and len(roi) == 4:
        join = " JOIN tube_points p ON p.tube_id = t.id "
        where.append(
            "p.cx BETWEEN ?*v.width AND ?*v.width AND p.cy BETWEEN ?*v.height AND ?*v.height"
        )
        args += [float(roi[0]), float(roi[2]), float(roi[1]), float(roi[3])]

    sql = (
        "SELECT DISTINCT t.*, v.name AS video_name, v.started_at AS video_started "
        " FROM tubes t JOIN videos v ON v.id = t.video_id "
        + join
        + (" WHERE " + " AND ".join(where) if where else "")
    )
    table = SORTS_ABS if vid in (None, "", ALL) else SORTS
    order = table.get(str(f.get("sort") or "time"), table["time"])
    return sql, args, order


def search(f: dict[str, Any], limit: int = 500, offset: int = 0) -> dict:
    f = _resolve_line(f)
    sql, args, order = build_query(f)
    con = db.connect()
    try:
        total = con.execute(f"SELECT COUNT(*) AS n FROM ({sql})", args).fetchone()["n"]
        rows = con.execute(f"{sql} ORDER BY {order} LIMIT ? OFFSET ?",
                           args + [int(limit), int(offset)]).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["clock"] = db.wall_clock(d.get("video_started"), d["start_sec"])
            d.pop("data_path", None)
            out.append(d)

        # บอกว่าวัตถุนี้เป็น "รถ" หรือ "คนที่อยู่บนรถ" ในกลุ่มไหน
        # เพื่อให้หน้าเว็บติดป้ายได้ว่าคันนี้รู้แล้วว่าใครขับ
        gids = {d["group_id"] for d in out if d.get("group_id")}
        sizes: dict = {}
        if gids:
            gl = list(gids)
            for i in range(0, len(gl), 400):
                ch = gl[i:i + 400]
                for row in con.execute(
                        "SELECT group_id, COUNT(*) n FROM tubes WHERE group_id IN (%s)"
                        " GROUP BY group_id" % ",".join("?" * len(ch)), ch):
                    sizes[int(row["group_id"])] = int(row["n"])
        for d in out:
            g = d.get("group_id")
            if not g:
                d["group_role"] = None
                d["group_n"] = 0
            else:
                d["group_role"] = "vehicle" if int(g) == int(d["id"]) else "rider"
                d["group_n"] = sizes.get(int(g), 0)
        return {"total": int(total), "items": out}
    finally:
        con.close()


def _scope(video_id) -> tuple[str, list]:
    if video_id in (None, "", ALL):
        return "", []
    return " WHERE video_id=?", [int(video_id)]


def class_counts(video_id) -> list[dict]:
    w, a = _scope(video_id)
    con = db.connect()
    try:
        return db.rows_to_dicts(con.execute(
            f"SELECT cls, COUNT(*) n FROM tubes{w} GROUP BY cls ORDER BY n DESC", a).fetchall())
    finally:
        con.close()


def color_counts(video_id) -> list[dict]:
    w, a = _scope(video_id)
    joiner = " AND " if w else " WHERE "
    con = db.connect()
    try:
        return db.rows_to_dicts(con.execute(
            f"SELECT color_main AS color, COUNT(*) n FROM tubes{w}{joiner}color_main<>''"
            " GROUP BY color_main ORDER BY n DESC", a).fetchall())
    finally:
        con.close()


def cameras() -> list[dict]:
    """สรุปรายกล้อง ใช้ในโหมดทุกกล้อง"""
    con = db.connect()
    try:
        return db.rows_to_dicts(con.execute(
            "SELECT v.id, v.name, v.started_at, v.duration, COUNT(t.id) n"
            " FROM videos v LEFT JOIN tubes t ON t.video_id=v.id"
            " WHERE v.status='done' GROUP BY v.id ORDER BY v.started_at, v.id").fetchall())
    finally:
        con.close()
