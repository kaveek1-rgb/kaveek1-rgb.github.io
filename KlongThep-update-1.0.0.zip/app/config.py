"""โหลดไฟล์ตั้งค่าและกำหนดตำแหน่งโฟลเดอร์ต่าง ๆ"""
from __future__ import annotations

import copy
import os
import sys
from pathlib import Path

# ตอนรันจากซอร์ส ทุกอย่างอยู่โฟลเดอร์เดียวกัน
# ตอนรันจากไฟล์ .exe (PyInstaller) โค้ดถูกแพ็กไว้ใน _internal แต่ข้อมูลของผู้ใช้
# (data/, models/, config.yaml) ต้องอยู่ข้างไฟล์ .exe ที่ผู้ใช้มองเห็นและสำรองได้
FROZEN = bool(getattr(sys, "frozen", False))
# PKG = โฟลเดอร์ที่มีโค้ด/หน้าเว็บของรุ่นที่กำลังรันอยู่ — คือที่ที่ไฟล์นี้ถูกโหลดมาจริง
# (รันจากซอร์ส = โฟลเดอร์โปรเจกต์, รันจาก .exe = _internal หรือโฟลเดอร์ app ที่อัปเดตมาวางข้าง .exe)
PKG = Path(__file__).resolve().parent.parent
if FROZEN:
    ROOT = Path(sys.executable).resolve().parent          # ข้อมูลผู้ใช้ (config, models, data)
else:
    ROOT = PKG
DATA = ROOT / "data"
DB_PATH = DATA / "klongthep.db"
DIR_CROPS = DATA / "crops"
DIR_TUBES = DATA / "tubes"
DIR_BG = DATA / "bg"
DIR_OUT = DATA / "out"
DIR_PROXY = DATA / "proxy"
DIR_MODELS = ROOT / "models"
WEB_DIR = PKG / "app" / "web"
TRACKER_DIR = PKG / "app" / "trackers"

DEFAULTS = {
    "detector": {
        "model": "models/yolo26s-seg.pt",
        "device": "auto",
        "imgsz": 1536,
        "conf": 0.15,
        "iou": 0.50,
        "stride": 2,
        "tracker": "app/trackers/klongthep.yaml",
        "mask_model": "",
        "half": True,
        "motion_gate": True,
        "motion_threshold": 18,
        "motion_min_ratio": 0.0004,
        "motion_heartbeat_sec": 2.0,
        "motion_cooldown_sec": 2.0,
        "classes": ["person", "bicycle", "car", "motorcycle", "bus", "truck", "dog", "cat"],
    },
    "tube": {
        "min_frames": 3,
        "min_box_px": 11,
        "max_gap": 30,
        "patch_max_dim": 256,
        "patch_quality": 78,
    },
    "background": {"bucket_minutes": 10, "samples": 41},
    "render": {"width": 1280, "fps": 25, "encoder": "auto", "workers": "auto"},
    "update": {"url": "https://kaveek1-rgb.github.io/klongthep.json", "check_on_start": True},
    "synopsis": {
        "collision_threshold": 0.14,
        "shift_step": 4,
        "min_gap": 6,
        "max_tubes": 800,
        "show_timestamp": True,
        "show_box": True,
    },
    "maintenance": {"retention_days": 0, "backup_keep": 7, "backup_on_start": True},
    "server": {"host": "127.0.0.1", "port": 8420, "open_browser": True},
    "video": {"make_proxy": True},
}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load(path: str | os.PathLike | None = None) -> dict:
    """อ่าน config.yaml ถ้ามี ไม่มีก็ใช้ค่าเริ่มต้น"""
    p = Path(path) if path else (ROOT / "config.yaml")
    user = {}
    if p.exists():
        try:
            import yaml  # type: ignore

            with open(p, "r", encoding="utf-8") as fh:
                user = yaml.safe_load(fh) or {}
        except ImportError:
            print("[เตือน] ไม่พบ PyYAML จึงใช้ค่าตั้งต้นทั้งหมด")
        except Exception as exc:  # noqa: BLE001
            print(f"[เตือน] อ่าน {p} ไม่สำเร็จ ({exc}) จึงใช้ค่าตั้งต้น")
    return _merge(DEFAULTS, user)


def ensure_dirs() -> None:
    for d in (DATA, DIR_CROPS, DIR_TUBES, DIR_BG, DIR_OUT, DIR_PROXY, DIR_MODELS):
        d.mkdir(parents=True, exist_ok=True)
