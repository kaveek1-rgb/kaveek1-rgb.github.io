"""เส้นทางการเคลื่อนที่ - ดึงเส้นทางของวัตถุมาวาดทับภาพนิ่งภาพเดียว

ตอบคำถามที่พนักงานสอบสวนถามบ่อยที่สุด "รถคันนี้มาจากทางไหน แล้วไปทางไหน"
โดยไม่ต้องเปิดวิดีโอดูทีละคัน

ข้อมูลมีอยู่แล้วในตาราง tube_points ซึ่งเก็บจุดกึ่งกลางของวัตถุทุกเฟรม
ที่ตรวจ ตอนวิเคราะห์วิดีโอ จึงไม่ต้องประมวลผลวิดีโอใหม่

ตัวกรอง "เส้นทาง" ทำงานกลับกัน คือผู้ใช้ลากเส้นบนภาพ แล้วระบบหาว่า
วัตถุตัวไหนเดินข้ามเส้นนั้นบ้าง (เส้นสะดุด/tripwire) ใช้กับคำถามแบบ
"ใครออกจากซอยนี้บ้างระหว่างตีหนึ่งถึงตีสาม"
"""
from __future__ import annotations

from typing import Any

from . import db, search

MAX_PATHS = 400          # เกินนี้ภาพจะรกจนอ่านไม่ออก
MAX_POINTS = 48          # จุดต่อหนึ่งเส้น พอให้เห็นรูปทรงโดยไม่หนักเครื่อง


def _thin(pts: list[tuple[float, float]], keep: int = MAX_POINTS) -> list[list[float]]:
    """ลดจำนวนจุดแบบกระจายทั่วเส้น เก็บจุดแรกและจุดสุดท้ายไว้เสมอ"""
    n = len(pts)
    if n <= keep:
        return [[round(x, 1), round(y, 1)] for x, y in pts]
    step = (n - 1) / float(keep - 1)
    idx = sorted({int(round(i * step)) for i in range(keep)} | {0, n - 1})
    return [[round(pts[i][0], 1), round(pts[i][1], 1)] for i in idx]


def _seg_cross(a, b, c, d) -> bool:
    """ส่วนของเส้น ab ตัดกับ cd หรือไม่ (ใช้เครื่องหมายพื้นที่สามเหลี่ยม)"""
    def side(p, q, r):
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

    d1, d2 = side(c, d, a), side(c, d, b)
    d3, d4 = side(a, b, c), side(a, b, d)
    return ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0))


def crossing_tube_ids(video_id, line: list[float]) -> list[int]:
    """หา tube ที่เส้นทางตัดผ่านเส้นที่ผู้ใช้ลากไว้

    line เป็นพิกัดสัมพัทธ์ 0-1 ของภาพ [x0, y0, x1, y1] จะได้ไม่ผูกกับ
    ขนาดภาพที่หน้าเว็บแสดงอยู่
    """
    if not line or len(line) != 4:
        return []
    con = db.connect()
    try:
        q = ("SELECT p.tube_id, p.cx, p.cy, v.width, v.height FROM tube_points p"
             " JOIN videos v ON v.id = p.video_id")
        args: list[Any] = []
        if video_id not in (None, "", search.ALL):
            q += " WHERE p.video_id=?"
            args.append(int(video_id))
        q += " ORDER BY p.tube_id, p.sec"
        rows = con.execute(q, args).fetchall()
    finally:
        con.close()

    hit: set[int] = set()
    cur_id = None
    prev = None
    for r in rows:
        tid = int(r["tube_id"])
        w = float(r["width"] or 1) or 1.0
        h = float(r["height"] or 1) or 1.0
        c = (line[0] * w, line[1] * h)
        d = (line[2] * w, line[3] * h)
        pt = (float(r["cx"]), float(r["cy"]))
        if tid != cur_id:
            cur_id, prev = tid, pt
            continue
        if tid not in hit and prev is not None and _seg_cross(prev, pt, c, d):
            hit.add(tid)
        prev = pt
    return sorted(hit)


def paths(f: dict[str, Any], limit: int = MAX_PATHS) -> dict:
    """คืนเส้นทางของวัตถุที่ตรงตัวกรอง พร้อมข้อมูลไว้แสดงตอนคลิก"""
    res = search.search(f, limit=100000)
    items = res["items"]
    total = len(items)
    truncated = total > limit
    if truncated:
        # ตัดแบบกระจายทั่วช่วงเวลา ไม่ใช่เอาแต่ตัวแรก ๆ
        step = (total - 1) / float(limit - 1) if limit > 1 else 1
        keep = sorted({int(round(i * step)) for i in range(limit)})
        items = [items[i] for i in keep]

    ids = [int(it["id"]) for it in items]
    pts_by_tube: dict[int, list[tuple[float, float]]] = {}
    if ids:
        con = db.connect()
        try:
            CH = 400        # SQLite จำกัดจำนวนตัวแปรต่อคำสั่ง
            for i in range(0, len(ids), CH):
                chunk = ids[i:i + CH]
                rows = con.execute(
                    "SELECT tube_id, cx, cy FROM tube_points WHERE tube_id IN (%s)"
                    " ORDER BY tube_id, sec" % ",".join("?" * len(chunk)), chunk).fetchall()
                for r in rows:
                    pts_by_tube.setdefault(int(r["tube_id"]), []).append(
                        (float(r["cx"]), float(r["cy"])))
        finally:
            con.close()

    w = h = 0
    con = db.connect()
    try:
        vid = f.get("video_id")
        if vid not in (None, "", search.ALL):
            v = db.get_video(con, int(vid))
            if v:
                w, h = int(v["width"] or 0), int(v["height"] or 0)
    finally:
        con.close()

    out = []
    for it in items:
        p = pts_by_tube.get(int(it["id"]) , [])
        if len(p) < 2:
            continue
        out.append({
            "id": it["id"],
            "cls": it["cls"],
            "clock": it.get("clock"),
            "start_sec": it["start_sec"],
            "end_sec": it["end_sec"],
            "duration": it["duration"],
            "color": it.get("color_main") or "",
            "speed": it.get("speed_px"),
            "video_name": it.get("video_name"),
            "pts": _thin(p),
        })
    return {"width": w, "height": h, "items": out,
            "total_available": total, "truncated": truncated, "max_paths": limit}
