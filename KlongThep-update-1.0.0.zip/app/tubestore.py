"""อ่าน/เขียนข้อมูลราย tube ลงไฟล์ .npz

หนึ่ง tube = วัตถุหนึ่งตัวตลอดช่วงที่ปรากฏ ประกอบด้วย
  frames  หมายเลขเฟรมในวิดีโอต้นฉบับ
  secs    วินาทีในวิดีโอ
  boxes   กรอบ [x1,y1,x2,y2] ในพิกัดต้นฉบับ
  patch   ภาพชิ้นส่วนของวัตถุ (JPEG)  -> ใช้ตอนเรนเดอร์วิดีโอย่อ
  mask    รูปทรงวัตถุ (PNG ขาวดำ)     -> ใช้ตัดวัตถุออกจากพื้นหลัง

เก็บ JPEG/PNG เป็นไบต์ต่อกันแล้วจำ offset แทนการใช้ pickle
ทำให้ไฟล์เล็ก โหลดเร็ว และเปิดด้วย numpy เปล่า ๆ ได้
"""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np


def _pack(chunks: list[bytes]) -> tuple[np.ndarray, np.ndarray]:
    off = np.zeros(len(chunks) + 1, dtype=np.int64)
    for i, c in enumerate(chunks):
        off[i + 1] = off[i] + len(c)
    buf = np.frombuffer(b"".join(chunks), dtype=np.uint8) if chunks else np.zeros(0, np.uint8)
    return buf, off


def save(path: str | Path, frames, secs, boxes, patches: list[bytes], masks: list[bytes]) -> None:
    pbuf, poff = _pack(patches)
    mbuf, moff = _pack(masks)
    np.savez_compressed(
        str(path),
        frames=np.asarray(frames, dtype=np.int32),
        secs=np.asarray(secs, dtype=np.float32),
        boxes=np.asarray(boxes, dtype=np.int32).reshape(-1, 4),
        pbuf=pbuf, poff=poff, mbuf=mbuf, moff=moff,
    )


def encode_patch(img: np.ndarray, max_dim: int, quality: int) -> bytes:
    h, w = img.shape[:2]
    if max(h, w) > max_dim:
        s = max_dim / float(max(h, w))
        img = cv2.resize(img, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA)
    ok, enc = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
    return enc.tobytes() if ok else b""


def encode_mask(mask: np.ndarray, shape_hw: tuple[int, int]) -> bytes:
    """มาสก์ถูกย่อให้เท่าภาพ patch ตอนใช้งานอยู่แล้ว จึงเก็บขนาดเล็กได้"""
    h, w = shape_hw
    if mask.shape[:2] != (h, w):
        mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_NEAREST)
    ok, enc = cv2.imencode(".png", (mask > 0).astype(np.uint8) * 255)
    return enc.tobytes() if ok else b""


def load_index(path: str | Path):
    """อ่านเฉพาะดัชนีเวลา/กรอบ ไม่แตะภาพ - ใช้ตอนคำนวณการจัดเรียงเวลา"""
    z = np.load(str(path))
    try:
        return z["frames"], z["secs"], z["boxes"]
    finally:
        z.close()


class TubeData:
    """เปิดไฟล์ tube แบบ lazy - ถอดรหัสภาพเฉพาะเฟรมที่ขอ"""

    def __init__(self, path: str | Path):
        self.path = str(path)
        z = np.load(self.path)
        self.frames = z["frames"]
        self.secs = z["secs"]
        self.boxes = z["boxes"]
        self._pbuf = z["pbuf"]
        self._poff = z["poff"]
        self._mbuf = z["mbuf"]
        self._moff = z["moff"]
        z.close()

    def __len__(self) -> int:
        return int(self.frames.shape[0])

    def patch(self, i: int) -> np.ndarray | None:
        a, b = int(self._poff[i]), int(self._poff[i + 1])
        if b <= a:
            return None
        return cv2.imdecode(self._pbuf[a:b], cv2.IMREAD_COLOR)

    def mask(self, i: int) -> np.ndarray | None:
        a, b = int(self._moff[i]), int(self._moff[i + 1])
        if b <= a:
            return None
        return cv2.imdecode(self._mbuf[a:b], cv2.IMREAD_GRAYSCALE)
