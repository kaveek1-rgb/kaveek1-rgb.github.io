"""ท่อประมวลผลวิดีโอ - รันครั้งเดียวต่อไฟล์

วิดีโอ -> ถอดรหัส -> ตรวจจับ -> ติดตาม -> tube -> ฐานข้อมูล + ไฟล์ชิ้นส่วน
พร้อมกันนั้นก็สร้างภาพพื้นหลังแยกตามช่วงเวลา (รองรับแสงเปลี่ยน)

หลังขั้นนี้จบ การค้นหาทุกแบบไม่ต้องแตะวิดีโอหรือโมเดลอีกเลย
"""
from __future__ import annotations

import math
import os
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

from . import colors, config, db, detect, gate as gate_mod, guard, media, riders, stitch, tubestore


class _Acc:
    """ตัวสะสมข้อมูลของ tube หนึ่งตัวระหว่างประมวลผล"""

    __slots__ = ("track_id", "cls", "cls_id", "conf_sum", "n_conf", "frames", "secs",
                 "boxes", "patches", "masks", "col_main", "col_up", "col_lo",
                 "last_frame", "best_area", "best_patch", "cls_votes", "cls_ids",
                 "first_cls")

    def __init__(self, track_id: int, cls: str, cls_id: int):
        self.track_id = track_id
        self.cls = cls
        self.cls_id = cls_id
        self.conf_sum = 0.0
        self.n_conf = 0
        self.frames: list[int] = []
        self.secs: list[float] = []
        self.boxes: list[tuple[int, int, int, int]] = []
        self.patches: list[bytes] = []
        self.masks: list[bytes] = []
        self.col_main: list[str] = []
        self.col_up: list[str] = []
        self.col_lo: list[str] = []
        self.last_frame = -1
        self.best_area = -1
        self.best_patch: np.ndarray | None = None
        # โมเดลทายประเภทใหม่ทุกเฟรม วัตถุตัวเดียวจึงสลับไปมาได้
        # เช่นคนขี่มอเตอร์ไซค์ที่บางเฟรมเห็นเป็น "คน" บางเฟรมเห็นเป็น "รถจักรยานยนต์"
        # เดิมเราใช้ประเภทจากเฟรมแรกเฟรมเดียว ซึ่งเป็นเฟรมที่วัตถุยังเล็กและเบลอที่สุด
        # จึงเป็นเฟรมที่โมเดลทายผิดง่ายที่สุดด้วย ตอนนี้เก็บคะแนนโหวตไว้ทั้งเส้นทาง
        # แล้วค่อยตัดสินตอนจบ โดยถ่วงน้ำหนักด้วยความมั่นใจของแต่ละเฟรม
        self.cls_votes: dict[str, float] = {}
        self.cls_ids: dict[str, int] = {}
        self.first_cls = cls


def _direction_deg(x0, y0, x1, y1) -> float:
    return (math.degrees(math.atan2(y1 - y0, x1 - x0)) + 360.0) % 360.0


def _flush(con, video_id: int, acc: _Acc, cfg: dict, fps: float) -> bool:
    """เขียน tube หนึ่งตัวลงฐานข้อมูล คืน True ถ้าเก็บไว้"""
    tcfg = cfg["tube"]
    n = len(acc.frames)
    if n < int(tcfg["min_frames"]):
        return False

    # ตัดสินประเภทจากทั้งเส้นทาง ไม่ใช่จากเฟรมแรก
    if acc.cls_votes:
        win = max(acc.cls_votes.items(), key=lambda kv: kv[1])[0]
        acc.cls = win
        acc.cls_id = acc.cls_ids.get(win, acc.cls_id)

    boxes = np.asarray(acc.boxes, dtype=np.int32).reshape(-1, 4)
    ws = boxes[:, 2] - boxes[:, 0]
    hs = boxes[:, 3] - boxes[:, 1]
    if float(np.median(np.maximum(ws, hs))) < float(tcfg["min_box_px"]):
        return False

    cx = (boxes[:, 0] + boxes[:, 2]) / 2.0
    cy = (boxes[:, 1] + boxes[:, 3]) / 2.0
    dist = float(np.sum(np.hypot(np.diff(cx), np.diff(cy)))) if n > 1 else 0.0
    dur = float(acc.secs[-1] - acc.secs[0]) or (1.0 / max(fps, 1.0))

    # ตัวติดตามเอาหมายเลข track เดิมกลับมาใช้ซ้ำได้ เช่นวัตถุหลุดไปนานเกิน max_gap
    # เราปิด tube ไปแล้ว แต่มันโผล่กลับมาด้วยหมายเลขเดิม
    #
    # โค้ดเดิมตรงนี้ "ลบของเก่าทิ้งแล้วเขียนทับ" ซึ่งทำให้ช่วงแรกของวัตถุหายไปเงียบ ๆ
    # วัดจากคลิปจริงแล้วพบว่าเขียน 52 ตัวแต่เหลือในฐานข้อมูล 41 ตัว หายไป 21%
    # โดยไม่มีอะไรฟ้อง ซึ่งในงานสืบสวนคือการทำลายหลักฐานโดยไม่รู้ตัว
    #
    # จึงเปลี่ยนเป็นหาหมายเลขว่างให้ช่วงใหม่แทน เก็บไว้ทั้งสองช่วง
    # แล้วปล่อยให้ขั้นตอนต่อร่องรอยเป็นคนตัดสินว่าควรต่อกลับเป็นตัวเดียวกันไหม
    tid = int(acc.track_id)
    while con.execute("SELECT 1 FROM tubes WHERE video_id=? AND track_id=? LIMIT 1",
                      (video_id, tid)).fetchone():
        tid += 1_000_000

    cur = con.execute(
        """INSERT INTO tubes(video_id,track_id,cls,cls_id,conf,
             start_frame,end_frame,n_frames,start_sec,end_sec,duration,
             x1,y1,x2,y2,area_avg,h_avg,cx_start,cy_start,cx_end,cy_end,
             dir_deg,dist_px,speed_px,color_main,color_upper,color_lower)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            video_id, tid, acc.cls, acc.cls_id,
            acc.conf_sum / max(acc.n_conf, 1),
            int(acc.frames[0]), int(acc.frames[-1]), n,
            float(acc.secs[0]), float(acc.secs[-1]), dur,
            int(boxes[:, 0].min()), int(boxes[:, 1].min()),
            int(boxes[:, 2].max()), int(boxes[:, 3].max()),
            float(np.mean(ws * hs)), float(np.mean(hs)),
            float(cx[0]), float(cy[0]), float(cx[-1]), float(cy[-1]),
            _direction_deg(cx[0], cy[0], cx[-1], cy[-1]),
            dist, dist / max(dur, 1e-6),
            colors.vote(acc.col_main), colors.vote(acc.col_up), colors.vote(acc.col_lo),
        ),
    )
    tube_id = int(cur.lastrowid)

    con.executemany(
        "INSERT INTO tube_points(tube_id,video_id,frame,sec,cx,cy,x1,y1,x2,y2)"
        " VALUES(?,?,?,?,?,?,?,?,?,?)",
        [
            (tube_id, video_id, int(acc.frames[i]), float(acc.secs[i]),
             float(cx[i]), float(cy[i]),
             int(boxes[i, 0]), int(boxes[i, 1]), int(boxes[i, 2]), int(boxes[i, 3]))
            for i in range(n)
        ],
    )

    data_path = config.DIR_TUBES / f"{video_id}_{tube_id}.npz"
    tubestore.save(data_path, acc.frames, acc.secs, boxes, acc.patches, acc.masks)

    crop_path = ""
    if acc.best_patch is not None:
        crop_path = str(config.DIR_CROPS / f"{video_id}_{tube_id}.jpg")
        cv2.imwrite(crop_path, acc.best_patch, [int(cv2.IMWRITE_JPEG_QUALITY), 85])

    con.execute(
        "UPDATE tubes SET crop_path=?, data_path=? WHERE id=?",
        (crop_path, str(data_path), tube_id),
    )
    return True


def _save_background(con, video_id: int, bucket: int, samples: list[np.ndarray],
                     t0: float, t1: float) -> None:
    if not samples:
        return
    stack = np.stack(samples, axis=0)
    bg = np.median(stack, axis=0).astype(np.uint8)
    path = config.DIR_BG / f"{video_id}_{bucket}.jpg"
    cv2.imwrite(str(path), bg, [int(cv2.IMWRITE_JPEG_QUALITY), 90])
    con.execute(
        "INSERT OR REPLACE INTO backgrounds(video_id,bucket,start_sec,end_sec,path)"
        " VALUES(?,?,?,?,?)",
        (video_id, bucket, float(t0), float(t1), str(path)),
    )


def ingest(video_path: str | Path, started_at: str | None = None, cfg: dict | None = None,
           limit_sec: float | None = None,
           reingest: bool = True, resume: bool = False) -> int:
    """วิเคราะห์วิดีโอหนึ่งไฟล์

    resume=True = ทำต่อจากจุดที่ค้าง (เครื่องดับ/ปิดหน้าต่างกลางคัน) โดยเก็บวัตถุ
    ที่วิเคราะห์ไว้แล้ว ไม่ต้องเริ่มใหม่ตั้งแต่ต้น สำคัญมากกับไฟล์ 8 ชั่วโมง
    """
    cfg = cfg or config.load()
    config.ensure_dirs()
    db.init()

    video_path = str(Path(video_path).resolve())
    if not os.path.exists(video_path):
        raise SystemExit(f"ไม่พบไฟล์: {video_path}")

    # ไฟล์จากเครื่องบันทึก (.dav .h264 ...) ถูกแปลงให้อ่านได้ก่อน ไฟล์ทั่วไปใช้ตรง ๆ
    guard.require_disk(video_path, None)
    src_path, info = media.prepare_source(video_path)
    fps = info["fps"]
    stride = max(1, int(cfg["detector"]["stride"]))

    # ประมวลผลได้ทีละไฟล์ ถ้ามีงานอื่นทำอยู่ให้รอ (บอกผู้ใช้ว่ารออะไร)
    def _waiting(holder):
        print(f"[กล้องเทพ] รอคิว — กำลังประมวลผล {Path(holder.get('path', '?')).name} อยู่")
        try:
            c2 = db.connect()
            c2.execute("UPDATE videos SET status='queued', message=? WHERE path=?",
                       (f"รอคิว (กำลังทำ {Path(holder.get('path', '?')).name})", video_path))
            c2.commit(); c2.close()
        except Exception:  # noqa: BLE001
            pass
    guard.acquire_lock(video_path, wait=True, on_wait=_waiting)
    try:
        return _ingest_locked(video_path, started_at, cfg, limit_sec, reingest, resume,
                              info, fps, stride, src_path)
    finally:
        guard.release_lock()


def _ingest_locked(video_path: str, started_at, cfg: dict, limit_sec,
                   reingest: bool, resume: bool, info: dict, fps: float, stride: int,
                   src_path: str | None = None) -> int:
    src_path = src_path or video_path

    if not started_at:
        try:
            mtime = datetime.fromtimestamp(os.path.getmtime(video_path))
            start_dt = mtime.timestamp() - (info["duration"] or 0)
            started_at = datetime.fromtimestamp(start_dt).replace(microsecond=0).isoformat(sep=" ")
        except Exception:  # noqa: BLE001
            started_at = None

    con = db.connect()
    video_id = db.upsert_video(con, {
        "path": video_path,
        "name": Path(video_path).name,
        "fps": fps,
        "width": info["width"], "height": info["height"],
        "frame_count": info["frame_count"], "duration": info["duration"],
        "started_at": started_at,
        "status": "processing", "progress": 0.0, "message": "กำลังเตรียม",
        "detector": cfg["detector"]["model"],
        "stride": stride,
    })
    con.execute("UPDATE videos SET src_path=? WHERE id=?",
                (src_path if src_path != video_path else None, video_id))
    con.commit()

    resume_frame = 0
    if resume:
        # ทำต่อจากเฟรมสุดท้ายที่มีข้อมูล ถอยกลับนิดหน่อยเผื่อวัตถุที่ค้างอยู่ตอนถูกตัด
        row = con.execute("SELECT MAX(end_frame) m FROM tubes WHERE video_id=?", (video_id,)).fetchone()
        last = int(row["m"] or 0)
        resume_frame = max(0, last - int(cfg["tube"]["max_gap"]))
        if resume_frame > 0:
            # วัตถุที่คร่อมจุดตัดจะถูกสร้างใหม่ ลบของเดิมที่ทับซ้อนกันออกก่อน
            dup = con.execute("SELECT id, data_path, crop_path FROM tubes WHERE video_id=? AND end_frame>=?",
                              (video_id, resume_frame)).fetchall()
            for r in dup:
                for p in (r["data_path"], r["crop_path"]):
                    if p and os.path.exists(p):
                        try:
                            os.remove(p)
                        except OSError:
                            pass
                con.execute("DELETE FROM tube_points WHERE tube_id=?", (r["id"],))
                con.execute("DELETE FROM tubes WHERE id=?", (r["id"],))
            con.execute("DELETE FROM backgrounds WHERE video_id=? AND end_sec>=?",
                        (video_id, resume_frame / max(fps, 1.0)))
            con.commit()
            print(f"[กล้องเทพ] ทำต่อจากเฟรม {resume_frame:,} "
                  f"({resume_frame / max(fps, 1.0) / 60:.1f} นาที) — เก็บข้อมูลเดิมไว้")
        reingest = False

    if reingest:
        old = con.execute("SELECT id, data_path, crop_path FROM tubes WHERE video_id=?",
                          (video_id,)).fetchall()
        for r in old:
            for p in (r["data_path"], r["crop_path"]):
                if p and os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
        con.execute("DELETE FROM tube_points WHERE video_id=?", (video_id,))
        con.execute("DELETE FROM tubes WHERE video_id=?", (video_id,))
        con.execute("DELETE FROM backgrounds WHERE video_id=?", (video_id,))
        con.commit()

    # ไฟล์สำหรับเล่นในเบราว์เซอร์
    proxy = None
    if cfg["video"].get("make_proxy", True) and media.needs_proxy(video_path):
        rw = int(cfg["render"]["width"])
        if src_path != video_path and (info["width"] or 0) <= rw:
            proxy = src_path          # ไฟล์ที่แปลงแล้วเล็กพอ ใช้เล่นในเบราว์เซอร์ได้เลย ไม่ต้องแปลงซ้ำ
        else:
            db.set_progress(video_id, 0.01, "กำลังแปลงไฟล์ให้เบราว์เซอร์เล่นได้")
            proxy = media.make_proxy(src_path, video_id, rw)
        con.execute("UPDATE videos SET proxy_path=? WHERE id=?", (proxy, video_id))
        con.commit()

    tracker = detect.build(cfg)
    print(f"[กล้องเทพ] เริ่มประมวลผล: {Path(video_path).name}")
    print(f"           ตัวตรวจจับ: {tracker.name} | stride={stride} | fps={fps:.1f}")

    # เตรียมการสุ่มภาพพื้นหลัง
    bcfg = cfg["background"]
    bucket_sec = max(30.0, float(bcfg["bucket_minutes"]) * 60.0)
    bg_every = max(1, int(round(bucket_sec * fps / max(1, int(bcfg["samples"])))))
    bg_w = min(int(cfg["render"]["width"]), info["width"] or 1280)
    bg_scale = bg_w / float(info["width"] or bg_w)
    bg_samples: list[np.ndarray] = []
    bg_bucket = 0

    tcfg = cfg["tube"]
    max_gap = int(tcfg["max_gap"])
    patch_dim = int(tcfg["patch_max_dim"])
    patch_q = int(tcfg["patch_quality"])

    cap = cv2.VideoCapture(src_path)
    if resume_frame > 0:
        cap.set(cv2.CAP_PROP_POS_FRAMES, resume_frame)
        bg_bucket = int((resume_frame / max(fps, 1.0)) // bucket_sec)
    gate = gate_mod.MotionGate(cfg, fps, stride)
    # จับเวลาแยกส่วน เพื่อให้รู้ว่าเวลาหมดไปกับอะไรจริง ๆ ไม่ต้องเดา
    t_decode = t_gate = t_detect = t_pack = 0.0
    n_detect = 0
    n_recls = 0        # จำนวนวัตถุที่การโหวตทั้งเส้นทางแก้ประเภทจากเฟรมแรก
    active: dict[int, _Acc] = {}
    kept = int(con.execute("SELECT COUNT(*) FROM tubes WHERE video_id=?", (video_id,)).fetchone()[0]) if resume_frame > 0 else 0
    idx = resume_frame - 1
    t_start = time.time()
    last_report = 0.0
    total_frames = info["frame_count"] or 0
    if limit_sec:
        total_frames = min(total_frames or 10**9, int(limit_sec * fps))

    try:
        while True:
            ok = cap.grab()
            if not ok:
                break
            idx += 1
            sec = idx / fps
            if limit_sec and sec > limit_sec:
                break

            need_det = (idx % stride == 0)
            need_bg = (idx % bg_every == 0)
            if not (need_det or need_bg):
                continue

            _t = time.time()
            ok, frame = cap.retrieve()
            t_decode += time.time() - _t
            if not ok or frame is None:
                continue

            if need_bg:
                small = cv2.resize(frame, None, fx=bg_scale, fy=bg_scale,
                                   interpolation=cv2.INTER_AREA) if bg_scale < 0.999 else frame.copy()
                bg_samples.append(small)
                if sec >= (bg_bucket + 1) * bucket_sec:
                    _save_background(con, video_id, bg_bucket, bg_samples,
                                     bg_bucket * bucket_sec, sec)
                    con.commit()
                    bg_samples = []
                    bg_bucket += 1

            if not need_det:
                continue

            # ถ้าไม่มีวัตถุที่กำลังติดตามอยู่ และภาพนิ่งสนิท ก็ไม่ต้องปลุกการ์ดจอ
            _t = time.time()
            move = gate.should_detect(frame)
            t_gate += time.time() - _t
            if not active and not move:
                continue

            _t = time.time()
            dets = tracker.update(frame, idx)
            t_detect += time.time() - _t
            n_detect += 1
            _t = time.time()
            for d in dets:
                x1, y1, x2, y2 = d.box
                acc = active.get(d.track_id)
                if acc is None:
                    acc = _Acc(d.track_id, d.cls, d.cls_id)
                    active[d.track_id] = acc
                acc.last_frame = idx
                acc.conf_sum += d.conf
                acc.n_conf += 1
                acc.cls_votes[d.cls] = acc.cls_votes.get(d.cls, 0.0) + float(d.conf)
                acc.cls_ids[d.cls] = d.cls_id
                acc.frames.append(idx)
                acc.secs.append(sec)
                acc.boxes.append((x1, y1, x2, y2))

                patch = frame[y1:y2, x1:x2]
                if patch.size == 0:
                    acc.patches.append(b"")
                    acc.masks.append(b"")
                    continue
                pbytes = tubestore.encode_patch(patch, patch_dim, patch_q)
                acc.patches.append(pbytes)

                if d.mask is not None and d.mask.size:
                    dec = cv2.imdecode(np.frombuffer(pbytes, np.uint8), cv2.IMREAD_COLOR)
                    hw = dec.shape[:2] if dec is not None else patch.shape[:2]
                    acc.masks.append(tubestore.encode_mask(d.mask, hw))
                else:
                    acc.masks.append(b"")

                area = (x2 - x1) * (y2 - y1)
                if area > acc.best_area:
                    acc.best_area = area
                    longest = max(patch.shape[:2])
                    if longest <= 320:
                        acc.best_patch = patch.copy()
                    else:
                        s = 320.0 / longest
                        acc.best_patch = cv2.resize(patch, None, fx=s, fy=s,
                                                    interpolation=cv2.INTER_AREA)

                # เก็บสีจากบางเฟรมพอ ไม่ต้องทุกเฟรม
                if len(acc.frames) % 3 == 1:
                    m = d.mask if (d.mask is not None and d.mask.size) else None
                    acc.col_main.append(colors.dominant(patch, m))
                    if d.cls == "person":
                        up, lo = colors.upper_lower(patch, m)
                        acc.col_up.append(up)
                        acc.col_lo.append(lo)

            t_pack += time.time() - _t

            # ปิด tube ที่หายไปนานแล้ว
            done = [tid for tid, a in active.items() if idx - a.last_frame > max_gap]
            for tid in done:
                a = active.pop(tid)
                if _flush(con, video_id, a, cfg, fps):
                    kept += 1
                    if a.cls != a.first_cls:
                        n_recls += 1
            if done:
                con.commit()

            now = time.time()
            if now - last_report > 2.0:
                last_report = now
                frac = (idx / total_frames) if total_frames else 0.0
                elapsed = now - t_start
                rate = (idx - resume_frame + 1) / max(elapsed, 1e-6)
                eta = ((total_frames - idx) / rate) if (total_frames and rate > 0) else 0
                msg = f"เฟรม {idx:,}/{total_frames:,} | พบวัตถุแล้ว {kept:,} | เหลืออีก ~{eta/60:.1f} นาที"
                db.set_progress(video_id, min(0.99, max(0.01, frac)), msg)
                print(f"\r  {msg}   ", end="", flush=True)
    finally:
        cap.release()

    for tid in list(active):
        a = active.pop(tid)
        if _flush(con, video_id, a, cfg, fps):
            kept += 1
            if a.cls != a.first_cls:
                n_recls += 1
    if bg_samples:
        _save_background(con, video_id, bg_bucket, bg_samples,
                         bg_bucket * bucket_sec, (idx + 1) / fps)
    con.commit()

    # ต่อร่องรอยที่ขาดก่อน แล้วค่อยจับคู่คนขับ ลำดับนี้สำคัญ
    # เพราะการจับคู่อ้างจาก id ของ tube ถ้าต่อทีหลังจะทำให้คู่ที่จับไว้หลุด
    try:
        st = stitch.stitch(video_id, con)
        if st["merged"]:
            print(f"\n[กล้องเทพ] ต่อร่องรอยที่ขาด {st['merged']:,} ชิ้น "
                  f"เหลือวัตถุ {st['after']:,} ตัว (จาก {st['before']:,})")
        con.execute("UPDATE videos SET stitched=1 WHERE id=?", (video_id,))
        con.commit()
    except Exception as exc:  # noqa: BLE001
        print(f"\n[เตือน] ต่อร่องรอยไม่สำเร็จ ({exc}) — ข้อมูลอื่นยังใช้ได้ตามปกติ")

    try:
        rp = riders.pair(video_id, con)
        if rp["groups"]:
            print(f"\n[กล้องเทพ] จับคู่คนขับกับรถสองล้อได้ {rp['groups']:,} คัน "
                  f"(คนขับ/คนซ้อนรวม {rp['riders']:,} คน)")
    except Exception as exc:  # noqa: BLE001
        print(f"\n[เตือน] จับคู่คนขับไม่สำเร็จ ({exc}) — ข้อมูลอื่นยังใช้ได้ตามปกติ")

    duration = (idx + 1) / fps if idx >= 0 else info["duration"]
    con.execute(
        "UPDATE videos SET status='done', progress=1.0, message=?, n_tubes=?,"
        " processed_at=?, duration=COALESCE(NULLIF(duration,0),?) WHERE id=?",
        (f"เสร็จสิ้น พบวัตถุ {kept:,} รายการ", kept, db.now_iso(), duration, video_id),
    )
    con.commit()
    con.close()

    took = time.time() - t_start
    print(f"\n[กล้องเทพ] เสร็จแล้ว: {kept:,} วัตถุ | ใช้เวลา {took/60:.1f} นาที "
          f"({duration/max(took,1e-6):.1f}x เร็วกว่าเวลาจริง)")
    g = gate.summary()
    other = max(0.0, took - t_decode - t_gate - t_detect - t_pack)
    print(f"           เวลาไปไหน: อ่านวิดีโอ {t_decode/60:.1f} น. | "
          f"ตรวจด้วย AI {t_detect/60:.1f} น. ({n_detect:,} เฟรม) | "
          f"เก็บภาพวัตถุ {t_pack/60:.1f} น. | เช็คความเคลื่อนไหว {t_gate/60:.1f} น. | "
          f"อื่น ๆ {other/60:.1f} น.")
    if n_recls:
        print(f"           โหวตประเภทจากทั้งเส้นทาง แก้ให้ถูก {n_recls:,} ตัว "
              f"(เดิมใช้ประเภทจากเฟรมแรกซึ่งวัตถุยังเล็กและเบลอที่สุด)")
    if gate.enabled:
        print(f"           ข้ามเฟรมที่ภาพนิ่ง {g['skipped']:,} จาก {g['checked']:,} "
              f"({g['skipped_pct']}%) — ยิ่งมากยิ่งประหยัดเวลา")
    db.log("ingest", {"video_id": video_id, "path": video_path, "tubes": kept,
                      "วินาทีทั้งหมด": round(took, 1),
                      "อ่านวิดีโอ": round(t_decode, 1), "ตรวจ_ai": round(t_detect, 1),
                      "เก็บภาพ": round(t_pack, 1), "เช็คเคลื่อนไหว": round(t_gate, 1),
                      "เฟรมที่ตรวจจริง": n_detect, "ข้ามเพราะภาพนิ่ง": g["skipped"]})
    return video_id
