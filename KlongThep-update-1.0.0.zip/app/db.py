"""ฐานข้อมูล SQLite - คลังดัชนีของทั้งระบบ

หลักการ: ประมวลผลวิดีโอครั้งเดียว เขียนทุกอย่างลงที่นี่
หลังจากนั้นการค้นหาทุกแบบคือ SQL ไม่ต้องแตะวิดีโอหรือโมเดลอีก
"""
from __future__ import annotations

import contextvars
import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterable

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS videos (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    path          TEXT UNIQUE NOT NULL,
    name          TEXT NOT NULL,
    fps           REAL,
    width         INTEGER,
    height        INTEGER,
    frame_count   INTEGER,
    duration      REAL,
    started_at    TEXT,            -- เวลานาฬิกาจริงของวินาทีที่ 0 (ISO)
    proxy_path    TEXT,
    status        TEXT DEFAULT 'pending',   -- pending|processing|done|error
    progress      REAL DEFAULT 0,
    message       TEXT,
    detector      TEXT,
    stride        INTEGER,
    n_tubes       INTEGER DEFAULT 0,
    created_at    TEXT,
    processed_at  TEXT
);

CREATE TABLE IF NOT EXISTS tubes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    video_id     INTEGER NOT NULL,
    track_id     INTEGER NOT NULL,
    cls          TEXT,
    cls_id       INTEGER,
    conf         REAL,
    start_frame  INTEGER, end_frame INTEGER, n_frames INTEGER,
    start_sec    REAL,    end_sec   REAL,    duration REAL,
    x1 INTEGER, y1 INTEGER, x2 INTEGER, y2 INTEGER,
    area_avg     REAL,
    h_avg        REAL,
    cx_start REAL, cy_start REAL, cx_end REAL, cy_end REAL,
    dir_deg      REAL,      -- 0=ขวา 90=ลง 180=ซ้าย 270=ขึ้น (พิกัดภาพ)
    dist_px      REAL,
    speed_px     REAL,      -- พิกเซลต่อวินาที
    color_main   TEXT,
    color_upper  TEXT,
    color_lower  TEXT,
    crop_path    TEXT,
    data_path    TEXT,
    UNIQUE(video_id, track_id)
);
CREATE INDEX IF NOT EXISTS ix_tubes_video ON tubes(video_id);
CREATE INDEX IF NOT EXISTS ix_tubes_time  ON tubes(video_id, start_sec);
CREATE INDEX IF NOT EXISTS ix_tubes_cls   ON tubes(video_id, cls);

CREATE TABLE IF NOT EXISTS tube_points (
    tube_id  INTEGER NOT NULL,
    video_id INTEGER NOT NULL,
    frame    INTEGER, sec REAL,
    cx REAL, cy REAL,
    x1 INTEGER, y1 INTEGER, x2 INTEGER, y2 INTEGER
);
CREATE INDEX IF NOT EXISTS ix_pts_tube  ON tube_points(tube_id);
CREATE INDEX IF NOT EXISTS ix_pts_video ON tube_points(video_id, sec);

CREATE TABLE IF NOT EXISTS backgrounds (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    video_id  INTEGER NOT NULL,
    bucket    INTEGER,
    start_sec REAL, end_sec REAL,
    path      TEXT,
    UNIQUE(video_id, bucket)
);

CREATE TABLE IF NOT EXISTS jobs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kind       TEXT,            -- ingest|synopsis
    video_id   INTEGER,
    status     TEXT DEFAULT 'queued',
    progress   REAL DEFAULT 0,
    message    TEXT,
    params     TEXT,
    result     TEXT,
    created_at TEXT,
    updated_at TEXT
);

-- บันทึกการใช้งาน: ใครค้นอะไร เมื่อไร (ทำตั้งแต่วันแรกตามหลัก PDPA)
CREATE TABLE IF NOT EXISTS audit (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    ts     TEXT,
    user   TEXT,
    action TEXT,
    detail TEXT
);
CREATE INDEX IF NOT EXISTS ix_audit_ts ON audit(ts);
"""


def connect() -> sqlite3.Connection:
    config.ensure_dirs()
    con = sqlite3.connect(str(config.DB_PATH), timeout=30.0)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def init() -> None:
    con = connect()
    try:
        # WAL เร็วกว่ามาก แต่ใช้ไม่ได้บนไดรฟ์เครือข่ายบางแบบ
        # ถ้าตั้งไม่ได้ก็ปล่อยให้ใช้โหมดมาตรฐานแทน ไม่ต้องพัง
        for pragma in ("PRAGMA journal_mode=WAL", "PRAGMA synchronous=NORMAL"):
            try:
                con.execute(pragma)
            except sqlite3.OperationalError:
                pass
        con.executescript(SCHEMA)
        _migrate(con)
        con.commit()
    except sqlite3.OperationalError as exc:
        raise SystemExit(
            f"สร้างฐานข้อมูลไม่ได้ที่ {config.DB_PATH}\n"
            f"  สาเหตุ: {exc}\n"
            "  มักเกิดจากโฟลเดอร์อยู่บนไดรฟ์เครือข่าย หรือไม่มีสิทธิ์เขียน\n"
            "  ทางแก้: ย้ายโปรแกรมไปไว้บนไดรฟ์ในเครื่อง เช่น D:\\ หรือ C:\\"
        ) from exc
    finally:
        con.close()


def _migrate(con: sqlite3.Connection) -> None:
    """เพิ่มคอลัมน์ใหม่ให้ฐานข้อมูลเดิมโดยไม่ต้องประมวลผลวิดีโอใหม่

    ผู้ใช้มีข้อมูลที่วิเคราะห์ไว้แล้วหลายชั่วโมง การบังคับให้เริ่มใหม่
    เพราะเพิ่มฟีเจอร์เป็นสิ่งที่ยอมรับไม่ได้ในระบบงานจริง
    """
    vhave = {r[1] for r in con.execute("PRAGMA table_info(videos)")}
    if "src_path" not in vhave:
        # ไฟล์ที่แปลงจากรูปแบบของเครื่องบันทึก (.dav .h264 ฯลฯ) ให้โปรแกรมอ่านได้ NULL = อ่านต้นฉบับตรง ๆ
        con.execute("ALTER TABLE videos ADD COLUMN src_path TEXT")
    if "stitched" not in vhave:
        # 0 = ยังไม่ได้ต่อร่องรอยที่ขาด จะทำให้อัตโนมัติตอนสร้างวิดีโอย่อครั้งแรก
        con.execute("ALTER TABLE videos ADD COLUMN stitched INTEGER DEFAULT 0")
        print("[กล้องเทพ] อัปเดตฐานข้อมูล: เพิ่มการต่อร่องรอยที่ขาด")

    have = {r[1] for r in con.execute("PRAGMA table_info(tubes)")}
    if "group_id" not in have:
        # group_id = id ของ "รถ" ที่วัตถุนี้สังกัด ใช้จับคู่คนขับกับรถสองล้อ
        # ค่า NULL แปลว่าเป็นวัตถุเดี่ยว ไม่ได้อยู่กับใคร
        con.execute("ALTER TABLE tubes ADD COLUMN group_id INTEGER")
        con.execute("CREATE INDEX IF NOT EXISTS ix_tubes_group ON tubes(group_id)")
        print("[กล้องเทพ] อัปเดตฐานข้อมูล: เพิ่มการจับคู่คนขับกับรถ")


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat(sep=" ")


# ---------------------------------------------------------------- audit
# ชื่อผู้ใช้ของคำขอที่กำลังทำงานอยู่ ตั้งโดย middleware ของเว็บเซิร์ฟเวอร์
# ถ้าสั่งจากบรรทัดคำสั่งจะเป็น "คอนโซล"
CURRENT_USER: contextvars.ContextVar[str] = contextvars.ContextVar(
    "klongthep_user", default="คอนโซล")


def log(action: str, detail: Any = None, user: str | None = None) -> None:
    user = user or CURRENT_USER.get()
    try:
        con = connect()
        con.execute(
            "INSERT INTO audit(ts,user,action,detail) VALUES(?,?,?,?)",
            (now_iso(), user, action,
             detail if isinstance(detail, str) else json.dumps(detail, ensure_ascii=False)),
        )
        con.commit()
        con.close()
    except Exception:  # noqa: BLE001  บันทึกล้มเหลวต้องไม่ทำให้งานหลักพัง
        pass


# ---------------------------------------------------------------- videos
def get_video(con: sqlite3.Connection, video_id: int) -> sqlite3.Row | None:
    return con.execute("SELECT * FROM videos WHERE id=?", (video_id,)).fetchone()


def find_video_by_path(con: sqlite3.Connection, path: str) -> sqlite3.Row | None:
    return con.execute("SELECT * FROM videos WHERE path=?", (str(path),)).fetchone()


def upsert_video(con: sqlite3.Connection, info: dict) -> int:
    row = find_video_by_path(con, info["path"])
    if row:
        keys = [k for k in info if k != "path"]
        con.execute(
            f"UPDATE videos SET {', '.join(k + '=?' for k in keys)} WHERE id=?",
            [info[k] for k in keys] + [row["id"]],
        )
        con.commit()
        return int(row["id"])
    info = dict(info)
    info.setdefault("created_at", now_iso())
    cols = list(info)
    cur = con.execute(
        f"INSERT INTO videos({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
        [info[c] for c in cols],
    )
    con.commit()
    return int(cur.lastrowid)


def set_progress(video_id: int, progress: float, message: str = "", status: str | None = None) -> None:
    con = connect()
    try:
        if status:
            con.execute(
                "UPDATE videos SET progress=?, message=?, status=? WHERE id=?",
                (progress, message, status, video_id),
            )
        else:
            con.execute(
                "UPDATE videos SET progress=?, message=? WHERE id=?", (progress, message, video_id)
            )
        con.commit()
    finally:
        con.close()


def wall_clock(started_at: str | None, sec: float) -> str:
    """แปลงวินาทีในวิดีโอเป็นเวลานาฬิกาจริง"""
    if not started_at:
        h = int(sec // 3600)
        m = int((sec % 3600) // 60)
        s = int(sec % 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    try:
        base = datetime.fromisoformat(started_at)
    except ValueError:
        return f"{sec:.1f}s"
    return (base + timedelta(seconds=float(sec))).strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------- jobs
def job_create(kind: str, video_id: int | None, params: dict) -> int:
    con = connect()
    try:
        cur = con.execute(
            "INSERT INTO jobs(kind,video_id,status,progress,params,created_at,updated_at)"
            " VALUES(?,?,'queued',0,?,?,?)",
            (kind, video_id, json.dumps(params, ensure_ascii=False), now_iso(), now_iso()),
        )
        con.commit()
        return int(cur.lastrowid)
    finally:
        con.close()


def job_update(job_id: int, **fields: Any) -> None:
    if not fields:
        return
    fields["updated_at"] = now_iso()
    if isinstance(fields.get("result"), (dict, list)):
        fields["result"] = json.dumps(fields["result"], ensure_ascii=False)
    con = connect()
    try:
        con.execute(
            f"UPDATE jobs SET {', '.join(k + '=?' for k in fields)} WHERE id=?",
            list(fields.values()) + [job_id],
        )
        con.commit()
    finally:
        con.close()


def job_get(job_id: int) -> dict | None:
    con = connect()
    try:
        row = con.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def rows_to_dicts(rows: Iterable[sqlite3.Row]) -> list[dict]:
    return [dict(r) for r in rows]
