"""กลไกกันโปรแกรมพังในการใช้งานจริง

  - ล็อกให้ประมวลผลวิดีโอได้ทีละไฟล์ (กันกดเพิ่มวิดีโอสองครั้งจนการ์ดจอเต็ม)
  - ตรวจว่าโปรเซสที่ถือล็อกยังมีชีวิตอยู่ไหม (เครื่องดับ/ปิดหน้าต่างไปแล้วล็อกค้าง)
  - เช็คพื้นที่ดิสก์ก่อนเริ่ม (ดิสก์เต็มกลางทางคือทางที่พังเงียบที่สุด)
  - กู้สถานะตอนเปิดโปรแกรม: งานที่ค้างเพราะถูกขัดจังหวะต้องมีป้ายบอกและกดทำต่อได้

ทั้งหมดใช้แค่ไฟล์กับไลบรารีมาตรฐาน ไม่พึ่งแพ็กเกจเพิ่ม เพราะเครื่องปลายทาง
ติดตั้งอะไรเพิ่มไม่ได้ง่าย ๆ
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import time
from pathlib import Path

from . import config

LOCK = config.DATA / "ingest.lock"
MIN_FREE_GB = 1.0          # ต่ำกว่านี้ไม่ยอมเริ่มงานใหม่


# ------------------------------------------------------------- โปรเซสยังอยู่ไหม
def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
            if not h:
                return False
            try:
                code = ctypes.c_ulong()
                ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
                STILL_ACTIVE = 259
                return bool(ok) and code.value == STILL_ACTIVE
            finally:
                k32.CloseHandle(h)
        except Exception:  # noqa: BLE001
            return False
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:  # noqa: BLE001
        return False


# ------------------------------------------------------------------- ล็อก
def read_lock() -> dict | None:
    try:
        d = json.loads(LOCK.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except Exception:  # noqa: BLE001
        return None


def lock_holder() -> dict | None:
    """คืนข้อมูลล็อกถ้ามีคนถืออยู่จริง ล็อกค้างจากโปรเซสที่ตายแล้วถือว่าไม่มี"""
    d = read_lock()
    if not d:
        return None
    if pid_alive(int(d.get("pid") or 0)):
        return d
    try:
        LOCK.unlink()
    except OSError:
        pass
    return None


def acquire_lock(video_path: str, wait: bool = True, poll_sec: float = 5.0,
                 on_wait=None) -> None:
    """รอจนกว่าจะได้เป็นคนประมวลผลคนเดียว"""
    config.ensure_dirs()
    waited = False
    while True:
        holder = lock_holder()
        if holder is None:
            LOCK.write_text(json.dumps({
                "pid": os.getpid(), "path": str(video_path), "since": time.time(),
            }, ensure_ascii=False), encoding="utf-8")
            return
        if not wait:
            raise SystemExit(
                f"กำลังประมวลผล {Path(holder.get('path', '?')).name} อยู่ "
                "รอให้เสร็จก่อนแล้วค่อยเริ่มไฟล์ใหม่")
        if on_wait and not waited:
            on_wait(holder)
        waited = True
        time.sleep(poll_sec)


def release_lock() -> None:
    d = read_lock()
    if d and int(d.get("pid") or 0) == os.getpid():
        try:
            LOCK.unlink()
        except OSError:
            pass


# ------------------------------------------------------------------- ดิสก์
def free_gb(path: Path | None = None) -> float:
    try:
        u = shutil.disk_usage(str(path or config.DATA))
        return u.free / (1024 ** 3)
    except Exception:  # noqa: BLE001
        return 999.0


def require_disk(video_path: str, duration_sec: float | None) -> None:
    """ประเมินคร่าว ๆ ว่างานนี้กินที่เท่าไร แล้วปฏิเสธถ้าดิสก์ไม่พอ

    จากที่วัดมา ข้อมูลที่ระบบสร้าง (ภาพชิ้นส่วน + ฐานข้อมูล + ไฟล์เล่นในเว็บ)
    อยู่ราว 1-3 เท่าของขนาดไฟล์วิดีโอ ขึ้นกับความคึกคักของภาพ
    """
    free = free_gb()
    try:
        src_gb = os.path.getsize(video_path) / (1024 ** 3)
    except OSError:
        src_gb = 0.0
    need = max(MIN_FREE_GB, src_gb * 2.0)
    if free < need:
        raise SystemExit(
            f"พื้นที่ดิสก์เหลือ {free:.1f} GB แต่งานนี้ต้องการราว {need:.1f} GB\n"
            "  ลบวิดีโอเก่าออกจากระบบ (ปุ่ม ลบ) หรือย้ายไฟล์อื่นออกจากไดรฟ์ก่อน")


# ------------------------------------------------------ กู้สถานะตอนเปิดโปรแกรม
def recover(con) -> dict:
    """งานที่ค้างเพราะโปรแกรมถูกปิดกลางคัน ต้องไม่ค้างเป็น 'กำลังประมวลผล' ตลอดไป"""
    holder = lock_holder()
    busy_path = str(holder.get("path")) if holder else None
    fixed_videos = 0
    for r in con.execute("SELECT id, path, name FROM videos WHERE status IN ('processing','queued')").fetchall():
        if busy_path and os.path.normcase(str(r["path"])) == os.path.normcase(busy_path):
            continue                       # ยังทำอยู่จริง ไม่แตะ
        n = con.execute("SELECT COUNT(*) FROM tubes WHERE video_id=?", (r["id"],)).fetchone()[0]
        con.execute(
            "UPDATE videos SET status='interrupted',"
            " message=? WHERE id=?",
            (f"ถูกขัดจังหวะ (มีข้อมูลแล้ว {n:,} วัตถุ) — กด “ทำต่อ” เพื่อประมวลผลต่อจากจุดที่ค้าง", r["id"]))
        fixed_videos += 1
    fixed_jobs = con.execute(
        "UPDATE jobs SET status='error', message='ถูกขัดจังหวะเพราะโปรแกรมถูกปิด — สั่งใหม่ได้เลย'"
        " WHERE status IN ('running','queued')").rowcount
    con.commit()
    return {"videos": fixed_videos, "jobs": int(fixed_jobs or 0)}


# ----------------------------------------------------------------- บันทึกล็อก
class _Tee:
    """ส่งทุกอย่างที่พิมพ์ขึ้นจอไปเก็บในไฟล์ล็อกด้วย

    บรรทัดความคืบหน้าที่ใช้ \\r เขียนทับตัวเอง จะเก็บเฉพาะค่าสุดท้ายก่อนขึ้นบรรทัดใหม่
    ไม่งั้นไฟล์ล็อกจะบวมด้วยข้อความ "เฟรม 1/1000, 2/1000, ..." เป็นแสนบรรทัด
    """

    def __init__(self, stream, fh):
        self.stream = stream
        self.fh = fh
        self.buf = ""

    def write(self, s: str) -> int:
        try:
            self.stream.write(s)
        except Exception:  # noqa: BLE001
            pass
        self.buf += s
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            if "\r" in line:
                line = line.split("\r")[-1]
            if line.strip():
                try:
                    self.fh.write(time.strftime("%Y-%m-%d %H:%M:%S ") + line.rstrip() + "\n")
                    self.fh.flush()
                except Exception:  # noqa: BLE001
                    pass
        return len(s)

    def flush(self) -> None:
        try:
            self.stream.flush()
        except Exception:  # noqa: BLE001
            pass

    def __getattr__(self, name):
        if self.stream is None:
            # โปรแกรม .exe แบบไม่มีคอนโซล: ไม่มีจอให้พิมพ์ แต่ไลบรารีบางตัวยังถามว่าเป็นเทอร์มินัลไหม
            if name == "isatty":
                return lambda: False
            if name == "encoding":
                return "utf-8"
            if name == "errors":
                return "replace"
            raise AttributeError(name)
        return getattr(self.stream, name)


def setup_logging(tag: str = "app") -> Path | None:
    """เขียนสำเนาของทุกอย่างที่ขึ้นจอลง data/logs/ และหมุนไฟล์เมื่อใหญ่เกิน

    เวลาโปรแกรมพังที่ สภ. ตอนตีสอง ไม่มีใครอยู่ดูหน้าจอ ไฟล์นี้คือหลักฐานชิ้นเดียว
    """
    try:
        logdir = config.DATA / "logs"
        logdir.mkdir(parents=True, exist_ok=True)
        path = logdir / "klongthep.log"
        if path.exists() and path.stat().st_size > 5 * 1024 * 1024:
            for i in range(4, 0, -1):
                a, b = logdir / f"klongthep.log.{i}", logdir / f"klongthep.log.{i + 1}"
                if a.exists():
                    a.replace(b)
            path.replace(logdir / "klongthep.log.1")
        fh = open(path, "a", encoding="utf-8")
        sys.stdout = _Tee(sys.stdout, fh)
        sys.stderr = _Tee(sys.stderr, fh)
        print(f"[{tag}] เริ่มทำงาน pid={os.getpid()} python={sys.version.split()[0]}")

        def _hook(t, v, tb):
            import traceback
            print("[พัง] " + "".join(traceback.format_exception(t, v, tb)))
        sys.excepthook = _hook
        return path
    except Exception:  # noqa: BLE001
        return None
