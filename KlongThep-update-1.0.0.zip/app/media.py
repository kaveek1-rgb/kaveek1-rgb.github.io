"""ยูทิลิตี้เกี่ยวกับไฟล์วิดีโอ - ตรวจ ffmpeg, สร้างไฟล์ proxy, ดึงภาพนิ่ง"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import cv2
import numpy as np

from . import config

BROWSER_OK = {".mp4", ".m4v", ".webm"}

# นามสกุลไฟล์ที่รับ — รวมของที่เครื่องบันทึกกล้องวงจรปิดยี่ห้อต่าง ๆ ส่งออกมา
#   .dav              Dahua / กล้องจีนส่วนใหญ่ (คอนเทนเนอร์ DHAV, ffmpeg อ่านได้)
#   .h264 .264 .h265 .265 .hevc  Hikvision และเครื่องบันทึกรุ่นเก่า (สตรีมดิบ ไม่มีเวลา ถือว่า 25 fps)
#   .asf .wmv         กล้อง IP บางยี่ห้อ / เครื่องบันทึกที่ส่งออกผ่าน Windows Media
#   .ts .mts .m2ts    เครื่องบันทึกที่ส่งออกเป็น MPEG-TS
#   .3gp .mov .mkv .avi .flv .mpg .mpeg .webm .m4v .mp4   ทั่วไป
VIDEO_EXTS = {".mp4", ".m4v", ".mov", ".mkv", ".avi", ".webm", ".ts", ".mts", ".m2ts", ".mpg", ".mpeg",
              ".wmv", ".asf", ".flv", ".3gp", ".dav", ".h264", ".264", ".h265", ".265", ".hevc"}
# นามสกุลที่ OpenCV มักเปิดไม่ได้ หรือเปิดได้แต่นับเฟรม/เวลาไม่ถูก -> แปลงเป็น mp4 ก่อนเสมอ
RAW_STREAM_EXTS = {".h264", ".264", ".h265", ".265", ".hevc"}
NORMALIZE_EXTS = RAW_STREAM_EXTS | {".dav", ".asf", ".wmv", ".ts", ".mts", ".m2ts", ".flv", ".3gp", ".mpg", ".mpeg"}


def ffmpeg_path() -> str | None:
    """หา ffmpeg จาก PATH ก่อน ถ้าไม่เจอก็ดูในโฟลเดอร์ ffmpeg\\bin ข้างโปรแกรม
    (ทำให้พกโปรแกรมไปทั้งโฟลเดอร์แล้วใช้ได้เลย ไม่ต้องติดตั้งอะไรในเครื่องปลายทาง)"""
    p = shutil.which("ffmpeg")
    if p:
        return p
    for cand in (config.ROOT / "ffmpeg" / "bin" / "ffmpeg.exe",
                 config.ROOT / "ffmpeg" / "ffmpeg.exe",
                 config.ROOT / "ffmpeg.exe"):
        if cand.exists():
            return str(cand)
    return None


def _probe_soft(path: str | Path) -> dict | None:
    """เหมือน probe แต่คืน None แทนการล้ม และตรวจว่าอ่านเฟรมแรกได้จริง"""
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return None
    try:
        ok, _ = cap.read()
        if not ok:
            return None
        fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    finally:
        cap.release()
    if not fps or fps != fps or fps > 240 or fps < 1:
        fps = 25.0
    if n <= 0 or w <= 0 or h <= 0:
        return None
    return {"fps": float(fps), "frame_count": n, "width": w, "height": h, "duration": n / fps}


def _run_ffmpeg(args: list[str], timeout: int) -> tuple[int, str]:
    ff = ffmpeg_path()
    if not ff:
        return 127, "ไม่พบ ffmpeg"
    try:
        r = subprocess.run([ff, "-y", "-loglevel", "error", "-nostdin", *args],
                           stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return r.returncode, (r.stderr or b"").decode("utf-8", "replace").strip()[-300:]
    except subprocess.TimeoutExpired:
        return 124, "ใช้เวลานานเกินไป"
    except Exception as exc:  # noqa: BLE001
        return 1, str(exc)


def prepare_source(path: str | Path, on_status=None) -> tuple[str, dict]:
    """คืน (ไฟล์ที่โปรแกรมอ่านได้, ข้อมูลวิดีโอ)

    ไฟล์จากเครื่องบันทึกกล้องวงจรปิดมักเป็นรูปแบบที่ OpenCV เปิดไม่ได้ (.dav ของ Dahua,
    .h264 ดิบของ Hikvision) หรือเปิดได้แต่นับจำนวนเฟรมไม่ถูก ทำให้แถบความคืบหน้าและ
    เวลาเพี้ยน จึงแปลงเป็น mp4 ก่อนหนึ่งครั้ง โดยพยายาม "ย้ายกล่อง" (remux, ไม่เสียคุณภาพ
    ใช้เวลาไม่กี่วินาที) ก่อน ถ้าไม่ได้ค่อยถอดรหัสใหม่ ไฟล์ที่แปลงเก็บไว้ใน data/proxy
    ไฟล์ต้นฉบับไม่ถูกแตะ
    """
    path = str(path)
    ext = Path(path).suffix.lower()
    info = None if ext in NORMALIZE_EXTS else _probe_soft(path)
    if info is not None:
        return path, info

    ff = ffmpeg_path()
    if not ff:
        raise SystemExit(f"เปิดไฟล์วิดีโอไม่ได้: {path}\n  ไฟล์ชนิดนี้ต้องใช้ ffmpeg แปลงก่อน แต่ยังไม่ได้ติดตั้ง ffmpeg (ดู README ข้อ 1)")

    config.ensure_dirs()
    import hashlib
    key = hashlib.sha1(path.encode("utf-8", "surrogateescape")).hexdigest()[:12]
    out = config.DIR_PROXY / f"src_{key}.mp4"
    if out.exists() and out.stat().st_size > 0:
        info = _probe_soft(out)
        if info is not None:
            return str(out), info

    in_opts: list[str] = []
    if ext in RAW_STREAM_EXTS:
        # สตรีมดิบไม่มีเวลาฝังอยู่ ffmpeg ต้องรู้ fps ก่อนอ่าน — เครื่องบันทึกส่วนใหญ่ใช้ 25
        in_opts = ["-framerate", "25"]
    if on_status:
        on_status("กำลังแปลงไฟล์จากเครื่องบันทึกให้อ่านได้ (ครั้งเดียว)")
    print(f"[กล้องเทพ] ไฟล์ {Path(path).name} เป็นรูปแบบจากเครื่องบันทึก กำลังแปลงเป็น mp4 (ครั้งเดียว)")

    # 1) ย้ายกล่องอย่างเดียว ไม่ถอดรหัส — เร็วและไม่เสียคุณภาพ
    rc, err = _run_ffmpeg([*in_opts, "-fflags", "+genpts", "-i", path, "-map", "0:v:0", "-an", "-sn", "-dn",
                           "-c:v", "copy", "-tag:v", "hvc1" if ext in (".h265", ".265", ".hevc") else "avc1",
                           "-movflags", "+faststart", str(out)], timeout=60 * 60)
    info = _probe_soft(out) if rc == 0 else None
    if info is None:
        # 2) ถอดรหัสใหม่ทั้งไฟล์ (ช้ากว่า แต่รับได้ทุกอย่างที่ ffmpeg อ่านออก)
        if on_status:
            on_status("กำลังถอดรหัสไฟล์ใหม่ทั้งไฟล์ (ไฟล์ชนิดนี้ย้ายกล่องตรง ๆ ไม่ได้)")
        rc, err = _run_ffmpeg([*in_opts, "-fflags", "+genpts", "-i", path, "-map", "0:v:0", "-an", "-sn", "-dn",
                               "-vsync", "cfr", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                               "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out)], timeout=60 * 180)
        info = _probe_soft(out) if rc == 0 else None
    if info is None:
        try:
            out.unlink()
        except OSError:
            pass
        raise SystemExit(f"เปิดไฟล์วิดีโอไม่ได้: {path}\n  ffmpeg: {err or 'ไม่ทราบสาเหตุ'}\n"
                         "  ลองส่งออกจากเครื่องบันทึกเป็น mp4 หรือ avi แทน")
    print(f"           แปลงแล้ว: {out.name} ({info['width']}x{info['height']} {info['fps']:.0f} fps, "
          f"{info['duration'] / 60:.1f} นาที)")
    return str(out), info


def probe(path: str | Path) -> dict:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise SystemExit(f"เปิดไฟล์วิดีโอไม่ได้: {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
    if not fps or fps != fps or fps > 240:
        fps = 25.0
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    cap.release()
    return {"fps": float(fps), "frame_count": n, "width": w, "height": h,
            "duration": (n / fps) if (n and fps) else 0.0}


def needs_proxy(path: str | Path) -> bool:
    return Path(path).suffix.lower() not in BROWSER_OK


def readable(v) -> str:
    """ไฟล์ที่ควรใช้อ่านภาพของวิดีโอนี้: ไฟล์ที่แปลงแล้ว > ต้นฉบับ"""
    keys = v.keys() if hasattr(v, "keys") else []
    for k in ("src_path", "proxy_path"):
        if k in keys and v[k] and Path(v[k]).exists():
            return str(v[k])
    return str(v["path"])


def make_proxy(path: str | Path, video_id: int, max_width: int = 1280) -> str | None:
    """แปลงเป็น mp4/H.264 ที่เบราว์เซอร์เล่นและเลื่อนหาตำแหน่งได้"""
    ff = ffmpeg_path()
    if not ff:
        return None
    config.ensure_dirs()
    out = config.DIR_PROXY / f"{video_id}.mp4"
    if out.exists() and out.stat().st_size > 0:
        return str(out)
    cmd = [
        ff, "-y", "-loglevel", "error", "-i", str(path),
        "-vf", f"scale='min({max_width},iw)':-2",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "26",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-an",
        str(out),
    ]
    try:
        subprocess.run(cmd, check=True, timeout=60 * 90)
    except Exception as exc:  # noqa: BLE001
        print(f"[เตือน] สร้างไฟล์ proxy ไม่สำเร็จ: {exc}")
        return None
    return str(out)


def grab_frame(path: str | Path, sec: float) -> bytes | None:
    """ดึงภาพนิ่ง ณ วินาทีที่ระบุ (ใช้ทำภาพพื้นหลังให้ผู้ใช้วาดพื้นที่)"""
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return None
    try:
        cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, float(sec)) * 1000.0)
        ok, frame = cap.read()
        if not ok:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, frame = cap.read()
        if not ok:
            return None
        ok, enc = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        return enc.tobytes() if ok else None
    finally:
        cap.release()


_NVENC_OK: bool | None = None


def nvenc_available() -> bool:
    """การ์ดจอ NVIDIA เข้ารหัส H.264 ได้เอง (NVENC) ไหม — เช็คครั้งเดียวต่อโปรเซส

    ทดสอบด้วยการเข้ารหัสภาพเปล่า 1 เฟรมจริง ๆ เพราะ ffmpeg อาจมี h264_nvenc ในรายการ
    แต่ไดรเวอร์ในเครื่องใช้ไม่ได้ (ไดรเวอร์เก่า, ไม่มีการ์ด NVIDIA, ใช้ผ่าน Remote Desktop)
    """
    global _NVENC_OK
    if _NVENC_OK is not None:
        return _NVENC_OK
    ff = ffmpeg_path()
    if not ff:
        _NVENC_OK = False
        return False
    try:
        r = subprocess.run(
            [ff, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=black:s=256x256:r=25",
             "-frames:v", "2", "-c:v", "h264_nvenc", "-f", "null", "-"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        _NVENC_OK = (r.returncode == 0)
    except Exception:  # noqa: BLE001
        _NVENC_OK = False
    return _NVENC_OK


class FrameWriter:
    """เขียนวิดีโอออก - ใช้ ffmpeg ถ้ามี (ได้ H.264 ที่เบราว์เซอร์เล่นได้)
    ถ้าไม่มีจะถอยไปใช้ OpenCV ซึ่งได้ mp4v ที่เบราว์เซอร์ส่วนใหญ่เล่นไม่ได้

    encoder: "auto" = ใช้การ์ดจอ (NVENC) ถ้ามี ไม่งั้น libx264 | "nvenc" | "x264"
    """

    def __init__(self, path: str | Path, width: int, height: int, fps: float,
                 encoder: str = "auto"):
        self.path = str(path)
        self.width, self.height, self.fps = int(width), int(height), float(fps)
        self.proc = None
        self.writer = None
        self.encoder = "opencv"
        ff = ffmpeg_path()
        if ff:
            use_nvenc = (encoder == "nvenc") or (encoder == "auto" and nvenc_available())
            if use_nvenc:
                codec = ["-c:v", "h264_nvenc", "-preset", "p4", "-tune", "hq",
                         "-rc", "vbr", "-cq", "23", "-b:v", "0"]
                self.encoder = "nvenc"
            else:
                # veryfast ที่ 1280px ได้หลายร้อยเฟรม/วินาทีบนซีพียูสมัยใหม่ ไม่ใช่คอขวดหลัก
                codec = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23"]
                self.encoder = "x264"
            cmd = [
                ff, "-y", "-loglevel", "error",
                "-f", "rawvideo", "-pix_fmt", "bgr24",
                "-s", f"{self.width}x{self.height}", "-r", f"{self.fps}",
                "-i", "-",
                *codec,
                "-pix_fmt", "yuv420p", "-movflags", "+faststart",
                self.path,
            ]
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                         bufsize=self.width * self.height * 3 * 4,
                                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            self.writer = cv2.VideoWriter(self.path, fourcc, self.fps, (self.width, self.height))

    def write(self, frame) -> None:
        if self.proc is not None:
            # ส่งหน่วยความจำของเฟรมตรง ๆ ไม่ต้องคัดลอกเป็น bytes ก่อน (ประหยัดราว 10% ของเวลาเรนเดอร์)
            if not frame.flags["C_CONTIGUOUS"]:
                frame = np.ascontiguousarray(frame)
            try:
                self.proc.stdin.write(memoryview(frame))
            except (BrokenPipeError, OSError):
                raise RuntimeError(self._error("ffmpeg หยุดทำงานกลางคัน"))
        else:
            self.writer.write(frame)

    def _error(self, what: str) -> str:
        msg = ""
        try:
            msg = (self.proc.stderr.read() or b"").decode("utf-8", "replace").strip()[-400:]
        except Exception:  # noqa: BLE001
            pass
        return f"{what} ({self.encoder}): {msg}"

    def close(self) -> None:
        if self.proc is not None:
            try:
                self.proc.stdin.close()
            except Exception:  # noqa: BLE001
                pass
            rc = self.proc.wait(timeout=300)
            if rc != 0:
                raise RuntimeError(self._error("เข้ารหัสวิดีโอไม่สำเร็จ"))
        elif self.writer is not None:
            self.writer.release()
