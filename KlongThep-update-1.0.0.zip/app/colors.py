"""จำแนกสีเด่นของวัตถุเป็นชื่อสีภาษาไทย

วิธี: แปลงเป็น HSV เอาเฉพาะพิกเซลในมาสก์ แล้วโหวตทีละพิกเซล
เรียบง่ายแต่ใช้งานได้จริงกับภาพวงจรปิด และเร็วพอที่จะทำทุกเฟรม
"""
from __future__ import annotations

import numpy as np

# ชื่อสี -> ช่วง Hue (OpenCV: 0-179)
HUE_BANDS = [
    ("แดง", 0, 8),
    ("ส้ม", 8, 22),
    ("เหลือง", 22, 34),
    ("เขียว", 34, 78),
    ("ฟ้า", 78, 100),
    ("น้ำเงิน", 100, 128),
    ("ม่วง", 128, 150),
    ("ชมพู", 150, 170),
    ("แดง", 170, 180),
]

ORDER = ["ดำ", "ขาว", "เทา", "แดง", "ส้ม", "เหลือง", "น้ำตาล", "เขียว",
         "ฟ้า", "น้ำเงิน", "ม่วง", "ชมพู"]

SWATCH = {  # สีตัวอย่างสำหรับแสดงบนหน้าเว็บ (hex)
    "ดำ": "#1b1f24", "ขาว": "#f2f4f7", "เทา": "#8a929c", "แดง": "#c0392b",
    "ส้ม": "#e07b2a", "เหลือง": "#e2c044", "น้ำตาล": "#8a5a2b", "เขียว": "#3f8f52",
    "ฟ้า": "#4aa3d8", "น้ำเงิน": "#2e4f9e", "ม่วง": "#7a4f9c", "ชมพู": "#d76e9a",
}


def _label_pixels(hsv: np.ndarray) -> np.ndarray:
    """คืน array ของชื่อสี (เป็นดัชนีใน ORDER) ต่อพิกเซล"""
    h = hsv[:, 0].astype(np.int16)
    s = hsv[:, 1].astype(np.int16)
    v = hsv[:, 2].astype(np.int16)

    out = np.full(h.shape, ORDER.index("เทา"), dtype=np.int16)

    # ไม่มีสี: ตัดสินจากความสว่าง
    out[v < 55] = ORDER.index("ดำ")
    out[(v >= 55) & (s < 45) & (v < 175)] = ORDER.index("เทา")
    out[(s < 45) & (v >= 175)] = ORDER.index("ขาว")

    chroma = (s >= 45) & (v >= 55)
    for name, lo, hi in HUE_BANDS:
        sel = chroma & (h >= lo) & (h < hi)
        out[sel] = ORDER.index(name)

    # น้ำตาล = ส้ม/แดงที่มืดหรือซีด
    brownish = chroma & (h < 25) & ((v < 130) | (s < 110))
    out[brownish] = ORDER.index("น้ำตาล")
    return out


def dominant(patch_bgr: np.ndarray, mask: np.ndarray | None = None) -> str:
    """สีเด่นของภาพชิ้นส่วนหนึ่งชิ้น"""
    import cv2

    if patch_bgr is None or patch_bgr.size == 0:
        return ""
    small = patch_bgr
    if max(small.shape[:2]) > 64:
        scale = 64.0 / max(small.shape[:2])
        small = cv2.resize(small, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        if mask is not None and mask.size:
            mask = cv2.resize(mask, (small.shape[1], small.shape[0]), interpolation=cv2.INTER_NEAREST)

    hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV).reshape(-1, 3)
    if mask is not None and mask.size:
        keep = mask.reshape(-1) > 0
        if keep.sum() >= 12:
            hsv = hsv[keep]
    if hsv.shape[0] == 0:
        return ""

    labels = _label_pixels(hsv)
    counts = np.bincount(labels, minlength=len(ORDER)).astype(float)

    # ลดน้ำหนักสีกลาง ๆ เพื่อให้สีจริงของเสื้อผ้าชนะเงาและถนน
    for name, w in (("เทา", 0.45), ("ดำ", 0.6), ("ขาว", 0.75)):
        counts[ORDER.index(name)] *= w
    if counts.sum() <= 0:
        return ""
    return ORDER[int(counts.argmax())]


def upper_lower(patch_bgr: np.ndarray, mask: np.ndarray | None = None) -> tuple[str, str]:
    """สีท่อนบน / ท่อนล่าง (ใช้กับคน) - ตัดหัวออก 15% แล้วแบ่งครึ่ง"""
    if patch_bgr is None or patch_bgr.size == 0:
        return "", ""
    h = patch_bgr.shape[0]
    if h < 24:
        c = dominant(patch_bgr, mask)
        return c, c
    top = int(h * 0.18)
    mid = int(h * 0.55)
    m_up = mask[top:mid] if mask is not None and mask.size else None
    m_lo = mask[mid:] if mask is not None and mask.size else None
    return dominant(patch_bgr[top:mid], m_up), dominant(patch_bgr[mid:], m_lo)


def vote(names: list[str]) -> str:
    """โหวตสีจากหลายเฟรม"""
    names = [n for n in names if n]
    if not names:
        return ""
    uniq: dict[str, int] = {}
    for n in names:
        uniq[n] = uniq.get(n, 0) + 1
    return max(uniq.items(), key=lambda kv: kv[1])[0]
