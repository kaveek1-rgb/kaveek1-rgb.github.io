"""ตัวกรองความเคลื่อนไหว - ตัดสินว่าเฟรมนี้ควรส่งให้ AI ตรวจหรือไม่

ภาพวงจรปิดส่วนใหญ่คือถนนว่าง ตอนตีสามอาจมีรถผ่านจริงแค่ 6 นาทีจาก 30 นาที
การส่งทุกเฟรมเข้า YOLO จึงเป็นการเผาเวลาการ์ดจอไปกับภาพที่ไม่มีอะไรเลย
ตัวนี้เทียบภาพกับพื้นหลังที่ค่อย ๆ สะสมไว้ ถ้าแทบไม่ต่างก็ข้ามเฟรมนั้น

ราคาของการเช็คอยู่ที่หลักไมโครวินาทีบน CPU เทียบกับการตรวจด้วย YOLO
ที่ใช้หลักสิบมิลลิวินาทีบน GPU จึงคุ้มแม้จะข้ามได้แค่ส่วนน้อย

กฎความปลอดภัย - ยอมตรวจเกินดีกว่าพลาดวัตถุ
  1. ระหว่างที่ยังมีวัตถุถูกติดตามอยู่ ห้ามข้ามเด็ดขาด (ผู้เรียกเป็นคนบังคับ)
  2. ต่อให้ภาพนิ่งสนิท ก็ยังตรวจทุก ๆ heartbeat วินาที กันวัตถุที่ค่อย ๆ
     โผล่มาจนกลายเป็นส่วนหนึ่งของพื้นหลังไปแล้ว
  3. ช่วงต้นคลิปตรวจทุกเฟรมจนกว่าพื้นหลังจะนิ่ง
  4. เมื่อเริ่มเห็นความเคลื่อนไหวแล้ว ให้ตรวจต่อเนื่องอีกพักหนึ่ง (cooldown)
     ห้ามสลับเปิดปิดถี่ ๆ เพราะตอนวัตถุเพิ่งโผล่ที่ขอบภาพมันยังเล็กมาก
     ถ้าปล่อยให้กระพริบ ตัวติดตามจะมองว่าเป็นวัตถุคนละตัว วัตถุหนึ่งคัน
     จะถูกบันทึกเป็นสองรายการ ซึ่งทำให้ผลค้นหาเพี้ยน
"""
from __future__ import annotations

import cv2
import numpy as np

WORK_W = 320          # ความกว้างที่ใช้เทียบ เล็กพอให้เร็ว ใหญ่พอให้เห็นรถไกล ๆ
WARMUP = 8            # กี่ครั้งแรกที่ตรวจทุกเฟรมเพื่อสร้างพื้นหลัง
ALPHA = 0.02          # ความเร็วที่พื้นหลังไล่ตามภาพจริง (ยิ่งน้อยยิ่งจำนาน)


class MotionGate:
    def __init__(self, cfg: dict, fps: float, stride: int):
        d = cfg["detector"]
        self.enabled = bool(d.get("motion_gate", True))
        self.thresh = int(d.get("motion_threshold", 18))
        self.min_ratio = float(d.get("motion_min_ratio", 0.0006))
        hb = float(d.get("motion_heartbeat_sec", 2.0))
        cd = float(d.get("motion_cooldown_sec", 2.0))
        # นับเป็นจำนวนครั้งที่ถูกเรียก ไม่ใช่จำนวนเฟรมในไฟล์
        self.heartbeat = max(1, int(round(hb * fps / max(1, stride))))
        self.cooldown = max(1, int(round(cd * fps / max(1, stride))))
        self.hot = 0
        self.bg: np.ndarray | None = None
        self.calls = 0
        self.since_detect = 0
        self.skipped = 0
        self.last_ratio = 0.0

    def _small(self, frame: np.ndarray) -> np.ndarray:
        h, w = frame.shape[:2]
        if w > WORK_W:
            s = WORK_W / float(w)
            frame = cv2.resize(frame, (WORK_W, max(1, int(round(h * s)))),
                               interpolation=cv2.INTER_AREA)
        g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return cv2.GaussianBlur(g, (5, 5), 0)

    def should_detect(self, frame: np.ndarray) -> bool:
        """อัปเดตพื้นหลังเสมอ แล้วบอกว่าเฟรมนี้ควรตรวจไหม"""
        if not self.enabled:
            return True
        g = self._small(frame)
        self.calls += 1

        if self.bg is None:
            self.bg = g.astype(np.float32)
            self.since_detect = 0
            self.hot = self.cooldown
            return True

        diff = cv2.absdiff(g, cv2.convertScaleAbs(self.bg))
        moved = int(np.count_nonzero(diff > self.thresh))
        self.last_ratio = moved / float(g.size)
        cv2.accumulateWeighted(g, self.bg, ALPHA)

        self.since_detect += 1
        busy = self.last_ratio >= self.min_ratio
        if busy:
            self.hot = self.cooldown          # เห็นความเคลื่อนไหว -> ตรวจต่ออีกพัก
        elif self.hot > 0:
            self.hot -= 1
        due = self.since_detect >= self.heartbeat
        if self.calls <= WARMUP or busy or self.hot > 0 or due:
            self.since_detect = 0
            return True
        self.skipped += 1
        return False

    def summary(self) -> dict:
        return {
            "checked": self.calls,
            "skipped": self.skipped,
            "skipped_pct": round(100.0 * self.skipped / max(1, self.calls), 1),
        }
