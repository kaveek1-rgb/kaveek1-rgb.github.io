"""ชั้นตรวจจับ + ติดตามวัตถุ — Ultralytics YOLO รุ่น -seg (ได้รูปทรงวัตถุ) + ตัวติดตาม ByteTrack"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from . import config


@dataclass
class Det:
    track_id: int
    cls_id: int
    cls: str
    conf: float
    box: tuple[int, int, int, int]      # x1,y1,x2,y2 พิกัดต้นฉบับ
    mask: np.ndarray | None = None      # ขนาดเท่ากล่อง ค่า 0/255 หรือ None


class BaseTracker:
    name = "base"
    has_masks = False

    def _check_tracker(self, path: str) -> str:
        """ถ้า ultralytics รุ่นที่ติดตั้งไม่รองรับตัวติดตามในไฟล์นี้ ให้ถอยไปใช้ตัวมาตรฐาน

        ระบบนี้ต้องรันบนเครื่องของ สภ. ที่เราไปตามแก้ทีหลังไม่ได้
        การพังตอนเริ่มประมวลผลเพราะไลบรารีคนละรุ่น เป็นสิ่งที่ยอมรับไม่ได้
        ยอมทำงานแบบเดิมดีกว่าทำงานไม่ได้เลย
        """
        try:
            import yaml as _yaml
            from pathlib import Path as _P
            if not _P(path).exists():
                return path
            with open(path, "r", encoding="utf-8") as fh:
                want = _yaml.safe_load(fh) or {}
            kind = str(want.get("tracker_type", "bytetrack"))
            from ultralytics.cfg import TRACKER_MAP  # type: ignore
            supported = set(TRACKER_MAP)
        except Exception:  # noqa: BLE001
            try:
                from pathlib import Path as _P2
                import ultralytics as _u
                d = _P2(_u.__file__).parent / "cfg" / "trackers"
                supported = {p.stem for p in d.glob("*.yaml")}
            except Exception:  # noqa: BLE001
                return path
        if kind in supported:
            return path
        fb = config.TRACKER_DIR / "klongthep.yaml"
        fb = str(fb) if fb.exists() else "bytetrack.yaml"
        print(f"[เตือน] ultralytics รุ่นนี้ไม่รองรับตัวติดตาม '{kind}' จึงใช้ {fb} แทน")
        return fb

    def update(self, frame: np.ndarray, frame_idx: int) -> list[Det]:
        raise NotImplementedError


# --------------------------------------------------------------------- YOLO
class YoloTracker(BaseTracker):
    def __init__(self, cfg: dict):
        from ultralytics import YOLO  # นำเข้าตอนใช้จริงเท่านั้น

        # ultralytics ส่งสถิติการใช้งานออกอินเทอร์เน็ตโดยอัตโนมัติ
        # ระบบนี้ทำงานกับภาพวงจรปิดของราชการ จึงต้องปิดตั้งแต่ต้น
        try:
            from ultralytics import settings as _ul
            if _ul.get("sync", True):
                _ul.update({"sync": False})
        except Exception:  # noqa: BLE001
            pass

        d = cfg["detector"]
        # ชื่อโมเดลที่เป็นเส้นทางสัมพัทธ์ ให้อ้างจากโฟลเดอร์โปรแกรมเสมอ
        # จะได้รันจากที่ไหนก็ได้ ส่วนชื่อเปล่า ๆ ปล่อยให้ ultralytics ดาวน์โหลดเอง
        mpath = str(d["model"])
        want_at = None
        if ("/" in mpath or "\\" in mpath) and not Path(mpath).is_absolute():
            cand = config.ROOT / mpath
            if cand.exists():
                mpath = str(cand)
            else:
                # ยังไม่มีไฟล์ ใช้ชื่อเปล่าเพื่อให้ ultralytics ดาวน์โหลดให้ครั้งเดียว
                print(f"[กล้องเทพ] ยังไม่มี {mpath} — กำลังดาวน์โหลดโมเดล (ครั้งเดียว)")
                want_at, mpath = cand, Path(mpath).name
        try:
            self.model = YOLO(mpath)
        except Exception as exc:  # noqa: BLE001
            # เครื่องที่ สภ. มักไม่มีอินเทอร์เน็ต ถ้าไฟล์โมเดลหายจะดาวน์โหลดไม่ได้
            # ต้องบอกให้ชัดว่าต้องไปเอาไฟล์อะไรมาวางที่ไหน ไม่ใช่โยน traceback ยาว ๆ
            raise SystemExit(
                f"โหลดโมเดล {d['model']} ไม่ได้ ({type(exc).__name__}: {exc})\n"
                f"  ถ้าไม่มีไฟล์: ดาวน์โหลด {Path(mpath).name} จากเครื่องที่มีอินเทอร์เน็ต "
                f"แล้วก๊อปมาวางที่ {config.DIR_MODELS}\n"
                "  ถ้ามีไฟล์แต่เปิดไม่ได้: ไฟล์อาจเสีย ให้ดาวน์โหลดใหม่")
        if want_at is not None:      # ย้ายไฟล์ที่เพิ่งโหลดมาเก็บให้เป็นระเบียบ
            got = Path(mpath)
            if got.exists():
                try:
                    want_at.parent.mkdir(parents=True, exist_ok=True)
                    got.replace(want_at)
                except OSError:
                    pass
        self.name = str(d["model"])
        self.has_masks = "-seg" in str(d["model"]).lower()
        self.conf = float(d["conf"])
        self.iou = float(d["iou"])
        self.imgsz = int(d["imgsz"])
        # ไฟล์ตั้งค่าตัวติดตาม ถ้าเป็นเส้นทางในโปรเจกต์ให้อ้างจากโฟลเดอร์โปรแกรม
        # จะได้รันจากที่ไหนก็เจอ ไม่ต้องพึ่ง cwd
        tk = str(d.get("tracker", "bytetrack.yaml"))
        cand = config.PKG / tk
        if not cand.exists():
            cand = config.TRACKER_DIR / Path(tk).name       # เผื่อเขียน path แบบเดิม
        self.tracker_yaml = str(cand) if cand.exists() else tk
        self.tracker_yaml = self._check_tracker(self.tracker_yaml)

        # โมเดลที่ฝึกเองเป็นรุ่นตรวจจับกรอบ ไม่มีรูปทรงวัตถุ
        # ถ้าตั้ง mask_model ไว้ จะรันโมเดล -seg เพิ่มอีกตัวเพื่อเอารูปทรงมาใช้กับวิดีโอย่อ
        # แลกกับเวลาประมวลผลที่เพิ่มขึ้นเกือบเท่าตัว
        self.seg = None
        mm = str(d.get("mask_model") or "").strip()
        if mm and not self.has_masks:
            mp = config.ROOT / mm
            try:
                self.seg = YOLO(str(mp) if mp.exists() else mm)
                self.has_masks = True
                print(f"[กล้องเทพ] ใช้ {mm} ช่วยหารูปทรงวัตถุ")
            except Exception as exc:  # noqa: BLE001
                print(f"[เตือน] โหลด mask_model ไม่ได้ ({exc}) จะใช้กรอบสี่เหลี่ยมแทน")

        dev = str(d.get("device", "auto"))
        if dev == "auto":
            try:
                import torch

                dev = "0" if torch.cuda.is_available() else "cpu"
            except Exception:  # noqa: BLE001
                dev = "cpu"
        self.device = dev

        # ครึ่งความละเอียด (FP16) บนการ์ดจอ NVIDIA ให้ผลเท่าเดิมในทางปฏิบัติ
        # แต่เร็วขึ้นราว 1.5-2 เท่า ส่วน CPU ต้องใช้ FP32 เท่านั้น
        #
        # ชื่อพารามิเตอร์ของ ultralytics เปลี่ยนไปตามรุ่น รุ่นเก่าใช้ half=True
        # รุ่นใหม่เลิกใช้แล้วเปลี่ยนเป็น quantize=16 ถ้าส่งชื่อผิดรุ่นจะเตือนรัว
        # หรือพังไปเลย จึงต้องถามไลบรารีก่อนว่ารุ่นที่ติดตั้งอยู่รับชื่อไหน
        self.fast_kwargs: dict = {}
        if bool(d.get("half", True)) and dev not in ("cpu", "mps"):
            try:
                from ultralytics.cfg import DEFAULT_CFG_DICT as _D
                if "quantize" in _D:
                    self.fast_kwargs = {"quantize": 16}
                elif "half" in _D:
                    self.fast_kwargs = {"half": True}
            except Exception:  # noqa: BLE001
                self.fast_kwargs = {}

        names = self.model.names  # {id: name}
        wanted = set(cfg["detector"].get("classes") or [])
        self.class_ids = (
            sorted(i for i, n in names.items() if n in wanted) if wanted else None
        )
        self.names = names

    def update(self, frame: np.ndarray, frame_idx: int) -> list[Det]:
        res = self.model.track(
            frame,
            persist=True,
            conf=self.conf,
            iou=self.iou,
            imgsz=self.imgsz,
            classes=self.class_ids,
            tracker=self.tracker_yaml,
            device=self.device,
            verbose=False,
            **self.fast_kwargs,
        )
        if not res:
            return []
        r = res[0]
        if r.boxes is None or r.boxes.id is None:
            return []

        H, W = frame.shape[:2]
        xyxy = r.boxes.xyxy.cpu().numpy()
        ids = r.boxes.id.cpu().numpy().astype(int)
        clss = r.boxes.cls.cpu().numpy().astype(int)
        confs = r.boxes.conf.cpu().numpy()

        # รูปทรงวัตถุมาได้สองทาง: จากโมเดลหลักถ้าเป็นรุ่น -seg
        # หรือจากโมเดลรูปทรงแยกต่างหาก ซึ่งต้องจับคู่กับกรอบเองด้วย seg_boxes
        masks, seg_boxes = None, None
        if r.masks is not None:
            masks = r.masks.data.cpu().numpy()          # n x h x w (0/1)
        elif self.seg is not None:
            masks, seg_boxes = self._seg_masks(frame)

        out: list[Det] = []
        for i in range(len(ids)):
            x1, y1, x2, y2 = [int(round(v)) for v in xyxy[i]]
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(W, x2), min(H, y2)
            if x2 - x1 < 2 or y2 - y1 < 2:
                continue
            m = None
            mi = i
            if seg_boxes is not None:
                mi = self._best_mask(seg_boxes, (x1, y1, x2, y2))
            if masks is not None and mi is not None and mi < masks.shape[0]:
                mm = masks[mi]
                if mm.shape[:2] != (H, W):
                    mm = cv2.resize(mm.astype(np.float32), (W, H), interpolation=cv2.INTER_LINEAR)
                m = (mm[y1:y2, x1:x2] > 0.5).astype(np.uint8) * 255
            out.append(
                Det(
                    track_id=int(ids[i]),
                    cls_id=int(clss[i]),
                    cls=str(self.names.get(int(clss[i]), str(clss[i]))),
                    conf=float(confs[i]),
                    box=(x1, y1, x2, y2),
                    mask=m,
                )
            )
        return out

    def _seg_masks(self, frame: np.ndarray):
        """รันโมเดลรูปทรงแยกต่างหาก คืนมาสก์ทั้งหมดพร้อมกรอบของมัน"""
        try:
            sr = self.seg.predict(frame, imgsz=self.imgsz, conf=max(0.10, self.conf * 0.7),
                                  device=self.device, verbose=False)[0]
        except Exception:  # noqa: BLE001
            return None, None
        if sr.masks is None or sr.boxes is None or not len(sr.boxes):
            return None, None
        return sr.masks.data.cpu().numpy(), sr.boxes.xyxy.cpu().numpy()

    @staticmethod
    def _best_mask(seg_boxes: np.ndarray, box) -> int | None:
        """จับคู่กรอบจากโมเดลหลักกับรูปทรงจากโมเดลรูปทรง ด้วยพื้นที่ซ้อนทับ"""
        x1, y1, x2, y2 = box
        bx1 = np.maximum(seg_boxes[:, 0], x1)
        by1 = np.maximum(seg_boxes[:, 1], y1)
        bx2 = np.minimum(seg_boxes[:, 2], x2)
        by2 = np.minimum(seg_boxes[:, 3], y2)
        inter = np.clip(bx2 - bx1, 0, None) * np.clip(by2 - by1, 0, None)
        area_a = max(1.0, (x2 - x1) * (y2 - y1))
        area_b = ((seg_boxes[:, 2] - seg_boxes[:, 0]) * (seg_boxes[:, 3] - seg_boxes[:, 1]))
        iou = inter / np.maximum(area_a + area_b - inter, 1e-6)
        j = int(iou.argmax())
        return j if iou[j] > 0.35 else None


def build(cfg: dict) -> BaseTracker:
    try:
        return YoloTracker(cfg)
    except ImportError as exc:
        raise SystemExit(
            "ไม่พบ ultralytics — ติดตั้งด้วย  pip install ultralytics\n"
            f"(รายละเอียด: {exc})"
        ) from exc
