/* กล้องเทพ — ตรรกะหน้าเว็บทั้งหมด (ไม่ใช้ไลบรารีภายนอก ทำงานแบบออฟไลน์ได้) */
"use strict";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const CLS_TH = {
  person: "คน", bicycle: "จักรยาน", car: "รถยนต์", motorcycle: "รถจักรยานยนต์",
  bus: "รถบัส", truck: "รถบรรทุก", dog: "สุนัข", cat: "แมว",
};
const CLS_COLOR = {
  person: "#e7b263", bicycle: "#b58ada", car: "#6fb0e0", motorcycle: "#79bfa0",
  bus: "#f0908a", truck: "#dcc46e", dog: "#a9b6c4", cat: "#a9b6c4",
};
const COLOR_SW = {
  "ดำ": "#1b1f24", "ขาว": "#f2f4f7", "เทา": "#8a929c", "แดง": "#c0392b",
  "ส้ม": "#e07b2a", "เหลือง": "#e2c044", "น้ำตาล": "#8a5a2b", "เขียว": "#3f8f52",
  "ฟ้า": "#4aa3d8", "น้ำเงิน": "#2e4f9e", "ม่วง": "#7a4f9c", "ชมพู": "#d76e9a",
};

const ALL = "all";                     // ค่าพิเศษของ videoId ที่แปลว่า "ทุกกล้อง"
const S = {
  videoId: null, video: null, summary: null, timeline: null, allMode: false,
  classes: new Set(), colors: new Set(), direction: null, roi: null, line: null,
  upColors: new Set(), loColors: new Set(), paths: null, pathHit: null,
  results: [], syn: null, sel: null,
};

/* ------------------------------------------------------------------ utils */
function currentUser() {
  try { return localStorage.getItem("klongthep_user") || ""; } catch (e) { return ""; }
}

async function api(url, body) {
  const headers = { "X-User": encodeURIComponent(currentUser() || "ไม่ระบุชื่อ") };
  const opt = body
    ? { method: "POST", headers: Object.assign({ "Content-Type": "application/json" }, headers),
        body: JSON.stringify(body) }
    : { headers };
  const r = await fetch(url, opt);
  if (!r.ok) throw new Error((await r.text()) || r.statusText);
  return r.json();
}
const pad = (n) => String(Math.floor(n)).padStart(2, "0");
function ampm(clockStr) {
  // "2026-09-03 14:13:10" -> "2:13 PM" (รูปแบบเดียวกับ BriefCam)
  const part = String(clockStr || "").trim().split(" ").pop();
  const p = part.split(":");
  if (p.length < 2) return "";
  const h = Number(p[0]);
  if (!Number.isFinite(h)) return "";
  return `${h % 12 || 12}:${p[1]} ${h < 12 ? "AM" : "PM"}`;
}
function hms(sec) {
  sec = Math.max(0, sec || 0);
  return `${pad(sec / 3600)}:${pad((sec % 3600) / 60)}:${pad(sec % 60)}`;
}
function parseHMS(str) {
  if (!str) return null;
  const p = String(str).trim().split(":").map(Number);
  if (p.some(isNaN)) return null;
  if (p.length === 3) return p[0] * 3600 + p[1] * 60 + p[2];
  if (p.length === 2) return p[0] * 60 + p[1];
  return p[0];
}
function absStr(epochSec) {
  const d = new Date(epochSec * 1000);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
         `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function absEpoch(str) {
  if (!str) return null;
  const t = Date.parse(String(str).trim().replace(" ", "T"));
  return isNaN(t) ? null : t / 1000;
}

function toast(msg, bad) {
  const bar = $("#ingestBar");
  bar.hidden = false;
  bar.textContent = msg;
  bar.style.color = bad ? "var(--crit)" : "";
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { bar.hidden = true; bar.style.color = ""; }, 6000);
}

/* --------------------------------------------------------------- เริ่มระบบ */
function askUser(force) {
  const cur = currentUser();
  if (cur && !force) { $("#whoBtn").textContent = cur; return Promise.resolve(); }
  $("#userModal").hidden = false;
  const nm = $("#userName"), rl = $("#userRole");
  if (force && cur) {
    const m = cur.match(/^(.*?)(?:\s+\((.*)\))?$/);
    nm.value = (m && m[1]) || ""; rl.value = (m && m[2]) || "";
  }
  nm.focus();
  return new Promise((resolve) => {
    const save = () => {
      const name = nm.value.trim();
      if (!name) { nm.focus(); return; }
      const role = rl.value.trim();
      const who = role ? `${name} (${role})` : name;
      try { localStorage.setItem("klongthep_user", who); } catch (e) { }
      $("#whoBtn").textContent = who;
      $("#userModal").hidden = true;
      resolve();
    };
    $("#userSave").onclick = save;
    nm.onkeydown = rl.onkeydown = (e) => { if (e.key === "Enter") save(); };
  });
}

async function init() {
  await askUser(false);
  try {
    const h = await api("/api/health");
    $("#health").textContent =
      `${h.model} · ${h.gpu} · ffmpeg ${h.ffmpeg ? "พร้อม" : "ไม่พบ"}`;
  } catch (e) { /* ไม่สำคัญ */ }
  await loadVideos();
  bindUI();
  pollIngest();
}

async function loadVideos(opts = {}) {
  const vids = await api("/api/videos");
  const sel = $("#videoSel");
  sel.innerHTML = "";
  if (!vids.length) {
    sel.innerHTML = '<option value="">— ยังไม่มีวิดีโอ กด “เพิ่มวิดีโอ” —</option>';
    S.videoId = null;
    $("#gridEmpty").hidden = false;
    $("#gridEmpty").textContent = "ยังไม่มีวิดีโอในระบบ — กด “+ เพิ่มวิดีโอ” เพื่อเริ่ม";
    return;
  }
  const ready = vids.filter((v) => v.status === "done");
  if (ready.length > 1) {
    const o = document.createElement("option");
    o.value = ALL;
    o.textContent = `— ทุกกล้อง (${ready.length} ตัว) —`;
    sel.appendChild(o);
  }
  for (const v of vids) {
    const o = document.createElement("option");
    o.value = v.id;
    const st = v.status === "done" ? `${v.n_tubes || 0} วัตถุ`
      : v.status === "processing" ? `กำลังประมวลผล ${Math.round((v.progress || 0) * 100)}%`
      : v.status === "queued" ? "รอคิว"
      : v.status === "interrupted" ? "ถูกขัดจังหวะ — กดทำต่อได้"
      : v.status;
    o.textContent = `${v.name}  —  ${st}`;
    sel.appendChild(o);
  }
  // ถ้ากำลังดูวิดีโอตัวไหนอยู่ ให้อยู่ที่เดิม (แค่อัปเดตรายการ) ไม่เด้งไปตัวอื่นและไม่ล้างผลค้นหา
  const keep = opts.keep && S.videoId != null &&
    (S.allMode || vids.some((v) => v.id === S.videoId && v.status === "done"));
  if (keep) {
    sel.value = S.allMode ? ALL : String(S.videoId);
    return;
  }
  const done = vids.find((v) => v.status === "done") || vids[0];
  sel.value = String(done.id);
  await selectVideo(done.id);
}

async function selectVideo(id) {
  S.allMode = String(id) === ALL;
  S.videoId = S.allMode ? ALL : Number(id);
  S.syn = null;
  S.roi = null;
  S.line = null;
  S.paths = null; S.pathHit = null;
  $("#roiInfo").textContent = "";
  $("#lineInfo").textContent = "";
  $("#pathBase").removeAttribute("src");
  $("#synBox").hidden = true;
  $("#synEmpty").hidden = false;
  $("#t0").value = ""; $("#t1").value = "";

  if (S.allMode) {
    S.summary = await api("/api/all/summary");
    S.video = null;
  } else {
    S.summary = await api(`/api/videos/${S.videoId}/summary`);
    S.video = S.summary.video;
  }
  applyMode();
  buildChips();
  renderSummary();
  await loadTimeline();
  await doSearch();
  if (!S.allMode) loadHeat();
}

/* ฟีเจอร์ที่ผูกกับภาพของกล้องตัวเดียว ใช้ในโหมดทุกกล้องไม่ได้
   (วิดีโอย่อต้องมีพื้นหลังเดียว, พื้นที่สนใจและภาพความหนาแน่นผูกกับมุมกล้อง) */
function applyMode() {
  const off = S.allMode;
  $("#btnSynopsis").disabled = off;
  $("#btnRoi").disabled = off;
  $("#btnLine").disabled = off;
  $("#modeNote").hidden = !off;
  $$(".tab").forEach((t) => {
    if (t.dataset.tab === "heat" || t.dataset.tab === "synopsis" || t.dataset.tab === "paths") {
      t.disabled = off;
      t.style.opacity = off ? ".4" : "";
      t.title = off ? "ใช้ได้เฉพาะตอนเลือกกล้องเดียว" : "";
    }
  });
  if (off && !$("#pane-results").hidden === false) switchTab("results");
  if (off) switchTab("results");
  $("#tlHint").textContent = off
    ? "ลากเพื่อเลือกช่วงเวลาจริง (ครอบคลุมทุกกล้อง)"
    : "ลากบนแถบไทม์ไลน์ด้านขวาเพื่อเลือกช่วงได้";
}

/* ------------------------------------------------------------------ chips */
function buildChips() {
  const cw = $("#clsChips");
  cw.innerHTML = "";
  for (const c of (S.summary.classes || [])) {
    const b = document.createElement("button");
    b.className = "chip" + (S.classes.has(c.cls) ? " on" : "");
    b.innerHTML = `<span class="dot" style="background:${CLS_COLOR[c.cls] || "#9aa"}"></span>` +
      `${CLS_TH[c.cls] || c.cls}<span class="n">${c.n}</span>`;
    b.onclick = () => { toggle(S.classes, c.cls); b.classList.toggle("on"); doSearch(); loadTimeline(); };
    cw.appendChild(b);
  }
  if (!cw.children.length) cw.innerHTML = '<span class="hint">ยังไม่มีข้อมูล</span>';

  const kw = $("#colorChips");
  kw.innerHTML = "";
  for (const c of (S.summary.colors || [])) {
    if (!c.color) continue;
    const b = document.createElement("button");
    b.className = "chip" + (S.colors.has(c.color) ? " on" : "");
    b.innerHTML = `<span class="sw" style="background:${COLOR_SW[c.color] || "#888"}"></span>` +
      `${c.color}<span class="n">${c.n}</span>`;
    b.onclick = () => { toggle(S.colors, c.color); b.classList.toggle("on"); doSearch(); };
    kw.appendChild(b);
  }
  if (!kw.children.length) kw.innerHTML = '<span class="hint">ยังไม่มีข้อมูล</span>';

  // สีเสื้อ/สีกางเกง ใช้รายการสีชุดเดียวกับด้านบน เพราะระบบรู้จักสีเท่านี้
  const palette = (S.summary.colors || []).map((c) => c.color).filter(Boolean);
  const build = (host, set) => {
    host.innerHTML = "";
    for (const c of palette) {
      const b = document.createElement("button");
      b.className = "chip" + (set.has(c) ? " on" : "");
      b.innerHTML = `<span class="sw" style="background:${COLOR_SW[c] || "#888"}"></span>${c}`;
      b.onclick = () => { toggle(set, c); b.classList.toggle("on"); doSearch(); };
      host.appendChild(b);
    }
    if (!host.children.length) host.innerHTML = '<span class="hint">ยังไม่มีข้อมูล</span>';
  };
  build($("#upChips"), S.upColors);
  build($("#loChips"), S.loColors);
}
function toggle(set, v) { set.has(v) ? set.delete(v) : set.add(v); }

function renderSummary() {
  const s = S.summary;
  if (S.allMode) {
    const cams = s.cameras || [];
    const cards = [
      ["กล้องในระบบ", s.n_cameras, "ที่ประมวลผลเสร็จแล้ว"],
      ["วัตถุทั้งหมด", (s.n_tubes || 0).toLocaleString(), "รวมทุกกล้อง"],
      ["อยู่ในภาพเฉลี่ย", `${(s.avg_duration || 0).toFixed(1)} วิ`, `นานสุด ${(s.max_duration || 0).toFixed(0)} วิ`],
    ];
    $("#summary").innerHTML = cards
      .map(([k, b, sm]) => `<div><em>${k}</em><b>${b}</b><small>${sm}</small></div>`).join("") +
      cams.map((c) => `<div><em>${c.name}</em><b>${(c.n || 0).toLocaleString()}</b>` +
        `<small>${c.started_at ? c.started_at.slice(0, 16) : "ไม่ทราบเวลา"}</small></div>`).join("");
    return;
  }
  const v = S.video || {};
  const cards = [
    ["วัตถุที่พบทั้งหมด", (s.n_tubes || 0).toLocaleString(), v.name || ""],
    ["ความยาววิดีโอ", `${((v.duration || 0) / 60).toFixed(1)} นาที`, v.started_at ? `เริ่ม ${v.started_at}` : "ไม่ทราบเวลาจริง"],
    ["อยู่ในภาพเฉลี่ย", `${(s.avg_duration || 0).toFixed(1)} วิ`, `นานสุด ${(s.max_duration || 0).toFixed(0)} วิ`],
  ];
  if (s.busiest) cards.push(["ช่วงที่คึกคักที่สุด", s.busiest.clock.split(" ").pop(), `${s.busiest.count} วัตถุใน 10 นาที`]);
  cards.push(["ตัวตรวจจับ", v.detector || "-", `ตรวจทุก ${v.stride || 1} เฟรม`]);
  $("#summary").innerHTML = cards
    .map(([k, b, sm]) => `<div><em>${k}</em><b>${b}</b><small>${sm}</small></div>`).join("");
}

/* --------------------------------------------------------------- timeline */
async function loadTimeline() {
  const cls = encodeURIComponent([...S.classes].join(","));
  if (S.allMode) {
    S.timeline = await api(`/api/all/timeline?bucket=0&classes=${cls}`);
    S.timeline.abs = true;
  } else {
    const dur = (S.video && S.video.duration) || 0;
    const bucket = Math.max(5, Math.round(dur / 400));
    S.timeline = await api(`/api/videos/${S.videoId}/timeline?bucket=${bucket}&classes=${cls}`);
    S.timeline.abs = false;
  }
  drawTimeline();
}

function drawTimeline() {
  const cv = $("#timeline"), tl = S.timeline;
  if (!tl) return;
  const dpr = window.devicePixelRatio || 1;
  const w = cv.clientWidth, h = 86;
  cv.width = w * dpr; cv.height = h * dpr;
  const g = cv.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);

  const counts = tl.counts || [];
  const n = counts.length || 1;
  const peak = Math.max(1, tl.peak || 1);
  const bw = w / n;

  g.fillStyle = "#19202a";
  g.fillRect(0, 0, w, h);

  for (let i = 0; i < n; i++) {
    const v = counts[i] / peak;
    const bh = Math.max(v > 0 ? 2 : 0, v * (h - 12));
    g.fillStyle = v > 0.66 ? "#e0a233" : v > 0.33 ? "#b3813f" : "#5d6b7a";
    g.fillRect(i * bw, h - bh - 4, Math.max(1, bw - 0.5), bh);
  }

  // ช่วงที่เลือกไว้
  const base = tl.abs ? absEpoch(tl.t_start) : 0;
  const t0 = tl.abs ? (absEpoch($("#t0").value) !== null ? absEpoch($("#t0").value) - base : null)
                    : parseHMS($("#t0").value);
  const t1 = tl.abs ? (absEpoch($("#t1").value) !== null ? absEpoch($("#t1").value) - base : null)
                    : parseHMS($("#t1").value);
  const dur = tl.duration || 1;
  if (t0 != null || t1 != null) {
    const a = ((t0 || 0) / dur) * w, b = ((t1 == null ? dur : t1) / dur) * w;
    g.fillStyle = "rgba(224,162,51,.16)";
    g.fillRect(a, 0, b - a, h);
    g.strokeStyle = "#e0a233"; g.lineWidth = 1;
    g.beginPath(); g.moveTo(a, 0); g.lineTo(a, h); g.moveTo(b, 0); g.lineTo(b, h); g.stroke();
  }

  const lab = (sec) => {
    if (tl.abs) {
      const d = new Date((base + sec) * 1000);
      const span = tl.duration || 0;
      if (span < 7200) return d.toTimeString().slice(0, 8);            // ไม่เกิน 2 ชม.
      if (span < 172800) return `${pad(d.getDate())}/${pad(d.getMonth() + 1)} ${d.toTimeString().slice(0, 5)}`;
      return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}`;            // หลายวัน
    }
    if (!tl.started_at) return hms(sec);
    const d = new Date(tl.started_at.replace(" ", "T"));
    d.setSeconds(d.getSeconds() + sec);
    return d.toTimeString().slice(0, 8);
  };
  $("#tlAxis").innerHTML = [0, 0.25, 0.5, 0.75, 1]
    .map((f) => `<span>${lab(f * dur)}</span>`).join("");
  $("#tlRange").textContent = (t0 != null || t1 != null)
    ? `เลือก ${lab(t0 || 0)} – ${lab(t1 == null ? dur : t1)}` : "แสดงทั้งหมด";
}

function bindTimelineDrag() {
  const cv = $("#timeline");
  let dragging = false, start = 0;
  const posToSec = (e) => {
    const r = cv.getBoundingClientRect();
    const f = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    return f * ((S.timeline && S.timeline.duration) || 0);
  };
  cv.addEventListener("mousedown", (e) => { dragging = true; start = posToSec(e); });
  cv.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const cur = posToSec(e);
    const tl = S.timeline || {};
    const lo = Math.min(start, cur), hi = Math.max(start, cur);
    if (tl.abs) {
      const base = absEpoch(tl.t_start) || 0;
      $("#t0").value = absStr(base + lo);
      $("#t1").value = absStr(base + hi);
    } else {
      $("#t0").value = hms(lo);
      $("#t1").value = hms(hi);
    }
    drawTimeline();
  });
  window.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    const tl = S.timeline || {};
    const a = tl.abs ? absEpoch($("#t0").value) : parseHMS($("#t0").value);
    const b = tl.abs ? absEpoch($("#t1").value) : parseHMS($("#t1").value);
    if (a === null || b === null || Math.abs(b - a) < 1) {
      $("#t0").value = ""; $("#t1").value = "";
    }
    drawTimeline(); doSearch();
  });
  window.addEventListener("resize", drawTimeline);
}

/* ----------------------------------------------------------------- ค้นหา */
function filters() {
  const f = { video_id: S.videoId, sort: $("#sortSel").value };
  if (S.classes.size) f.classes = [...S.classes];
  if (S.colors.size) f.colors = [...S.colors];
  if (S.allMode) {
    // โหมดทุกกล้องใช้เวลานาฬิกาจริง เพราะกล้องแต่ละตัวเริ่มบันทึกคนละเวลา
    if ($("#t0").value.trim()) f.abs_t0 = $("#t0").value.trim();
    if ($("#t1").value.trim()) f.abs_t1 = $("#t1").value.trim();
  } else {
    const t0 = parseHMS($("#t0").value), t1 = parseHMS($("#t1").value);
    if (t0 != null) f.t0 = t0;
    if (t1 != null) f.t1 = t1;
  }
  const md = parseFloat($("#minDur").value); if (md > 0) f.min_duration = md;
  const mh = parseFloat($("#minH").value); if (mh > 0) f.min_height = mh;
  const xh = parseFloat($("#maxH").value); if (xh > 0) f.max_height = xh;
  const ms = parseFloat($("#minSp").value); if (ms > 0) f.min_speed = ms;
  const xs = parseFloat($("#maxSp").value); if (xs > 0) f.max_speed = xs;
  if (S.upColors.size) f.upper_colors = [...S.upColors];
  if (S.loColors.size) f.lower_colors = [...S.loColors];
  if (S.line) f.line = S.line;
  if ($("#movingOnly").checked) f.moving_only = true;
  if (S.direction) f.direction = S.direction;
  if (S.roi) f.roi = S.roi;
  return f;
}

async function doSearch() {
  if (!S.videoId) return;
  const res = await api("/api/search", Object.assign(filters(), { limit: 400 }));
  S.results = res.items;
  $("#cnt").textContent = res.total.toLocaleString();
  const grid = $("#grid");
  grid.innerHTML = "";
  $("#gridEmpty").hidden = res.items.length > 0;
  if (!res.items.length) {
    $("#gridEmpty").textContent = "ไม่พบวัตถุที่ตรงเงื่อนไข ลองผ่อนตัวกรองดู";
    $("#gridNote").hidden = true;
    return;
  }
  // ป้ายจับคู่คนขับ — ทำให้เห็นทันทีว่าวัตถุนี้ไม่ได้มาลอย ๆ
  const groupBadge = (t) => {
    if (!t.group_role) return "";
    if (t.group_role === "vehicle") {
      const n = Math.max(1, (t.group_n || 2) - 1);
      return `<span class="badge-ride" title="ระบบจับคู่คนขับให้แล้ว">มีคนขับ ${n > 1 ? n + " คน" : ""}</span>`;
    }
    return `<span class="badge-ride rider" title="คนนี้อยู่บนรถ ไม่ได้เดินเท้า">อยู่บนรถ</span>`;
  };

  // เวลาบนการ์ดเดินตามตัวเลือก "ป้ายเวลาบนวัตถุ" เพื่อไม่ให้ตารางกับวิดีโอย่อ
  // อ่านคนละมาตรฐานแล้วสับสน
  const cardTime = (t) => {
    const clock = S.allMode ? (t.clock || "") : (t.clock || "").split(" ").pop();
    const inFile = hms(t.start_sec);
    const m = $("#timeMode") ? $("#timeMode").value : "clock";
    if (m === "file") return inFile;
    if (m === "ampm") return ampm(t.clock) || inFile;
    if (m === "both") return `${clock} · ${inFile}`;
    return clock;
  };

  // บอกให้ชัดเมื่อผลค้นหาเยอะกว่าที่แสดงอยู่
  const note = $("#gridNote");
  note.hidden = res.items.length >= res.total;
  if (!note.hidden) {
    note.textContent = `แสดง ${res.items.length.toLocaleString()} รายการแรก ` +
      `จากทั้งหมด ${res.total.toLocaleString()} รายการ — กรองให้แคบลงเพื่อดูให้ครบ`;
  }
  for (const t of res.items) {
    const el = document.createElement("div");
    el.className = "card";
    const col = [t.color_upper, t.color_lower].filter(Boolean).join("/") || t.color_main || "-";
    el.innerHTML =
      `<img class="thumb" loading="lazy" src="/api/tube/${t.id}/crop" alt=""` +
      ` onerror="this.style.visibility='hidden'">` +
      `<div class="meta">` +
      (S.allMode && t.video_name ? `<div class="cam" title="${t.video_name}">${t.video_name}</div>` : "") +
      `<div class="clock" title="เวลาจริง ${t.clock || "-"} · เวลาในไฟล์ ${hms(t.start_sec)}">${cardTime(t)}</div>` +
      `<div class="line"><span class="cls"><span class="dot" style="background:${CLS_COLOR[t.cls] || "#9aa"}"></span>${CLS_TH[t.cls] || t.cls}</span><span>${t.duration.toFixed(1)} วิ</span></div>` +
      `<div class="line"><span>${col}</span>${groupBadge(t)}</div>` +
      `</div>`;
    el.onclick = () => openPlayer(t);
    grid.appendChild(el);
  }
}

/* ----------------------------------------------- เล่นคลิปต้นฉบับ + เส้นทาง */
function fitBox(el, vw, vh) {
  const r = el.getBoundingClientRect();
  if (!vw || !vh) return { x: 0, y: 0, s: 1, w: r.width, h: r.height };
  const s = Math.min(r.width / vw, r.height / vh);
  return { x: (r.width - vw * s) / 2, y: (r.height - vh * s) / 2, s, w: r.width, h: r.height };
}

async function openPlayer(t) {
  const data = await api(`/api/tube/${t.id}/track`);
  const vid = data.video || {};
  const srcId = vid.id || t.video_id || S.videoId;
  const v = $("#srcVideo"), cv = $("#srcOverlay");
  $("#modal").hidden = false;
  $("#modalTitle").textContent =
    `${CLS_TH[t.cls] || t.cls} · ${t.clock} · อยู่ในภาพ ${t.duration.toFixed(1)} วินาที` +
    (vid.name ? `  ·  ${vid.name}` : "");
  $("#modalFoot").innerHTML =
    `<span>สีเด่น: ${t.color_main || "-"}</span>` +
    (t.cls === "person" ? `<span>เสื้อ: ${t.color_upper || "-"} / กางเกง: ${t.color_lower || "-"}</span>` : "") +
    `<span>ความเร็วเฉลี่ย: ${Math.round(t.speed_px)} พิกเซล/วินาที</span>` +
    `<span>ระยะทางในภาพ: ${Math.round(t.dist_px)} พิกเซล</span>` +
    `<span>เวลาในไฟล์: ${hms(t.start_sec)} – ${hms(t.end_sec)}</span>`;

  v.src = `/media/video/${srcId}`;
  const startAt = Math.max(0, t.start_sec - 1.5);
  const seek = () => { try { v.currentTime = startAt; } catch (e) { } v.play().catch(() => { }); };
  v.addEventListener("loadedmetadata", seek, { once: true });
  if (v.readyState >= 1) seek();

  const pts = data.points;
  const draw = () => {
    if ($("#modal").hidden) return;
    const dpr = window.devicePixelRatio || 1;
    const r = v.getBoundingClientRect();
    cv.width = r.width * dpr; cv.height = r.height * dpr;
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, r.width, r.height);
    const fb = fitBox(v, v.videoWidth, v.videoHeight);
    const sx = fb.s * (v.videoWidth / (vid.width || (S.video && S.video.width) || v.videoWidth || 1));

    // เส้นทางทั้งหมดของวัตถุ
    g.strokeStyle = "rgba(224,162,51,.55)"; g.lineWidth = 2;
    g.beginPath();
    pts.forEach((p, i) => {
      const X = fb.x + p.cx * sx, Y = fb.y + p.cy * sx;
      i ? g.lineTo(X, Y) : g.moveTo(X, Y);
    });
    g.stroke();

    // กรอบ ณ เวลาปัจจุบัน
    const cur = v.currentTime;
    let best = null, bd = 1e9;
    for (const p of pts) { const d = Math.abs(p.sec - cur); if (d < bd) { bd = d; best = p; } }
    if (best && bd < 1.0) {
      g.strokeStyle = "#e0a233"; g.lineWidth = 2;
      g.strokeRect(fb.x + best.x1 * sx, fb.y + best.y1 * sx,
        (best.x2 - best.x1) * sx, (best.y2 - best.y1) * sx);
    }
    requestAnimationFrame(draw);
  };
  requestAnimationFrame(draw);
}

function closeModal() {
  $("#modal").hidden = true;
  const v = $("#srcVideo"); v.pause(); v.removeAttribute("src"); v.load();
}

/* -------------------------------------------------------------- วิดีโอย่อ */
async function makeSynopsis() {
  if (!S.videoId) return;
  if (S.allMode) { toast("วิดีโอย่อต้องเลือกกล้องทีละตัว เพราะต้องใช้พื้นหลังของกล้องนั้น", true); return; }
  const btn = $("#btnSynopsis");
  btn.disabled = true;
  const bar = $("#synProgress");
  bar.hidden = false;
  const set = (p, m) => { bar.firstElementChild.style.width = `${Math.round(p * 100)}%`; bar.lastElementChild.textContent = m; };
  set(0.02, "กำลังส่งงาน…");
  try {
    const job = await api("/api/synopsis", {
      video_id: S.videoId, chrono: Number($("#chrono").value) / 100,
      time_mode: $("#timeMode").value,
      filters: filters(),
    });
    while (true) {
      await new Promise((r) => setTimeout(r, 900));
      const j = await api(`/api/job/${job.job_id}`);
      set(j.progress || 0, j.message || j.status);
      if (j.status === "done") { showSynopsis(j.result); break; }
      if (j.status === "error") { toast("สร้างวิดีโอย่อไม่สำเร็จ: " + j.message, true); break; }
    }
  } catch (e) {
    toast("เกิดข้อผิดพลาด: " + e.message, true);
  } finally {
    btn.disabled = false;
    setTimeout(() => { bar.hidden = true; }, 2500);
  }
}

function showSynopsis(res) {
  S.syn = res;
  switchTab("synopsis");
  $("#synEmpty").hidden = true;
  $("#synBox").hidden = false;
  const warn = $("#synWarn");
  if (res.truncated) {
    warn.hidden = false;
    warn.innerHTML =
      `<b>วิดีโอย่อนี้ไม่ครบ</b> ผลค้นหามี ${res.total_available.toLocaleString()} วัตถุ ` +
      `แต่แสดงได้ครั้งละไม่เกิน ${res.max_tubes.toLocaleString()} ตัว ` +
      `ระบบจึงสุ่มให้กระจายทั่วช่วงเวลาแทน<br>` +
      `<b>อย่าใช้วิดีโอนี้สรุปว่า “ไม่มีเหตุการณ์”</b> — ` +
      `ให้กรองให้แคบลงก่อน (เลือกประเภทวัตถุ เลือกช่วงเวลาให้สั้นลง ` +
      `หรือติ๊ก “เอาเฉพาะวัตถุที่เคลื่อนที่จริง”) แล้วสร้างใหม่ทีละช่วง`;
  } else {
    warn.hidden = true;
  }
  const src = res.source_duration || 0;
  $("#synMeta").innerHTML = [
    ["ย่อลง", `${res.compression}×`, res.compression >= 1.6 ? "เท่าของเวลาเดิม"
      : "ย่อได้น้อย — ลองติ๊ก “เอาเฉพาะวัตถุที่เคลื่อนที่จริง” แล้วสร้างใหม่"],
    ["ความยาว", `${res.duration} วิ`,
      `จากช่วง ${src >= 90 ? (src / 60).toFixed(1) + " นาที" : Math.round(src) + " วินาที"} ที่เลือก`],
    ["วัตถุ", res.n_tubes, "ตัวในวิดีโอเดียว"],
  ].map(([k, b, s]) => `<span><em>${k}</em><b>${b}</b>${s}</span>`).join("");

  const v = $("#synVideo");
  v.src = res.url;
  v.load();
  bindSynOverlay();
}

function bindSynOverlay() {
  const v = $("#synVideo"), cv = $("#synOverlay"), res = S.syn;
  const boxAt = (o, f) => {
    const b = o.boxes || [];
    if (!b.length) return null;
    let best = null, bd = 1e9;
    for (const e of b) { const d = Math.abs(e[0] - f); if (d < bd) { bd = d; best = e; } }
    return bd <= 8 ? best : null;
  };

  const draw = () => {
    if ($("#pane-synopsis").hidden || !S.syn) return;
    const dpr = window.devicePixelRatio || 1;
    const r = v.getBoundingClientRect();
    if (!r.width) { requestAnimationFrame(draw); return; }
    cv.width = r.width * dpr; cv.height = r.height * dpr;
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, r.width, r.height);
    const fb = fitBox(v, res.width, res.height);
    const f = Math.round(v.currentTime * res.fps);
    for (const o of res.objects) {
      if (f < o.out_start - 4 || f > o.out_end + 4) continue;
      const b = boxAt(o, f);
      if (!b) continue;
      g.strokeStyle = "rgba(224,162,51,.85)";
      g.lineWidth = S.sel === o.tube_id ? 3 : 1;
      g.strokeRect(fb.x + b[1] * fb.s, fb.y + b[2] * fb.s, b[3] * fb.s, b[4] * fb.s);
    }
    requestAnimationFrame(draw);
  };
  requestAnimationFrame(draw);

  // รับคลิกที่กรอบด้านนอก ไม่ใช่ที่ canvas
  // ถ้าดักที่ canvas มันจะทับแถบควบคุมของวิดีโอจนกดปุ่มเล่นไม่ได้
  const frame = cv.parentElement;
  frame.onclick = async (e) => {
    const r = v.getBoundingClientRect();
    if (e.clientY > r.bottom - 56) return;   // ปล่อยแถบควบคุมด้านล่างให้วิดีโอจัดการเอง
    const fb = fitBox(v, res.width, res.height);
    const x = (e.clientX - r.left - fb.x) / fb.s, y = (e.clientY - r.top - fb.y) / fb.s;
    const f = Math.round(v.currentTime * res.fps);
    let hit = null, area = 1e12;
    for (const o of res.objects) {
      if (f < o.out_start - 4 || f > o.out_end + 4) continue;
      const b = boxAt(o, f);
      if (!b) continue;
      if (x >= b[1] && x <= b[1] + b[3] && y >= b[2] && y <= b[2] + b[4] && b[3] * b[4] < area) {
        area = b[3] * b[4]; hit = { o, b };
      }
    }
    if (!hit) return;
    S.sel = hit.o.tube_id;
    v.pause();
    const t = S.results.find((r2) => r2.id === hit.o.tube_id);
    if (t) return openPlayer(t);
    const d = await api(`/api/tube/${hit.o.tube_id}/track`);
    openPlayer(Object.assign(d.tube, { clock: hms(d.tube.start_sec) }));
  };
}

/* --------------------------------------------------------------- heatmap */
function loadHeat() {
  if (!S.videoId || S.allMode) return;
  $("#heatBase").src = `/api/videos/${S.videoId}/still?sec=0&_=${Date.now()}`;
  $("#heatLayer").src = `/api/videos/${S.videoId}/heatmap?classes=${encodeURIComponent([...S.classes].join(","))}&_=${Date.now()}`;
}

/* ------------------------------------------------------------------- ROI */
function openRoi() {
  if (!S.videoId || S.allMode) return;
  $("#roiModal").hidden = false;
  const img = $("#roiImg");
  img.src = `/api/videos/${S.videoId}/still?sec=0&_=${Date.now()}`;
  const cv = $("#roiCanvas");
  let a = null, b = null, dragging = false;

  const redraw = () => {
    const r = img.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    cv.width = r.width * dpr; cv.height = r.height * dpr;
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, r.width, r.height);
    if (a && b) {
      g.fillStyle = "rgba(224,162,51,.18)";
      g.strokeStyle = "#e0a233"; g.lineWidth = 2;
      const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
      g.fillRect(x, y, Math.abs(b.x - a.x), Math.abs(b.y - a.y));
      g.strokeRect(x, y, Math.abs(b.x - a.x), Math.abs(b.y - a.y));
    }
  };
  const pt = (e) => {
    const r = cv.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  cv.onmousedown = (e) => { dragging = true; a = pt(e); b = a; redraw(); };
  cv.onmousemove = (e) => { if (dragging) { b = pt(e); redraw(); } };
  window.addEventListener("mouseup", () => { dragging = false; });
  img.onload = redraw;

  $("#roiClear").onclick = () => { a = b = null; S.roi = null; $("#roiInfo").textContent = ""; redraw(); };
  $("#roiDone").onclick = () => {
    if (a && b) {
      const r = cv.getBoundingClientRect();
      const x1 = Math.min(a.x, b.x) / r.width, x2 = Math.max(a.x, b.x) / r.width;
      const y1 = Math.min(a.y, b.y) / r.height, y2 = Math.max(a.y, b.y) / r.height;
      if (x2 - x1 > 0.01 && y2 - y1 > 0.01) {
        S.roi = [x1, y1, x2, y2];
        $("#roiInfo").textContent = `เลือกพื้นที่แล้ว (${Math.round((x2 - x1) * 100)}% × ${Math.round((y2 - y1) * 100)}% ของภาพ)`;
      }
    }
    $("#roiModal").hidden = true;
    doSearch();
  };
}

/* ------------------------------------------------------------ เพิ่มวิดีโอ */
async function browse(path) {
  const box = $("#browser");
  box.hidden = false;
  try {
    const d = await api(`/api/browse?path=${encodeURIComponent(path || "")}`);
    box.innerHTML =
      `<div class="dir" data-p="${d.parent}">📁 .. (ขึ้นบน)</div>` +
      d.dirs.map((x) => `<div class="dir" data-p="${x.path}">📁 ${x.name}</div>`).join("") +
      d.files.map((x) => `<div data-f="${x.path}">🎬 ${x.name} <span class="hint">${x.size_mb} MB</span></div>`).join("");
    $$("div", box).forEach((el) => {
      el.onclick = () => {
        if (el.dataset.p) browse(el.dataset.p);
        else { $("#addPath").value = el.dataset.f; }
      };
    });
  } catch (e) { box.innerHTML = `<div class="hint">${e.message}</div>`; }
}

/* เมื่อรันเป็นหน้าต่างโปรแกรม (pywebview) จะมี window.pywebview.api ให้เรียกหน้าต่างเลือกไฟล์ของ Windows จริง ๆ
   ตอนเปิดผ่านเบราว์เซอร์ธรรมดาไม่มีตัวนี้ ปุ่มจึงซ่อนไว้ และใช้ "เปิดดูโฟลเดอร์" แทน */
function bindDesktop() {
  const enable = () => {
    const api = window.pywebview && window.pywebview.api;
    if (!api || !api.pick_video) return;
    const b = $("#btnPick");
    b.hidden = false;
    b.onclick = async () => {
      try {
        const p = await api.pick_video();
        if (p) $("#addPath").value = p;
      } catch (e) { toast("เปิดหน้าต่างเลือกไฟล์ไม่ได้: " + e.message, true); }
    };
    document.body.classList.add("desktop");
  };
  if (window.pywebview && window.pywebview.api) enable();
  else window.addEventListener("pywebviewready", enable);
}

async function startIngest() {
  const path = $("#addPath").value.trim();
  if (!path) return toast("ใส่เส้นทางไฟล์ก่อน", true);
  try {
    await api("/api/ingest", { path, started_at: $("#addStart").value.trim() || null });
    $("#addModal").hidden = true;
    toast("เริ่มประมวลผลแล้ว — ดูความคืบหน้าที่แถบด้านบน");
    setTimeout(loadVideos, 2500);
  } catch (e) { toast("เริ่มไม่สำเร็จ: " + e.message, true); }
}

async function pollIngest() {
  let fails = 0;
  const bar = $("#ingestBar");
  setInterval(async () => {
    try {
      const vids = await api("/api/videos");
      fails = 0;
      const busy = vids.filter((v) => v.status === "processing");
      const queued = vids.filter((v) => v.status === "queued");
      const stuck = vids.filter((v) => v.status === "interrupted");
      const parts = [];
      for (const v of busy) {
        parts.push(`<span>⏳ ${v.name}: ${Math.round((v.progress || 0) * 100)}% — ${v.message || ""}</span>`);
      }
      for (const v of queued) parts.push(`<span>🕓 ${v.name}: ${v.message || "รอคิว"}</span>`);
      for (const v of stuck) {
        parts.push(`<span>⚠️ ${v.name}: ${v.message || "ถูกขัดจังหวะ"} ` +
          `<button class="btn mini" onclick="resumeIngest(${v.id})">ทำต่อ</button></span>`);
      }
      if (parts.length) {
        bar.hidden = false;
        bar.style.color = "";
        bar.innerHTML = parts.join("");
      } else if (bar.textContent.includes("⏳") || bar.textContent.includes("🕓") || bar.textContent.includes("⚠️")) {
        // งานเพิ่งเสร็จ: ซ่อนแถบและ "ล้างข้อความ" ด้วย ไม่งั้นเงื่อนไขนี้จะเป็นจริงทุก 3 วินาที
        // แล้วโหลดรายการวิดีโอซ้ำไม่รู้จบ ซึ่งไปรีเซ็ตหน้าจอ (วิดีโอย่อที่เพิ่งสร้างหายไปทันที)
        bar.hidden = true;
        bar.innerHTML = "";
        loadVideos({ keep: true });
      }
    } catch (e) {
      // ล้มเป็นครั้งคราวไม่เป็นไร แต่ถ้าล้มติดกันหลายครั้งแปลว่าโปรแกรมด้านหลังปิดไปแล้ว
      fails += 1;
      if (fails >= 5) {
        bar.hidden = false;
        bar.style.color = "var(--crit)";
        bar.textContent = "ติดต่อโปรแกรมไม่ได้ — หน้าต่างดำอาจถูกปิดไป ให้เปิด run.bat ใหม่แล้วกด Ctrl+F5";
      }
    }
  }, 3000);
}

async function resumeIngest(id) {
  try {
    const r = await api(`/api/videos/${id}/resume`, {});
    toast(r.message || "กำลังทำต่อ");
  } catch (e) { toast("ทำต่อไม่ได้: " + e.message, true); }
}
window.resumeIngest = resumeIngest;

/* --------------------------------------------------- แก้เวลาเริ่มบันทึก */
function openTime() {
  if (!S.videoId) return;
  if (S.allMode) { toast("เลือกกล้องที่ต้องการแก้เวลาก่อน", true); return; }
  const v = S.video || {};
  $("#timeVal").value = v.started_at || "";
  $("#timeNow").innerHTML = [
    ["ไฟล์", v.name || "-"],
    ["เวลาที่ใช้อยู่ตอนนี้", v.started_at || "ไม่ได้ตั้งไว้ (แสดงเป็นเวลานับจากต้นคลิป)"],
    ["ความยาว", `${((v.duration || 0) / 60).toFixed(1)} นาที`],
  ].map(([k, x]) => `<div><span>${k}</span><span>${x}</span></div>`).join("");
  $("#timeModal").hidden = false;
}

async function saveTime() {
  const btn = $("#timeSave");
  btn.disabled = true;
  try {
    const r = await api(`/api/videos/${S.videoId}/started_at`,
      { started_at: $("#timeVal").value.trim() });
    $("#timeModal").hidden = true;
    toast(`แก้เวลาเริ่มบันทึกเป็น ${r.started_at || "ไม่ระบุ"} แล้ว`);
    await loadVideos();
    if (S.syn) { S.syn = null; $("#synBox").hidden = true; $("#synEmpty").hidden = false; }
  } catch (e) {
    toast("แก้เวลาไม่สำเร็จ: " + e.message, true);
  } finally { btn.disabled = false; }
}


/* ------------------------------------------- เส้นทางการเคลื่อนที่ (Path) */
async function loadPaths() {
  if (!S.videoId || S.allMode) return;
  const img = $("#pathBase");
  if (!img.getAttribute("src")) {
    img.src = `/api/videos/${S.videoId}/still?sec=0&_=${Date.now()}`;
  }
  try {
    S.paths = await api("/api/paths", Object.assign(filters(), { limit: 400 }));
  } catch (e) {
    toast("ดึงเส้นทางไม่สำเร็จ: " + e.message, true); return;
  }
  const w = $("#pathWarn");
  w.hidden = !S.paths.truncated;
  if (S.paths.truncated) {
    w.textContent = `วัตถุตรงตัวกรอง ${S.paths.total_available.toLocaleString()} ตัว ` +
      `แต่วาดได้ครั้งละ ${S.paths.max_paths} เส้น (สุ่มให้กระจายทั่วช่วงเวลาแล้ว) — ` +
      `กรองให้แคบลงเพื่อดูให้ครบ`;
  }
  $("#pathMeta").textContent = `${S.paths.items.length.toLocaleString()} เส้นทาง`;
  drawPaths();
}

/* ภาพถูกจัดด้วย object-fit:contain จึงมักมีขอบดำซ้าย-ขวาหรือบน-ล่าง
   ถ้าคิดสเกลจากกล่องของ <img> ตรง ๆ เส้นจะเลื่อนออกจากถนนทันที
   ตัวนี้คืนกรอบของ "ภาพจริง" ภายในกล่อง พร้อมออฟเซ็ตของขอบดำ */
function fitRect(img, W, H) {
  const r = img.getBoundingClientRect();
  W = W || img.naturalWidth || 1;
  H = H || img.naturalHeight || 1;
  const boxAR = r.width / Math.max(1, r.height), imgAR = W / Math.max(1, H);
  let dw, dh;
  if (imgAR > boxAR) { dw = r.width; dh = r.width / imgAR; }
  else { dh = r.height; dw = r.height * imgAR; }
  return { r, ox: (r.width - dw) / 2, oy: (r.height - dh) / 2, dw, dh,
           sx: dw / W, sy: dh / H };
}

function pathScale() {
  const img = $("#pathBase");
  const W = S.paths && S.paths.width ? S.paths.width : 0;
  const H = S.paths && S.paths.height ? S.paths.height : 0;
  return fitRect(img, W, H);
}

function drawPaths() {
  if (!S.paths) return;
  const cv = $("#pathCanvas");
  const { r, sx, sy, ox, oy } = pathScale();
  const dpr = window.devicePixelRatio || 1;
  cv.width = Math.max(1, r.width * dpr); cv.height = Math.max(1, r.height * dpr);
  cv.style.width = r.width + "px"; cv.style.height = r.height + "px";
  const g = cv.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, r.width, r.height);
  const arrows = $("#pathArrows").checked, dots = $("#pathDots").checked;

  const drawOne = (it, hot) => {
    const p = it.pts;
    if (!p || p.length < 2) return;
    const col = CLS_COLOR[it.cls] || "#9aa";
    g.lineWidth = hot ? 4 : 1.8;
    g.strokeStyle = hot ? "#e0a233" : col;
    g.globalAlpha = hot ? 1 : 0.75;
    g.lineJoin = g.lineCap = "round";
    g.beginPath();
    g.moveTo(ox + p[0][0] * sx, oy + p[0][1] * sy);
    for (let i = 1; i < p.length; i++) g.lineTo(ox + p[i][0] * sx, oy + p[i][1] * sy);
    g.stroke();

    if (dots) {
      g.globalAlpha = hot ? 1 : 0.85;
      g.fillStyle = "#7ecb8f";                       // จุดเขียว = จุดเริ่ม
      g.beginPath(); g.arc(ox + p[0][0] * sx, oy + p[0][1] * sy, hot ? 5 : 3, 0, 7); g.fill();
      g.fillStyle = "#e0645a";                       // จุดแดง = จุดสุดท้าย
      const e = p[p.length - 1];
      g.beginPath(); g.arc(ox + e[0] * sx, oy + e[1] * sy, hot ? 5 : 3, 0, 7); g.fill();
    }
    if (arrows) {
      const a = p[p.length - 2], b = p[p.length - 1];
      const ang = Math.atan2((b[1] - a[1]) * sy, (b[0] - a[0]) * sx);
      const L = hot ? 14 : 9;
      const bx = ox + b[0] * sx, by = oy + b[1] * sy;
      g.globalAlpha = hot ? 1 : 0.85;
      g.fillStyle = hot ? "#e0a233" : col;
      g.beginPath();
      g.moveTo(bx, by);
      g.lineTo(bx - L * Math.cos(ang - 0.42), by - L * Math.sin(ang - 0.42));
      g.lineTo(bx - L * Math.cos(ang + 0.42), by - L * Math.sin(ang + 0.42));
      g.closePath(); g.fill();
    }
    if (hot) {
      g.globalAlpha = 1;
      const lbl = (it.clock || "").split(" ").pop();
      g.font = "12px ui-monospace, monospace";
      const tw = g.measureText(lbl).width;
      const tx = Math.min(r.width - tw - 8, ox + p[0][0] * sx + 6),
            ty = Math.max(14, oy + p[0][1] * sy - 6);
      g.fillStyle = "rgba(0,0,0,.72)";
      g.fillRect(tx - 3, ty - 12, tw + 6, 16);
      g.fillStyle = "#e0a233";
      g.fillText(lbl, tx, ty);
    }
    g.globalAlpha = 1;
  };

  for (const it of S.paths.items) if (it !== S.pathHit) drawOne(it, false);
  if (S.pathHit) drawOne(S.pathHit, true);
}

/* หาเส้นที่ใกล้เมาส์ที่สุด โดยวัดระยะจากจุดถึงแต่ละท่อนของเส้น */
function pathAt(mx, my) {
  if (!S.paths) return null;
  const { sx, sy, ox, oy } = pathScale();
  let best = null, bestD = 12;                        // ไกลเกิน 12 พิกเซลถือว่าไม่ได้ชี้
  for (const it of S.paths.items) {
    const p = it.pts;
    for (let i = 1; i < p.length; i++) {
      const x1 = ox + p[i - 1][0] * sx, y1 = oy + p[i - 1][1] * sy;
      const x2 = ox + p[i][0] * sx, y2 = oy + p[i][1] * sy;
      const dx = x2 - x1, dy = y2 - y1;
      const L2 = dx * dx + dy * dy;
      let t = L2 ? ((mx - x1) * dx + (my - y1) * dy) / L2 : 0;
      t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(mx - (x1 + t * dx), my - (y1 + t * dy));
      if (d < bestD) { bestD = d; best = it; }
    }
  }
  return best;
}

function bindPaths() {
  const cv = $("#pathCanvas");
  const box = $("#pathHover");
  cv.onmousemove = (e) => {
    const r = cv.getBoundingClientRect();
    const hit = pathAt(e.clientX - r.left, e.clientY - r.top);
    if (hit !== S.pathHit) { S.pathHit = hit; drawPaths(); }
    if (hit) {
      box.hidden = false;
      box.innerHTML = `<b>${CLS_TH[hit.cls] || hit.cls}</b> · ${hit.clock || ""} · ` +
        `อยู่ในภาพ ${(hit.duration || 0).toFixed(1)} วิ` +
        (hit.color ? ` · สี${hit.color}` : "") +
        ` · ${Math.round(hit.speed || 0)} พิกเซล/วินาที`;
      box.style.left = Math.round(e.clientX - r.left + 12) + "px";
      box.style.top = Math.round(e.clientY - r.top + 12) + "px";
      cv.style.cursor = "pointer";
    } else { box.hidden = true; cv.style.cursor = "default"; }
  };
  cv.onmouseleave = () => { box.hidden = true; S.pathHit = null; drawPaths(); };
  cv.onclick = () => {
    if (!S.pathHit) return;
    const t = S.results.find((x) => x.id === S.pathHit.id);
    openPlayer(t || Object.assign({}, S.pathHit, { video_id: S.videoId }));
  };
  $("#pathArrows").onchange = drawPaths;
  $("#pathDots").onchange = drawPaths;
  $("#pathReload").onclick = loadPaths;
  $("#pathBase").onload = drawPaths;
  window.addEventListener("resize", () => { if (!$("#pane-paths").hidden) drawPaths(); });
}

/* -------------------------------------------- ลากเส้นทาง (เส้นสะดุด) */
function openLine() {
  if (!S.videoId || S.allMode) { toast("เลือกกล้องเดียวก่อนจึงลากเส้นได้", true); return; }
  $("#lineModal").hidden = false;
  const img = $("#lineImg");
  img.src = `/api/videos/${S.videoId}/still?sec=0&_=${Date.now()}`;
  const cv = $("#lineCanvas");
  let a = null, b = null, dragging = false;

  const redraw = () => {
    const r = img.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    cv.width = Math.max(1, r.width * dpr); cv.height = Math.max(1, r.height * dpr);
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, r.width, r.height);
    if (a && b) {
      g.strokeStyle = "#e0a233"; g.lineWidth = 3; g.lineCap = "round";
      g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
      g.fillStyle = "#e0a233";
      for (const p of [a, b]) { g.beginPath(); g.arc(p.x, p.y, 5, 0, 7); g.fill(); }
    }
  };
  const pt = (e) => {
    const r = cv.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  cv.onmousedown = (e) => { dragging = true; a = pt(e); b = a; redraw(); };
  cv.onmousemove = (e) => { if (dragging) { b = pt(e); redraw(); } };
  window.addEventListener("mouseup", () => { dragging = false; });
  img.onload = redraw;

  $("#lineClear").onclick = () => {
    a = b = null; S.line = null; $("#lineInfo").textContent = ""; redraw();
  };
  $("#lineDone").onclick = () => {
    if (a && b) {
      const f = fitRect(img, 0, 0);
      const cl = (v) => Math.max(0, Math.min(1, v));
      const L = Math.hypot(b.x - a.x, b.y - a.y);
      if (L > 12) {
        S.line = [cl((a.x - f.ox) / f.dw), cl((a.y - f.oy) / f.dh),
                  cl((b.x - f.ox) / f.dw), cl((b.y - f.oy) / f.dh)];
        $("#lineInfo").textContent = "ตั้งเส้นแล้ว — แสดงเฉพาะวัตถุที่ข้ามเส้นนี้";
      }
    }
    $("#lineModal").hidden = true;
    doSearch();
    if (!$("#pane-paths").hidden) loadPaths();
  };
}

/* ------------------------------------------------------------- ลบวิดีโอ */
function mb(n) { return (n / 1048576).toFixed(1) + " MB"; }

async function openDelete() {
  if (!S.videoId) return;
  if (S.allMode) { toast("เลือกกล้องที่ต้องการลบก่อน (โหมดทุกกล้องลบไม่ได้)", true); return; }
  try {
    const u = await api(`/api/videos/${S.videoId}/usage`);
    $("#delInfo").innerHTML = [
      ["ไฟล์", u.name],
      ["วัตถุที่วิเคราะห์ไว้", u.n_tubes.toLocaleString() + " รายการ"],
      ["ไฟล์ที่ระบบสร้าง", u.n_files.toLocaleString() + " ไฟล์"],
      ["พื้นที่ที่จะได้คืน", mb(u.bytes)],
    ].map(([k, v]) => `<div><span>${k}</span><span>${v}</span></div>`).join("");
    $("#delPath").textContent = u.path + (u.source_exists ? "" : "  (หาไฟล์ไม่เจอแล้ว)");
    $("#delModal").hidden = false;
  } catch (e) { toast("อ่านข้อมูลไม่ได้: " + e.message, true); }
}

async function doDelete() {
  const btn = $("#delConfirm");
  btn.disabled = true;
  try {
    const r = await api(`/api/videos/${S.videoId}/delete`, {});
    $("#delModal").hidden = true;
    toast(`ลบ ${r.name} แล้ว — คืนพื้นที่ ${mb(r.freed)}`);
    S.videoId = null; S.syn = null;
    S.classes.clear(); S.colors.clear(); S.direction = null; S.roi = null;
    $("#synBox").hidden = true; $("#synEmpty").hidden = false;
    $("#grid").innerHTML = ""; $("#cnt").textContent = "0";
    await loadVideos();
  } catch (e) {
    toast("ลบไม่สำเร็จ: " + e.message, true);
  } finally { btn.disabled = false; }
}

/* ----------------------------------------------------------- สอนโมเดล */
const DS = { frame: null, boxes: [], cls: 0, classes: [], sel: -1, drag: null, busy: false };
const DS_COLORS = ["#e7b263", "#b58ada", "#6fb0e0", "#79bfa0",
                   "#f0908a", "#dcc46e", "#a9b6c4", "#8fd2c8"];

async function dsStats() {
  try {
    const st = await api("/api/dataset/stats");
    DS.classes = st.classes || [];
    $("#dsCnt").textContent = st.pending;
    const pct = st.target ? Math.min(100, Math.round(st.done / st.target * 100)) : 0;
    $("#dsStats").innerHTML = [
      ["ติดป้ายแล้ว", st.done.toLocaleString(), `${st.boxes.toLocaleString()} กรอบ`],
      ["รอติดป้าย", st.pending.toLocaleString(), "ภาพในคิว"],
      ["ความคืบหน้า", pct + "%", `เป้าหมาย ${st.target} ภาพ`],
    ].map(([k, b, s2]) => `<div><em>${k}</em><b>${b}</b><small>${s2}</small></div>`).join("");
    return st;
  } catch (e) { return null; }
}

function dsClassBar() {
  $("#dsClasses").innerHTML = DS.classes.map((n, i) =>
    `<button data-i="${i}" class="${i === DS.cls ? "on" : ""}" ` +
    `style="border-color:${i === DS.cls ? DS_COLORS[i % 8] : ""}">` +
    `<span class="k">${i + 1}</span>${CLS_TH[n] || n}</button>`).join("");
  $$("#dsClasses button").forEach((b) => {
    b.onclick = () => {
      const i = Number(b.dataset.i);
      DS.cls = i;
      if (DS.sel >= 0) DS.boxes[DS.sel].cls = i;
      dsClassBar(); dsDraw();
    };
  });
}

async function dsNext() {
  const f = await api("/api/dataset/next");
  const st = await dsStats();
  if (f.done) {
    $("#dsBox").hidden = true;
    $("#dsEmpty").hidden = false;
    $("#dsEmpty").innerHTML = (st && st.done)
      ? `ติดป้ายครบทุกภาพในคิวแล้ว (${st.done} ภาพ)<br>` +
        "เก็บภาพเพิ่มจากกล้องอื่น หรือกด “ส่งออกชุดข้อมูล” แล้วสั่งฝึกโมเดลด้วย <code>สอนโมเดล.bat</code>"
      : "ยังไม่มีภาพในคิว — เลือกกล้องที่แถบบน แล้วกด “เก็บภาพจากกล้องที่เลือก”";
    return;
  }
  DS.frame = f;
  DS.boxes = (f.boxes || []).map((b) => ({ ...b }));
  DS.sel = -1;
  $("#dsEmpty").hidden = true;
  $("#dsBox").hidden = false;
  $("#dsWhere").textContent =
    `${f.video_name || "กล้อง " + f.video_id} · เฟรม ${f.frame} · ${hms(f.sec || 0)}`;
  dsClassBar();
  const img = $("#dsImg");
  img.onload = dsDraw;
  img.src = `/api/dataset/image/${f.id}?_=${Date.now()}`;
}

function dsFit() {
  const img = $("#dsImg");
  return fitBox(img, img.naturalWidth || 1, img.naturalHeight || 1);
}

function dsDraw() {
  const img = $("#dsImg"), cv = $("#dsCanvas");
  const r = img.getBoundingClientRect();
  if (!r.width) return;
  const dpr = window.devicePixelRatio || 1;
  cv.width = r.width * dpr; cv.height = r.height * dpr;
  const g = cv.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, r.width, r.height);
  const fb = dsFit();
  const P = (x, y) => [fb.x + x * fb.s, fb.y + y * fb.s];

  DS.boxes.forEach((b, i) => {
    const [X, Y] = P(b.x1, b.y1);
    const w = (b.x2 - b.x1) * fb.s, h = (b.y2 - b.y1) * fb.s;
    const col = DS_COLORS[(b.cls || 0) % 8];
    g.lineWidth = i === DS.sel ? 3 : 1.5;
    g.strokeStyle = col;
    g.strokeRect(X, Y, w, h);
    if (i === DS.sel) { g.fillStyle = col + "22"; g.fillRect(X, Y, w, h); }
    const name = CLS_TH[DS.classes[b.cls]] || DS.classes[b.cls] || "?";
    g.font = "12px Tahoma, sans-serif";
    const tw = g.measureText(name).width + 8;
    g.fillStyle = col;
    g.fillRect(X, Math.max(0, Y - 15), tw, 15);
    g.fillStyle = "#12161d";
    g.fillText(name, X + 4, Math.max(11, Y - 4));
  });

  if (DS.drag) {
    const [X, Y] = P(Math.min(DS.drag.x1, DS.drag.x2), Math.min(DS.drag.y1, DS.drag.y2));
    g.setLineDash([5, 4]);
    g.strokeStyle = DS_COLORS[DS.cls % 8];
    g.lineWidth = 2;
    g.strokeRect(X, Y, Math.abs(DS.drag.x2 - DS.drag.x1) * fb.s,
                 Math.abs(DS.drag.y2 - DS.drag.y1) * fb.s);
    g.setLineDash([]);
  }
}

function dsBindCanvas() {
  const cv = $("#dsCanvas");
  const toImg = (e) => {
    const r = $("#dsImg").getBoundingClientRect(), fb = dsFit();
    return { x: (e.clientX - r.left - fb.x) / fb.s, y: (e.clientY - r.top - fb.y) / fb.s };
  };
  cv.onmousedown = (e) => {
    const p = toImg(e);
    // เลือกกรอบที่เล็กที่สุดที่คลุมจุดนี้ เพื่อให้เลือกวัตถุเล็กที่ซ้อนอยู่ในกรอบใหญ่ได้
    let hit = -1, area = 1e15;
    DS.boxes.forEach((b, i) => {
      if (p.x >= b.x1 && p.x <= b.x2 && p.y >= b.y1 && p.y <= b.y2) {
        const a = (b.x2 - b.x1) * (b.y2 - b.y1);
        if (a < area) { area = a; hit = i; }
      }
    });
    if (hit >= 0) { DS.sel = hit; DS.cls = DS.boxes[hit].cls || 0; dsClassBar(); dsDraw(); return; }
    DS.sel = -1;
    DS.drag = { x1: p.x, y1: p.y, x2: p.x, y2: p.y };
    dsDraw();
  };
  cv.onmousemove = (e) => {
    if (!DS.drag) return;
    const p = toImg(e);
    DS.drag.x2 = p.x; DS.drag.y2 = p.y;
    dsDraw();
  };
  window.addEventListener("mouseup", () => {
    if (!DS.drag) return;
    const d = DS.drag; DS.drag = null;
    const b = {
      cls: DS.cls,
      x1: Math.round(Math.min(d.x1, d.x2)), y1: Math.round(Math.min(d.y1, d.y2)),
      x2: Math.round(Math.max(d.x1, d.x2)), y2: Math.round(Math.max(d.y1, d.y2)),
    };
    if (b.x2 - b.x1 >= 5 && b.y2 - b.y1 >= 5) { DS.boxes.push(b); DS.sel = DS.boxes.length - 1; }
    dsDraw();
  });
  window.addEventListener("resize", () => { if (!$("#pane-teach").hidden) dsDraw(); });
}

async function dsSave(status) {
  if (!DS.frame || DS.busy) return;
  DS.busy = true;
  try {
    await api(`/api/dataset/frame/${DS.frame.id}`, { boxes: DS.boxes, status });
    await dsNext();
  } catch (e) { toast("บันทึกไม่สำเร็จ: " + e.message, true); }
  finally { DS.busy = false; }
}

async function dsCollect() {
  if (!S.videoId || S.allMode) { toast("เลือกกล้องทีละตัวก่อนเก็บภาพ", true); return; }
  const btn = $("#dsCollect");
  btn.disabled = true;
  try {
    const r = await api("/api/dataset/collect", { video_id: S.videoId, n: 40 });
    toast(r.added ? `เก็บภาพเพิ่ม ${r.added} ภาพเข้าคิวแล้ว` : "ไม่มีภาพใหม่จากกล้องนี้แล้ว");
    await dsNext();
  } catch (e) { toast("เก็บภาพไม่สำเร็จ: " + e.message, true); }
  finally { btn.disabled = false; }
}

async function dsExport() {
  const btn = $("#dsExport");
  btn.disabled = true;
  try {
    const r = await api("/api/dataset/export", {});
    toast(`ส่งออกแล้ว ${r.images} ภาพ (ฝึก ${r.train} / ตรวจสอบ ${r.val}) — ต่อไปดับเบิลคลิก สอนโมเดล.bat`);
  } catch (e) { toast("ส่งออกไม่สำเร็จ: " + e.message, true); }
  finally { btn.disabled = false; }
}

/* ------------------------------------------------------------------- tabs */
function switchTab(name) {
  $$(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
  $$(".tabpane").forEach((p) => { p.hidden = p.id !== `pane-${name}`; });
  if (name === "heat") loadHeat();
  if (name === "paths") loadPaths();
  if (name === "info") { loadAudit(); loadMaint(); }
  if (name === "teach") { dsStats(); dsNext(); }
}

/* ------------------------------------------------------------ อัปเดตโปรแกรม */
const UPD = { info: null, done: false };
function updRender() {
  const i = UPD.info;
  const st = $("#updState"), ap = $("#updApply"), rs = $("#updRestart"), notes = $("#updNotes"), badge = $("#updBadge");
  if (UPD.done) {
    st.textContent = `อัปเดตเป็นรุ่น ${UPD.done} แล้ว — ต้องรีสตาร์ทโปรแกรม`;
    ap.hidden = true; rs.hidden = false; notes.hidden = true; badge.hidden = true;
    return;
  }
  if (!i) return;
  $("#updCur").textContent = i.current || "–";
  if (!i.ok) { st.textContent = i.error || "ตรวจสอบไม่ได้"; ap.hidden = true; return; }
  if (i.available) {
    st.textContent = `มีรุ่นใหม่ ${i.latest}${i.released ? " (" + i.released + ")" : ""}`;
    ap.hidden = !i.update_url;
    ap.textContent = i.update_size ? `อัปเดตเดี๋ยวนี้ (${(i.update_size / 1048576).toFixed(1)} MB)` : "อัปเดตเดี๋ยวนี้";
    notes.hidden = !i.notes; notes.textContent = i.notes || "";
    if (!i.update_url) $("#updInfo").textContent = "รุ่นนี้ต้องดาวน์โหลดชุดเต็มจากเว็บ" + (i.full_url ? ": " + i.full_url : "");
    badge.hidden = false;
  } else {
    st.textContent = `เป็นรุ่นล่าสุดแล้ว (ตรวจเมื่อ ${i.checked_at})`;
    ap.hidden = true; notes.hidden = true; badge.hidden = true;
  }
}
async function updCheck(force) {
  const b = $("#updCheck"); b.disabled = true; $("#updInfo").textContent = "";
  try { UPD.info = await api(`/api/update/check?force=${force ? 1 : 0}`); updRender(); }
  catch (e) { $("#updState").textContent = "ตรวจสอบไม่ได้: " + e.message; }
  finally { b.disabled = false; }
}
async function updApply() {
  const b = $("#updApply"); b.disabled = true; $("#updInfo").textContent = "กำลังเริ่ม…";
  try {
    const job = await api("/api/update/apply", {});
    while (true) {
      await new Promise((r) => setTimeout(r, 800));
      const j = await api(`/api/job/${job.job_id}`);
      $("#updInfo").textContent = j.message || j.status;
      if (j.status === "done") { UPD.done = (j.result && j.result.version) || UPD.info.latest; updRender(); toast("อัปเดตแล้ว กดรีสตาร์ทเพื่อใช้รุ่นใหม่"); break; }
      if (j.status === "error") { toast("อัปเดตไม่สำเร็จ: " + j.message, true); break; }
    }
  } catch (e) { toast("อัปเดตไม่สำเร็จ: " + e.message, true); }
  finally { b.disabled = false; }
}
async function updRestart() {
  const b = $("#updRestart"); b.disabled = true;
  try {
    const r = await api("/api/update/restart", {});
    $("#updInfo").textContent = r.mode === "app"
      ? "โปรแกรมกำลังปิดและเปิดใหม่ หน้าต่างนี้จะหายไปแล้วเปิดขึ้นมาใหม่ในไม่กี่วินาที"
      : "กำลังรีสตาร์ท… หน้านี้จะโหลดใหม่เองเมื่อพร้อม";
    // โหมดเว็บ: รอเซิร์ฟเวอร์ตัวใหม่ขึ้นแล้วโหลดหน้าใหม่
    let gone = false;
    for (let k = 0; k < 90; k++) {
      await new Promise((r) => setTimeout(r, 1000));
      try {
        const h = await fetch("/api/health", { cache: "no-store" });
        if (h.ok) { const d = await h.json(); if (gone || d.version !== UPD.info.current) { location.reload(); return; } }
      } catch (e) { gone = true; }
    }
  } catch (e) { toast("รีสตาร์ทไม่ได้: " + e.message, true); b.disabled = false; }
}
function bindUpdate() {
  $("#updCheck").onclick = () => updCheck(true);
  $("#updApply").onclick = updApply;
  $("#updRestart").onclick = updRestart;
  // ตอนเปิดหน้า: ถามผลที่เซิร์ฟเวอร์เช็คไว้แล้ว (ไม่ยิงเน็ตซ้ำ) เพื่อขึ้นป้าย "รุ่นใหม่" ที่แท็บ
  api("/api/health").then((h) => { $("#updCur").textContent = h.version || "–"; }).catch(() => {});
  setTimeout(() => updCheck(false), 6000);
}

async function loadMaint() {
  try {
    const m = await api("/api/maintenance");
    const rows = Object.entries(m.disk.parts)
      .map(([k, v]) => `<div class="kv"><span>${k}</span><span>${mb(v)}</span></div>`).join("");
    const ret = m.retention_days > 0
      ? `<div class="kv"><span>เก็บข้อมูลไว้</span><span>${m.retention_days} วัน</span></div>` +
        `<div class="kv"><span>ถึงกำหนดลบแล้ว</span><span class="${m.expiring.length ? "warn" : ""}">${m.expiring.length} รายการ</span></div>`
      : `<div class="kv"><span>เก็บข้อมูลไว้</span><span class="warn">ไม่จำกัด</span></div>
         <p class="hint">ตั้ง <code>maintenance.retention_days</code> ใน config.yaml
         ให้ตรงกับระเบียบของหน่วยงาน ระบบจะลบให้เองตอนเปิดโปรแกรม</p>`;
    $("#maint").innerHTML =
      `<div><em>พื้นที่ที่ใช้อยู่</em>${rows}
         <div class="kv tot"><span>รวม</span><span>${mb(m.disk.total)}</span></div></div>
       <div><em>อายุการเก็บข้อมูล</em>${ret}
         ${m.retention_days > 0 ? '<button class="btn" id="btnCleanup">ลบข้อมูลที่เกินอายุเดี๋ยวนี้</button>' : ""}</div>
       <div><em>สำรองฐานข้อมูล</em>
         <div class="kv"><span>ชุดที่มีอยู่</span><span>${m.backups.length} / ${m.backup_keep}</span></div>
         <div class="kv"><span>ล่าสุด</span><span>${m.backups[0] ? m.backups[0].replace("klongthep-", "").replace(".db", "") : "ยังไม่มี"}</span></div>
         <p class="hint">เก็บที่ data\\backup — ถ้าฐานข้อมูลเสียให้คัดลอกทับกลับมา</p>
         <button class="btn" id="btnBackup">สำรองเดี๋ยวนี้</button></div>`;
    const bb = $("#btnBackup");
    if (bb) bb.onclick = async () => {
      bb.disabled = true;
      try { const r = await api("/api/maintenance/backup", {}); toast(r.ok ? `สำรองแล้ว (${mb(r.bytes)})` : "สำรองไม่สำเร็จ", !r.ok); }
      catch (e) { toast("สำรองไม่สำเร็จ: " + e.message, true); }
      finally { bb.disabled = false; loadMaint(); }
    };
    const cb = $("#btnCleanup");
    if (cb) cb.onclick = async () => {
      cb.disabled = true;
      try { const r = await api("/api/maintenance/cleanup", {}); toast(`ลบ ${r.deleted} รายการ คืนพื้นที่ ${mb(r.freed)}`); await loadVideos(); }
      catch (e) { toast("ลบไม่สำเร็จ: " + e.message, true); }
      finally { cb.disabled = false; loadMaint(); }
    };
  } catch (e) { $("#maint").innerHTML = '<div class="hint">อ่านข้อมูลไม่ได้</div>'; }
}

async function loadAudit() {
  try {
    const rows = await api("/api/audit?limit=150");
    $("#audit").innerHTML = rows.map((r) =>
      `<div><span class="ts">${r.ts}</span><span class="act">${r.action}</span><span class="det">${(r.detail || "").slice(0, 160)}</span></div>`
    ).join("") || '<div class="hint" style="padding:10px">ยังไม่มีประวัติ</div>';
  } catch (e) { /* ไม่สำคัญ */ }
}

/* ------------------------------------------------------------------- bind */
function bindUI() {
  $("#videoSel").onchange = (e) => e.target.value && selectVideo(e.target.value);
  $("#btnSearch").onclick = doSearch;
  $("#btnClear").onclick = () => {
    S.classes.clear(); S.colors.clear(); S.direction = null; S.roi = null; S.line = null;
    S.upColors.clear(); S.loColors.clear();
    $("#t0").value = ""; $("#t1").value = "";
    $("#minDur").value = ""; $("#minH").value = ""; $("#maxH").value = "";
    $("#minSp").value = ""; $("#maxSp").value = "";
    $("#roiInfo").textContent = ""; $("#lineInfo").textContent = "";
    $("#movingOnly").checked = false;
    $$("#compass button").forEach((b) => b.classList.remove("on"));
    buildChips(); loadTimeline(); doSearch();
  };
  $("#sortSel").onchange = doSearch;
  $("#minDur").onchange = doSearch;
  $("#minH").onchange = doSearch;
  $("#maxH").onchange = doSearch;
  $("#minSp").onchange = doSearch;
  $("#maxSp").onchange = doSearch;
  $("#movingOnly").onchange = doSearch;
  $("#t0").onchange = () => { drawTimeline(); doSearch(); };
  $("#t1").onchange = () => { drawTimeline(); doSearch(); };

  $$("#compass button").forEach((b) => {
    b.onclick = () => {
      const on = b.classList.contains("on");
      $$("#compass button").forEach((x) => x.classList.remove("on"));
      if (on) { S.direction = null; } else { b.classList.add("on"); S.direction = b.dataset.dir.split(",").map(Number); }
      doSearch();
    };
  });

  $("#pairRun").onclick = async () => {
    const b = $("#pairRun"); b.disabled = true;
    $("#pairInfo").textContent = "กำลังปรับปรุง…";
    try {
      const r = await api("/api/tubes/improve", {});
      $("#pairInfo").textContent =
        `ต่อร่องรอย ${r.merged.toLocaleString()} ชิ้น (เหลือวัตถุ ${r.after.toLocaleString()} จาก ${r.before.toLocaleString()}) · ` +
        `จับคู่คนขับ ${r.groups.toLocaleString()} คัน จาก ${r.videos} กล้อง`;
      toast("ปรับปรุงเรียบร้อย — สร้างวิดีโอย่อใหม่เพื่อดูผล");
      await doSearch();
    } catch (e) {
      $("#pairInfo").textContent = "";
      toast("จับคู่ไม่สำเร็จ: " + e.message, true);
    } finally { b.disabled = false; }
  };
  $("#btnRoi").onclick = openRoi;
  $("#btnLine").onclick = openLine;
  bindPaths();
  $("#btnSynopsis").onclick = makeSynopsis;
  $("#chrono").oninput = (e) => { $("#chronoVal").textContent = e.target.value; };
  $("#timeMode").onchange = () => { if (S.videoId) doSearch(); };
  $("#modalClose").onclick = closeModal;
  $("#modal").onclick = (e) => { if (e.target.id === "modal") closeModal(); };
  $("#btnAdd").onclick = () => { $("#addModal").hidden = false; };
  $("#btnDel").onclick = openDelete;
  $("#btnTime").onclick = openTime;
  $("#timeClose").onclick = () => { $("#timeModal").hidden = true; };
  $("#timeCancel").onclick = () => { $("#timeModal").hidden = true; };
  $("#timeSave").onclick = saveTime;
  $("#whoBtn").onclick = () => askUser(true);
  $("#dsCollect").onclick = dsCollect;
  $("#dsExport").onclick = dsExport;
  $("#dsSave").onclick = () => dsSave("done");
  $("#dsSkip").onclick = () => dsSave("skipped");
  $("#dsDel").onclick = () => {
    if (DS.sel >= 0) { DS.boxes.splice(DS.sel, 1); DS.sel = -1; dsDraw(); }
  };
  dsBindCanvas();
  $("#delClose").onclick = $("#delCancel").onclick = () => { $("#delModal").hidden = true; };
  $("#delConfirm").onclick = doDelete;
  $("#addClose").onclick = () => { $("#addModal").hidden = true; };
  $("#btnBrowse").onclick = () => browse($("#addPath").value.trim());
  $("#btnStartIngest").onclick = startIngest;
  bindDesktop();
  bindUpdate();
  $$(".tab").forEach((t) => { t.onclick = () => switchTab(t.dataset.tab); });
  document.addEventListener("keydown", (e) => {
    // ปุ่มลัดของหน้าติดป้าย ใช้ได้เฉพาะตอนอยู่ในแท็บนั้นและไม่ได้พิมพ์ในช่องข้อความ
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target || {}).tagName || "");
    if (!typing && !$("#pane-teach").hidden && DS.frame) {
      if (e.key === "Delete" || e.key === "Backspace") {
        if (DS.sel >= 0) { DS.boxes.splice(DS.sel, 1); DS.sel = -1; dsDraw(); }
        e.preventDefault(); return;
      }
      if (e.key === "Enter") { dsSave("done"); e.preventDefault(); return; }
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= DS.classes.length) {
        DS.cls = n - 1;
        if (DS.sel >= 0) DS.boxes[DS.sel].cls = DS.cls;
        dsClassBar(); dsDraw(); e.preventDefault(); return;
      }
    }
    if (e.key === "Escape") {
      closeModal();
      $("#addModal").hidden = true; $("#roiModal").hidden = true; $("#delModal").hidden = true;
    }
  });
  bindTimelineDrag();
}

init();
