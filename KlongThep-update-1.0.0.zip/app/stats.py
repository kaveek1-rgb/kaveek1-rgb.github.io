"""สถิติและภาพความหนาแน่น - อ่านจากคลังดัชนีล้วน ๆ"""
from __future__ import annotations

import io

import cv2
import numpy as np

from . import db, search


def timeline(video_id: int, bucket_sec: float = 60.0, classes: list[str] | None = None) -> dict:
    """จำนวนวัตถุที่ 'ยังปรากฏอยู่' ในแต่ละช่วงเวลา ใช้วาดแถบไทม์ไลน์"""
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            return {"bucket": bucket_sec, "buckets": [], "duration": 0}
        dur = float(v["duration"] or 0)
        n = max(1, int(np.ceil(dur / bucket_sec))) if dur else 1

        q = "SELECT cls, start_sec, end_sec FROM tubes WHERE video_id=?"
        args: list = [video_id]
        if classes:
            q += " AND cls IN (%s)" % ",".join("?" * len(classes))
            args += classes
        rows = con.execute(q, args).fetchall()

        counts = np.zeros(n, dtype=np.int32)
        per_class: dict[str, np.ndarray] = {}
        for r in rows:
            a = int(max(0, min(n - 1, int(r["start_sec"] // bucket_sec))))
            b = int(max(0, min(n - 1, int(r["end_sec"] // bucket_sec))))
            counts[a:b + 1] += 1
            arr = per_class.setdefault(r["cls"], np.zeros(n, dtype=np.int32))
            arr[a:b + 1] += 1

        return {
            "bucket": bucket_sec,
            "duration": dur,
            "started_at": v["started_at"],
            "counts": counts.tolist(),
            "per_class": {k: a.tolist() for k, a in per_class.items()},
            "peak": int(counts.max()) if n else 0,
        }
    finally:
        con.close()


def timeline_all(bucket_sec: float = 60.0, classes: list[str] | None = None) -> dict:
    """ไทม์ไลน์รวมทุกกล้อง อ้างอิงเวลานาฬิกาจริง ไม่ใช่เวลาในไฟล์

    กล้องแต่ละตัวเริ่มบันทึกคนละเวลา จึงต้องวางทุกอย่างบนแกนเวลาจริงเดียวกัน
    ไม่งั้นเหตุการณ์จากคนละกล้องจะไปกองผิดที่
    """
    con = db.connect()
    try:
        q = ("SELECT v.id vid, v.name, v.started_at, t.cls, t.start_sec, t.end_sec"
             " FROM tubes t JOIN videos v ON v.id=t.video_id"
             " WHERE v.started_at IS NOT NULL")
        args: list = []
        if classes:
            q += " AND t.cls IN (%s)" % ",".join("?" * len(classes))
            args += classes
        rows = con.execute(q, args).fetchall()
    finally:
        con.close()

    if not rows:
        return {"mode": "abs", "buckets": 0, "counts": [], "per_camera": {}, "cameras": []}

    def epoch(iso: str) -> float:
        from datetime import datetime
        return datetime.fromisoformat(iso).timestamp()

    items = []
    for r in rows:
        try:
            base = epoch(r["started_at"])
        except ValueError:
            continue
        items.append((r["vid"], r["name"], base + r["start_sec"], base + r["end_sec"]))
    if not items:
        return {"mode": "abs", "buckets": 0, "counts": [], "per_camera": {}, "cameras": []}

    t0 = min(i[2] for i in items)
    t1 = max(i[3] for i in items)
    span = max(1.0, t1 - t0)
    # bucket<=0 = ให้ระบบเลือกเอง ให้ได้แท่งราว 300 แท่งไม่ว่าช่วงเวลาจะสั้นหรือยาว
    # (ข้อมูลอาจกินเวลาแค่นาทีเดียว หรือหลายวันก็ได้)
    if not bucket_sec or bucket_sec <= 0:
        bucket_sec = span / 300.0
    n = max(1, min(2000, int(np.ceil(span / bucket_sec))))
    bucket_sec = span / n

    counts = np.zeros(n, np.int32)
    per_cam: dict[str, np.ndarray] = {}
    for vid, name, a, b in items:
        ia = int(max(0, min(n - 1, (a - t0) // bucket_sec)))
        ib = int(max(0, min(n - 1, (b - t0) // bucket_sec)))
        counts[ia:ib + 1] += 1
        arr = per_cam.setdefault(name, np.zeros(n, np.int32))
        arr[ia:ib + 1] += 1

    from datetime import datetime
    return {
        "mode": "abs",
        "bucket": bucket_sec,
        "t_start": datetime.fromtimestamp(t0).strftime("%Y-%m-%d %H:%M:%S"),
        "t_end": datetime.fromtimestamp(t1).strftime("%Y-%m-%d %H:%M:%S"),
        "duration": t1 - t0,
        "counts": counts.tolist(),
        "per_camera": {k: v.tolist() for k, v in per_cam.items()},
        "peak": int(counts.max()),
        "cameras": sorted(per_cam),
    }


def summary_all() -> dict:
    """สรุปรวมทุกกล้อง"""
    cams = search.cameras()
    con = db.connect()
    try:
        row = con.execute("SELECT COUNT(*) n, AVG(duration) avgdur, MAX(duration) maxdur"
                          " FROM tubes").fetchone()
    finally:
        con.close()
    return {
        "mode": "all",
        "n_cameras": len(cams),
        "cameras": cams,
        "n_tubes": int(row["n"] or 0),
        "avg_duration": float(row["avgdur"] or 0),
        "max_duration": float(row["maxdur"] or 0),
        "classes": search.class_counts(search.ALL),
        "colors": search.color_counts(search.ALL),
    }


def heatmap_png(video_id: int, filters: dict | None = None, alpha: float = 0.78) -> bytes:
    """ภาพความหนาแน่นของเส้นทางเดิน คืน PNG แบบมีช่องโปร่งใส วางทับภาพนิ่งได้เลย"""
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            return b""
        W = int(v["width"] or 1280)
        H = int(v["height"] or 720)
        gw, gh = 160, max(2, int(160 * H / max(W, 1)))

        q = "SELECT p.cx, p.cy FROM tube_points p JOIN tubes t ON t.id=p.tube_id WHERE p.video_id=?"
        args: list = [video_id]
        f = filters or {}
        if f.get("classes"):
            q += " AND t.cls IN (%s)" % ",".join("?" * len(f["classes"]))
            args += list(f["classes"])
        if f.get("t0") is not None:
            q += " AND p.sec >= ?"
            args.append(float(f["t0"]))
        if f.get("t1") is not None:
            q += " AND p.sec <= ?"
            args.append(float(f["t1"]))
        rows = con.execute(q, args).fetchall()
    finally:
        con.close()

    acc = np.zeros((gh, gw), np.float32)
    for r in rows:
        x = int(min(gw - 1, max(0, r["cx"] / max(W, 1) * gw)))
        y = int(min(gh - 1, max(0, r["cy"] / max(H, 1) * gh)))
        acc[y, x] += 1.0

    if acc.max() <= 0:
        rgba = np.zeros((gh, gw, 4), np.uint8)
    else:
        acc = cv2.GaussianBlur(acc, (0, 0), 2.4)
        norm = acc / (np.percentile(acc[acc > 0], 97) + 1e-6)
        norm = np.clip(norm, 0, 1)
        col = cv2.applyColorMap((norm * 255).astype(np.uint8), cv2.COLORMAP_TURBO)
        a = (np.clip(norm * 1.35, 0, 1) * 255 * alpha).astype(np.uint8)
        rgba = np.dstack([col, a])

    rgba = cv2.resize(rgba, (W, H), interpolation=cv2.INTER_CUBIC)
    ok, enc = cv2.imencode(".png", rgba)
    return enc.tobytes() if ok else b""


def summary(video_id: int) -> dict:
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            return {}
        row = con.execute(
            "SELECT COUNT(*) n, AVG(duration) avgdur, MAX(duration) maxdur FROM tubes WHERE video_id=?",
            (video_id,),
        ).fetchone()
        busiest = con.execute(
            "SELECT CAST(start_sec/600 AS INT) b, COUNT(*) n FROM tubes WHERE video_id=?"
            " GROUP BY b ORDER BY n DESC LIMIT 1",
            (video_id,),
        ).fetchone()
    finally:
        con.close()

    out = {
        "video": dict(v),
        "n_tubes": int(row["n"] or 0),
        "avg_duration": float(row["avgdur"] or 0),
        "max_duration": float(row["maxdur"] or 0),
        "classes": search.class_counts(video_id),
        "colors": search.color_counts(video_id),
    }
    if busiest:
        t0 = float(busiest["b"]) * 600.0
        out["busiest"] = {
            "start_sec": t0,
            "clock": db.wall_clock(v["started_at"], t0),
            "count": int(busiest["n"]),
        }
    return out
