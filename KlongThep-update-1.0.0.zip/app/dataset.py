"""ชุดข้อมูลสำหรับสอนโมเดลด้วยภาพจากกล้องของหน่วยงานเอง

ทำไมต้องมี: โมเดลสำเร็จรูปถูกฝึกจากภาพทั่วไปบนอินเทอร์เน็ต ไม่เคยเห็นมุมกล้องของ สภ.
ไม่เคยเห็นรถที่ถูกราวเหล็กบัง ไม่เคยเห็นภาพกลางคืนจากกล้องรุ่นนี้
การเอาภาพจากกล้องจริงสัก 300-500 ภาพมาสอนเพิ่ม ได้ผลกว่าการเปลี่ยนไปใช้โมเดลใหญ่ขึ้นมาก

ขั้นตอน
  1. collect()  ดึงภาพจากวิดีโอที่ประมวลผลแล้ว พร้อมใส่กรอบอัตโนมัติให้เป็นร่างแรก
  2. คนมาตรวจแก้กรอบในหน้าเว็บ (ลบของผิด เพิ่มของที่ระบบมองไม่เห็น)
  3. export()   จัดเป็นชุดข้อมูลรูปแบบ YOLO แล้วสั่ง tools/train.py
"""
from __future__ import annotations

import random
import shutil
from datetime import datetime
from pathlib import Path

import cv2

from . import config, db, media

DIR = config.DATA / "dataset"
DIR_IMG = DIR / "images"
DIR_LBL = DIR / "labels"

SCHEMA = """
CREATE TABLE IF NOT EXISTS dataset_frames (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    video_id   INTEGER NOT NULL,
    frame      INTEGER NOT NULL,
    sec        REAL,
    width      INTEGER, height INTEGER,
    image_path TEXT,
    status     TEXT DEFAULT 'pending',   -- pending|done|skipped
    n_boxes    INTEGER DEFAULT 0,
    auto_boxes INTEGER DEFAULT 0,
    labeled_by TEXT,
    labeled_at TEXT,
    UNIQUE(video_id, frame)
);
CREATE INDEX IF NOT EXISTS ix_ds_status ON dataset_frames(status);
"""


def ensure() -> None:
    DIR_IMG.mkdir(parents=True, exist_ok=True)
    DIR_LBL.mkdir(parents=True, exist_ok=True)
    con = db.connect()
    try:
        con.executescript(SCHEMA)
        con.commit()
    finally:
        con.close()


def classes(cfg: dict) -> list[str]:
    """ลำดับคลาสของชุดข้อมูล ต้องคงที่ตลอด ไม่งั้นป้ายที่ติดไว้จะเพี้ยน"""
    return list(cfg["detector"].get("classes") or ["person", "car", "motorcycle"])


def label_file(video_id: int, frame: int) -> Path:
    return DIR_LBL / f"{video_id}_{frame:07d}.txt"


def image_file(video_id: int, frame: int) -> Path:
    return DIR_IMG / f"{video_id}_{frame:07d}.jpg"


# ------------------------------------------------------------ เลือกเฟรม
def _pick_frames(con, video_id: int, want: int, min_gap: int) -> list[tuple[int, float]]:
    """เลือกเฟรมที่ "สอนแล้วได้ผล" มากที่สุด

    ให้น้ำหนักกับเฟรมที่โมเดลไม่มั่นใจ และเฟรมที่มีวัตถุตัวเล็ก
    เพราะนั่นคือจุดที่โมเดลกำลังพลาด การติดป้ายเฟรมง่าย ๆ ที่โมเดลทำถูกอยู่แล้วแทบไม่ช่วยอะไร
    """
    rows = con.execute(
        "SELECT p.frame, p.sec, MIN(t.conf) mconf, AVG(t.h_avg) mh, COUNT(*) n"
        " FROM tube_points p JOIN tubes t ON t.id = p.tube_id"
        " WHERE p.video_id = ? GROUP BY p.frame ORDER BY p.frame", (video_id,)
    ).fetchall()
    if not rows:
        return []

    scored = []
    for r in rows:
        conf = float(r["mconf"] or 0.5)
        h = float(r["mh"] or 100.0)
        # ยิ่งความมั่นใจต่ำ และวัตถุยิ่งเล็ก ยิ่งควรเอามาสอน
        score = (1.0 - min(conf, 1.0)) * 2.0 + max(0.0, (80.0 - min(h, 80.0)) / 80.0)
        score += min(int(r["n"]), 5) * 0.05
        scored.append((score, int(r["frame"]), float(r["sec"] or 0)))

    scored.sort(reverse=True)
    picked: list[tuple[int, float]] = []
    used: list[int] = []
    for _score, fr, sec in scored:
        if any(abs(fr - u) < min_gap for u in used):
            continue          # อย่าเอาเฟรมที่อยู่ติดกัน ภาพจะซ้ำจนไม่ได้ประโยชน์
        picked.append((fr, sec))
        used.append(fr)
        if len(picked) >= want:
            break
    return sorted(picked)


def collect(video_id: int, want: int = 40, cfg: dict | None = None) -> dict:
    """ดึงภาพจากวิดีโอหนึ่งเข้าชุดข้อมูล พร้อมใส่กรอบอัตโนมัติเป็นร่างแรก"""
    cfg = cfg or config.load()
    ensure()
    names = classes(cfg)
    idx = {n: i for i, n in enumerate(names)}

    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            return {"ok": False, "reason": "ไม่พบวิดีโอ"}
        fps = float(v["fps"] or 25.0)
        min_gap = max(int(fps * 3), 10)          # ห่างกันอย่างน้อย 3 วินาที
        frames = _pick_frames(con, video_id, want, min_gap)
        if not frames:
            return {"ok": False, "reason": "วิดีโอนี้ยังไม่มีวัตถุที่ตรวจพบ"}

        # กรอบของทุกวัตถุในเฟรมที่เลือก
        want_frames = {f for f, _ in frames}
        boxes: dict[int, list] = {}
        for r in con.execute(
            "SELECT p.frame, p.x1, p.y1, p.x2, p.y2, t.cls FROM tube_points p"
            " JOIN tubes t ON t.id = p.tube_id WHERE p.video_id = ?", (video_id,)
        ):
            if r["frame"] in want_frames and r["cls"] in idx:
                boxes.setdefault(int(r["frame"]), []).append(
                    (idx[r["cls"]], r["x1"], r["y1"], r["x2"], r["y2"]))

        cap = cv2.VideoCapture(media.readable(v))
        if not cap.isOpened():
            return {"ok": False, "reason": f"เปิดไฟล์วิดีโอไม่ได้: {v['path']}"}

        added = 0
        for fr, sec in frames:
            if con.execute("SELECT 1 FROM dataset_frames WHERE video_id=? AND frame=?",
                           (video_id, fr)).fetchone():
                continue
            cap.set(cv2.CAP_PROP_POS_FRAMES, fr)
            ok, img = cap.read()
            if not ok or img is None:
                continue
            H, W = img.shape[:2]
            ip = image_file(video_id, fr)
            cv2.imwrite(str(ip), img, [int(cv2.IMWRITE_JPEG_QUALITY), 92])

            bs = boxes.get(fr, [])
            write_label(video_id, fr, [
                {"cls": c, "x1": x1, "y1": y1, "x2": x2, "y2": y2} for c, x1, y1, x2, y2 in bs
            ], W, H)
            con.execute(
                "INSERT OR IGNORE INTO dataset_frames"
                "(video_id,frame,sec,width,height,image_path,status,n_boxes,auto_boxes)"
                " VALUES(?,?,?,?,?,?,'pending',?,?)",
                (video_id, fr, sec, W, H, str(ip), len(bs), len(bs)))
            added += 1
        cap.release()
        con.commit()
    finally:
        con.close()

    db.log("dataset_collect", {"video_id": video_id, "added": added})
    return {"ok": True, "added": added, "requested": want}


# --------------------------------------------------------- อ่าน/เขียนป้าย
def write_label(video_id: int, frame: int, boxes: list[dict], W: int, H: int) -> None:
    """เขียนไฟล์ป้ายรูปแบบ YOLO: cls cx cy w h (ทุกค่าเป็นสัดส่วน 0-1)"""
    lines = []
    for b in boxes:
        x1, y1 = max(0, float(b["x1"])), max(0, float(b["y1"]))
        x2, y2 = min(W, float(b["x2"])), min(H, float(b["y2"]))
        if x2 - x1 < 2 or y2 - y1 < 2:
            continue
        lines.append(f"{int(b['cls'])} {(x1+x2)/2/W:.6f} {(y1+y2)/2/H:.6f} "
                     f"{(x2-x1)/W:.6f} {(y2-y1)/H:.6f}")
    label_file(video_id, frame).write_text("\n".join(lines) + ("\n" if lines else ""),
                                           encoding="utf-8")


def read_label(video_id: int, frame: int, W: int, H: int) -> list[dict]:
    p = label_file(video_id, frame)
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        parts = line.split()
        if len(parts) != 5:
            continue
        c, cx, cy, w, h = int(parts[0]), *[float(x) for x in parts[1:]]
        out.append({"cls": c,
                    "x1": round((cx - w / 2) * W), "y1": round((cy - h / 2) * H),
                    "x2": round((cx + w / 2) * W), "y2": round((cy + h / 2) * H)})
    return out


# ------------------------------------------------------------------ คิวงาน
def next_frame(status: str = "pending") -> dict | None:
    con = db.connect()
    try:
        r = con.execute(
            "SELECT d.*, v.name AS video_name FROM dataset_frames d"
            " LEFT JOIN videos v ON v.id = d.video_id"
            " WHERE d.status=? ORDER BY d.id LIMIT 1", (status,)).fetchone()
    finally:
        con.close()
    return dict(r) if r else None


def get_frame(frame_id: int) -> dict | None:
    con = db.connect()
    try:
        r = con.execute(
            "SELECT d.*, v.name AS video_name FROM dataset_frames d"
            " LEFT JOIN videos v ON v.id = d.video_id WHERE d.id=?", (frame_id,)).fetchone()
    finally:
        con.close()
    if not r:
        return None
    d = dict(r)
    d["boxes"] = read_label(int(d["video_id"]), int(d["frame"]),
                            int(d["width"] or 1), int(d["height"] or 1))
    return d


def save_frame(frame_id: int, boxes: list[dict], status: str = "done") -> dict | None:
    con = db.connect()
    try:
        r = con.execute("SELECT * FROM dataset_frames WHERE id=?", (frame_id,)).fetchone()
        if not r:
            return None
        write_label(int(r["video_id"]), int(r["frame"]), boxes,
                    int(r["width"] or 1), int(r["height"] or 1))
        con.execute(
            "UPDATE dataset_frames SET status=?, n_boxes=?, labeled_by=?, labeled_at=? WHERE id=?",
            (status, len(boxes), db.CURRENT_USER.get(), db.now_iso(), frame_id))
        con.commit()
    finally:
        con.close()
    return {"ok": True, "id": frame_id, "n_boxes": len(boxes), "status": status}


def stats() -> dict:
    ensure()
    con = db.connect()
    try:
        rows = con.execute("SELECT status, COUNT(*) n, SUM(n_boxes) b"
                           " FROM dataset_frames GROUP BY status").fetchall()
        per_cls = con.execute("SELECT COUNT(*) n FROM dataset_frames WHERE status='done'").fetchone()
    finally:
        con.close()
    by = {r["status"]: {"frames": int(r["n"]), "boxes": int(r["b"] or 0)} for r in rows}
    done = by.get("done", {}).get("frames", 0)
    return {
        "pending": by.get("pending", {}).get("frames", 0),
        "done": done,
        "skipped": by.get("skipped", {}).get("frames", 0),
        "boxes": by.get("done", {}).get("boxes", 0),
        "total": sum(v["frames"] for v in by.values()),
        # ต่ำกว่านี้สอนแล้วมักไม่เห็นผล
        "ready": done >= 100,
        "target": 300,
    }


# ------------------------------------------------------- ส่งออกไปเทรน
def export(cfg: dict | None = None, val_ratio: float = 0.2, seed: int = 7) -> dict:
    """จัดไฟล์เป็นโครงสร้างที่ ultralytics ต้องการ แล้วเขียน data.yaml"""
    cfg = cfg or config.load()
    names = classes(cfg)
    out = DIR / "yolo"
    if out.exists():
        shutil.rmtree(out)
    for split in ("train", "val"):
        (out / "images" / split).mkdir(parents=True, exist_ok=True)
        (out / "labels" / split).mkdir(parents=True, exist_ok=True)

    con = db.connect()
    try:
        rows = con.execute("SELECT video_id, frame, image_path FROM dataset_frames"
                           " WHERE status='done' ORDER BY id").fetchall()
    finally:
        con.close()
    items = [r for r in rows if r["image_path"] and Path(r["image_path"]).exists()]
    if not items:
        return {"ok": False, "reason": "ยังไม่มีภาพที่ติดป้ายเสร็จ"}

    random.Random(seed).shuffle(items)
    n_val = max(1, int(len(items) * val_ratio)) if len(items) > 4 else 0
    for i, r in enumerate(items):
        split = "val" if i < n_val else "train"
        src_img = Path(r["image_path"])
        src_lbl = label_file(int(r["video_id"]), int(r["frame"]))
        shutil.copy2(src_img, out / "images" / split / src_img.name)
        dst_lbl = out / "labels" / split / (src_img.stem + ".txt")
        dst_lbl.write_text(src_lbl.read_text(encoding="utf-8") if src_lbl.exists() else "",
                           encoding="utf-8")

    yaml_text = (
        f"# ชุดข้อมูลจากกล้องของหน่วยงาน สร้างโดยกล้องเทพ {datetime.now():%Y-%m-%d %H:%M}\n"
        f"path: {out.resolve().as_posix()}\n"
        "train: images/train\n"
        "val: images/val\n"
        f"nc: {len(names)}\n"
        "names:\n" + "".join(f"  {i}: {n}\n" for i, n in enumerate(names))
    )
    (out / "data.yaml").write_text(yaml_text, encoding="utf-8")
    db.log("dataset_export", {"images": len(items), "train": len(items) - n_val, "val": n_val})
    return {"ok": True, "images": len(items), "train": len(items) - n_val, "val": n_val,
            "data_yaml": str(out / "data.yaml"), "classes": names}
