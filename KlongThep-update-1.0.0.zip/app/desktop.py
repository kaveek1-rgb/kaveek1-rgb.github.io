"""เปิดเป็นหน้าต่างโปรแกรม แทนการเปิดเบราว์เซอร์

ข้างในยังเป็นหน้าเว็บเดิม (FastAPI + HTML) แต่ห่อด้วยหน้าต่างของตัวเอง
ผ่าน pywebview ซึ่งบน Windows ใช้ Edge WebView2 ที่ติดมากับ Windows 10/11 อยู่แล้ว
ผู้ใช้จึงเห็นเป็นโปรแกรมปกติ มีชื่อ ปิดหน้าต่างแล้วโปรแกรมหยุด
ไม่มีแถบที่อยู่เว็บให้สับสน และไม่ต้องเปิดเบราว์เซอร์ค้างไว้

ถ้าเครื่องไหนไม่มี pywebview หรือ WebView2 (เครื่องเก่ามาก) จะถอยไปเปิด
เบราว์เซอร์แบบเดิมโดยอัตโนมัติ โปรแกรมต้องใช้ได้เสมอ
"""
from __future__ import annotations

import os
import socket
import sys
import threading
import time
import urllib.request
from pathlib import Path

from . import config, media

APP_TITLE = "กล้องเทพ — ระบบวิเคราะห์ภาพวงจรปิด"
VIDEO_EXTS = ";".join("*" + e for e in sorted(media.VIDEO_EXTS))


def _port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.5):
            return True
    except OSError:
        return False


def _healthy(url: str) -> bool:
    try:
        with urllib.request.urlopen(url + "/api/health", timeout=1.5) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def _start_server(host: str, port: int) -> threading.Thread:
    from . import server

    def run():
        import uvicorn
        uvicorn.run(server.app, host=host, port=port, log_level="warning")

    t = threading.Thread(target=run, name="klongthep-server", daemon=True)
    t.start()
    return t


def _wait_ready(url: str, seconds: float = 40.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < seconds:
        if _healthy(url):
            return True
        time.sleep(0.25)
    return False


def _has_webview2() -> bool:
    """Windows: มี Edge WebView2 Runtime ไหม (Windows 11 มีเสมอ, Windows 10 ส่วนใหญ่มี)

    ถ้าไม่มี pywebview จะถอยไปใช้ตัวเรนเดอร์เก่าของ IE ซึ่งแสดงหน้าเว็บนี้ไม่ได้
    จึงเช็คก่อน แล้วเปิดเบราว์เซอร์แทนพร้อมบอกวิธีติดตั้ง
    """
    if os.name != "nt":
        return True
    try:
        import winreg
    except ImportError:
        return True
    keys = (
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
        (winreg.HKEY_CURRENT_USER,
         r"Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
    )
    for root, sub in keys:
        try:
            with winreg.OpenKey(root, sub) as k:
                pv, _ = winreg.QueryValueEx(k, "pv")
                if pv and str(pv) != "0.0.0.0":
                    return True
        except OSError:
            continue
    return False


class _Api:
    """ฟังก์ชันที่หน้าเว็บเรียกได้ผ่าน window.pywebview.api (เฉพาะตอนเป็นหน้าต่างโปรแกรม)

    ระวัง: pywebview จะไล่สำรวจ "ทุก attribute ที่ไม่ขึ้นต้นด้วย _" ของอ็อบเจกต์นี้แบบ recursive
    เพื่อหาฟังก์ชันไปเปิดให้ JavaScript ถ้าเผลอเก็บ window (ซึ่งถือ .NET object ข้างในเป็นพัน ๆ ชั้น)
    ไว้เป็น attribute ธรรมดา มันจะไล่ลงไปไม่รู้จบจนโปรแกรมค้าง — จึงต้องใช้ชื่อขึ้นต้นด้วย _
    """

    def __init__(self):
        self._window = None

    def pick_video(self):
        """เปิดหน้าต่างเลือกไฟล์ของ Windows แล้วคืนเส้นทางไฟล์ (หรือ None ถ้ายกเลิก)"""
        import webview
        if self._window is None:
            return None
        start = str(config.ROOT)
        try:
            # คำอธิบายในตัวกรองต้องเป็น ASCII — pywebview ตรวจด้วย regex ที่ไม่รับสระ/วรรณยุกต์ไทย
            res = self._window.create_file_dialog(
                webview.OPEN_DIALOG, directory=start, allow_multiple=False,
                file_types=(f"Video files ({VIDEO_EXTS})", "All files (*.*)"))
        except Exception as exc:  # noqa: BLE001
            print(f"[กล้องเทพ] หน้าต่างเลือกไฟล์เปิดไม่ได้: {exc}")
            return None
        if not res:
            return None
        return str(res[0]) if isinstance(res, (list, tuple)) else str(res)

    def open_folder(self, path: str):
        """เปิดโฟลเดอร์ใน Explorer (ใช้กับโฟลเดอร์ผลลัพธ์)"""
        p = Path(path)
        if not p.exists():
            return False
        try:
            if os.name == "nt":
                os.startfile(str(p))  # type: ignore[attr-defined]
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(p)])
            return True
        except Exception:  # noqa: BLE001
            return False


def _windowed() -> bool:
    """รันเป็น .exe แบบไม่มีคอนโซล (ดับเบิลคลิกจาก Explorer) หรือไม่"""
    return config.FROZEN and (sys.stdout is None or not hasattr(sys.stdout, "fileno"))


def _can_open_window(force_browser: bool) -> tuple[bool, str]:
    if force_browser:
        return False, ""
    try:
        import webview  # noqa: F401  (pywebview)
    except Exception:  # noqa: BLE001
        return False, ("ไม่พบ pywebview จึงเปิดในเบราว์เซอร์แทน "
                       "(pip install pywebview เพื่อให้เป็นหน้าต่างโปรแกรม)")
    if not _has_webview2():
        return False, ("เครื่องนี้ไม่มี Microsoft Edge WebView2 Runtime จึงเปิดในเบราว์เซอร์แทน\n"
                       "  ติดตั้งได้ฟรีจาก https://developer.microsoft.com/microsoft-edge/webview2/ "
                       "(Evergreen Bootstrapper)")
    return True, ""


def main(force_browser: bool = False) -> int:
    from . import server

    server.RUN_MODE = "app"
    cfg = server.CFG
    host = str(cfg["server"]["host"])
    port = int(cfg["server"]["port"])
    url = f"http://{host}:{port}"

    use_window, why = _can_open_window(force_browser)
    if why:
        print(f"[กล้องเทพ] {why}")

    # เปิดโปรแกรมซ้ำ (ดับเบิลคลิกสองที) -> ไม่เริ่มเซิร์ฟเวอร์ตัวที่สอง แค่เปิดหน้าต่างไปหาตัวเดิม
    already = _port_open(host, port) and _healthy(url)
    if already:
        print(f"[กล้องเทพ] โปรแกรมเปิดอยู่แล้วที่ {url} — เปิดหน้าต่างใหม่ไปหาตัวเดิม")
    elif not use_window and _windowed():
        # ตัว .exe แบบไม่มีคอนโซล ถ้าต้องถอยไปโหมดเบราว์เซอร์ ผู้ใช้จะไม่มีหน้าต่างให้ปิดโปรแกรม
        # จึงส่งไม้ต่อให้ตัวคอนโซล (klongthep-cli.exe) ซึ่งมีหน้าต่างดำ ๆ ให้กดปิด
        cli = config.ROOT / "klongthep-cli.exe"
        if cli.exists():
            import subprocess
            return subprocess.call([str(cli), "serve"], cwd=str(config.ROOT))

    if not already:
        server.prepare()                       # สำรอง/กู้สถานะ/ล้างของเก่า เหมือนโหมดเว็บ
        _start_server(host, port)
        if not _wait_ready(url):
            print("[กล้องเทพ] เซิร์ฟเวอร์ไม่ตอบสนอง ดู data/logs/klongthep.log")
            return 1

    if not use_window:
        return _browser_mode(url, already)

    import webview
    api = _Api()
    try:
        win = webview.create_window(
            APP_TITLE, url,
            width=1500, height=950, min_size=(1100, 700),
            text_select=True, zoomable=True, js_api=api,
        )
        api._window = win
        # บน Windows pywebview เลือก EdgeChromium (WebView2) ให้เองถ้ามี
        webview.start(private_mode=False)     # private_mode=False = จำชื่อผู้ใช้/ค่าที่ตั้งไว้ในหน้าเว็บ
    except TypeError:
        webview.start()
    except Exception as exc:  # noqa: BLE001
        print(f"[กล้องเทพ] เปิดหน้าต่างไม่ได้ ({exc}) จึงเปิดในเบราว์เซอร์แทน")
        return _browser_mode(url, already)

    # ปิดหน้าต่าง = ปิดโปรแกรม (ถ้าเซิร์ฟเวอร์เป็นของเรา) ไม่ทิ้งโปรเซสค้างไว้กินการ์ดจอ
    # งานประมวลผลวิดีโอที่กำลังทำอยู่เป็นอีกโปรเซส จะทำต่อจนเสร็จเอง
    if not already:
        print("[กล้องเทพ] ปิดโปรแกรม")
        try:
            sys.stdout.flush()
        except Exception:  # noqa: BLE001
            pass
        os._exit(0)
    return 0


def _browser_mode(url: str, already: bool) -> int:
    import webbrowser
    webbrowser.open(url)
    if already:
        return 0
    print("=" * 58)
    print("  กล้องเทพ - ระบบวิเคราะห์ภาพวงจรปิด")
    print(f"  เปิดอยู่ที่: {url}")
    print("  ปิดโปรแกรมด้วย Ctrl+C หรือปิดหน้าต่างนี้")
    print("=" * 58)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        return 0
