"""Video Synopsis - ย่อวิดีโอยาวให้สั้นโดยไม่ตัดเหตุการณ์ทิ้ง

แนวคิด (Rav-Acha, Pritch, Peleg 2006/2008):
วัตถุที่เกิดคนละเวลาไม่จำเป็นต้องแสดงคนละเวลา เราย้ายแกนเวลาของวัตถุแต่ละตัว
มาซ้อนกันบนพื้นหลังเดียวกันได้ ตราบใดที่มันไม่บังกันจนดูไม่ออก

การจัดเรียงใช้วิธี greedy แบบ FGS (2024) ซึ่งเร็วกว่า simulated annealing
ของงานต้นฉบับมาก และให้ผลใกล้เคียงกันในภาพวงจรปิดทั่วไป:
  ไล่วัตถุทีละตัว ลองวางที่เวลาเริ่มต้นหนึ่ง ถ้าชนของเดิมเกินเกณฑ์ก็เลื่อนไปข้างหน้า
  ทีละก้าว จนกว่าจะหาที่ว่างพอ

ทุกวัตถุในวิดีโอย่อจำเวลาจริงของตัวเองไว้ คลิกแล้วกระโดดกลับไปดูต้นฉบับได้
"""
from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import time
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np

from . import config, db, media, tubestore

CELL = 16  # ขนาดช่องตารางที่ใช้คำนวณการชน (พิกเซล ที่ความละเอียดเรนเดอร์)

CLASS_BGR = {
    "person": (99, 178, 231),
    "bicycle": (218, 138, 181),
    "car": (224, 176, 111),
    "motorcycle": (154, 200, 121),
    "bus": (140, 160, 240),
    "truck": (120, 200, 220),
    "dog": (200, 200, 160),
    "cat": (200, 200, 160),
}
DEFAULT_BGR = (200, 200, 200)


# ------------------------------------------------------------------ พื้นหลัง
class Backgrounds:
    def __init__(self, con, video_id: int, size_wh: tuple[int, int], src_path: str):
        self.size = size_wh
        self.rows = con.execute(
            "SELECT bucket,start_sec,end_sec,path FROM backgrounds WHERE video_id=? ORDER BY bucket",
            (video_id,),
        ).fetchall()
        self.mids = [(float(r["start_sec"]) + float(r["end_sec"])) / 2.0 for r in self.rows]
        self.cache: dict[int, np.ndarray] = {}
        self.src_path = src_path
        self._fallback: np.ndarray | None = None

    def _fallback_bg(self) -> np.ndarray:
        if self._fallback is not None:
            return self._fallback
        frames = []
        cap = cv2.VideoCapture(self.src_path)
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if n > 0:
            for k in range(0, 25):
                cap.set(cv2.CAP_PROP_POS_FRAMES, int(n * k / 25.0))
                ok, fr = cap.read()
                if ok:
                    frames.append(cv2.resize(fr, self.size, interpolation=cv2.INTER_AREA))
        cap.release()
        if frames:
            self._fallback = np.median(np.stack(frames), axis=0).astype(np.uint8)
        else:
            self._fallback = np.full((self.size[1], self.size[0], 3), 40, np.uint8)
        return self._fallback

    def at(self, sec: float) -> np.ndarray:
        if not self.rows:
            return self._fallback_bg()
        i = int(np.argmin([abs(m - sec) for m in self.mids]))
        img = self.cache.get(i)
        if img is None:
            img = cv2.imread(self.rows[i]["path"])
            if img is None:
                return self._fallback_bg()
            if (img.shape[1], img.shape[0]) != self.size:
                img = cv2.resize(img, self.size, interpolation=cv2.INTER_AREA)
            if len(self.cache) > 12:
                self.cache.clear()
            self.cache[i] = img
        return img


def _ensure_pairs(con, video_id: int) -> None:
    """ยังไม่เคยจับคู่คนขับกับรถ ก็จับให้ก่อนเรนเดอร์

    เดิมต้องให้ผู้ใช้ไปกดปุ่มเอง ซึ่งแปลว่าถ้าไม่รู้ว่ามีปุ่มก็จะได้วิดีโอย่อ
    ที่รถวิ่งเองกับคนลอยกลางถนนต่อไปเรื่อย ๆ โดยไม่รู้ว่าทำไม
    งานนี้อ่านจากข้อมูลที่มีอยู่แล้ว ใช้เวลาไม่กี่วินาที จึงทำให้เลยดีกว่า
    """
    try:
        n = con.execute("SELECT COUNT(*) FROM tubes WHERE video_id=? AND group_id IS NOT NULL",
                        (int(video_id),)).fetchone()[0]
        if n:
            return
        # ไม่มีรถสองล้อหรือไม่มีคนเลย ก็ไม่ต้องเสียเวลาไล่จุดเส้นทาง
        ride = con.execute("SELECT 1 FROM tubes WHERE video_id=? AND cls IN ('motorcycle','bicycle')"
                           " LIMIT 1", (int(video_id),)).fetchone()
        ppl = con.execute("SELECT 1 FROM tubes WHERE video_id=? AND cls='person' LIMIT 1",
                          (int(video_id),)).fetchone()
        if not (ride and ppl):
            return
        from . import riders
        r = riders.pair(int(video_id), con)
        if r["groups"]:
            print(f"[กล้องเทพ] จับคู่คนขับกับรถสองล้อให้อัตโนมัติ {r['groups']:,} คัน")
    except Exception as exc:  # noqa: BLE001
        print(f"[เตือน] จับคู่คนขับอัตโนมัติไม่สำเร็จ ({exc})")


def _ensure_stitched(con, video_id: int) -> None:
    """ต่อร่องรอยที่ขาดให้อัตโนมัติ ถ้าวิดีโอนี้ยังไม่เคยทำ

    ตัวติดตามทำหลุดเป็นระยะ วัตถุหนึ่งตัวจึงถูกบันทึกเป็นหลายชิ้นสั้น ๆ
    ถ้าไม่ต่อกลับ วิดีโอย่อจะเห็นแค่ช่วงกลาง ไม่เห็นตอนเข้าและตอนออก
    """
    try:
        row = con.execute("SELECT stitched FROM videos WHERE id=?",
                          (int(video_id),)).fetchone()
        if row is None or (row[0] or 0):
            return
        from . import stitch as _stitch
        st = _stitch.stitch(int(video_id), con)
        con.execute("UPDATE videos SET stitched=1 WHERE id=?", (int(video_id),))
        con.commit()
        if st["merged"]:
            print(f"[กล้องเทพ] ต่อร่องรอยที่ขาดให้อัตโนมัติ {st['merged']:,} ชิ้น "
                  f"เหลือวัตถุ {st['after']:,} ตัว")
    except Exception as exc:  # noqa: BLE001
        print(f"[เตือน] ต่อร่องรอยอัตโนมัติไม่สำเร็จ ({exc})")


# ---------------------------------------------------------------- จัดเรียงเวลา
def arrange(tubes: list[dict], gw: int, gh: int, cfg: dict, chrono: float = 0.25) -> list[dict]:
    """หาว่าแต่ละ tube ควรเริ่มที่เฟรมไหนของวิดีโอย่อ"""
    s = cfg["synopsis"]
    thresh = float(s["collision_threshold"])
    step = max(1, int(s["shift_step"]))

    tubes = sorted(tubes, key=lambda t: t["start_sec"])

    # รถสองล้อกับคนขับถูกผูกเป็นกลุ่มเดียวกันไว้แล้ว ต้องวางพร้อมกันเสมอ
    # ไม่งั้นวิดีโอย่อจะได้รถวิ่งเองกับคนลอยกลางถนน ซึ่งใช้เป็นหลักฐานไม่ได้
    # จึงจัดเรียงเป็น "หน่วย" โดยหนึ่งหน่วยคือวัตถุเดี่ยวหรือทั้งกลุ่ม
    units: list[dict] = []
    by_group: dict[int, list] = {}
    for t in tubes:
        gid = t.get("group_id")
        if gid is None:
            units.append({"members": [t]})
        else:
            by_group.setdefault(gid, []).append(t)
    for gid, ms in by_group.items():
        units.append({"members": ms})

    for u in units:
        ms = u["members"]
        base = min(m["f0"] for m in ms)
        # เลื่อนเวลาของสมาชิกให้อ้างจุดเริ่มเดียวกัน จะได้คงระยะห่างเดิมไว้
        for m in ms:
            m["_delta"] = int(m["f0"] - base)
        rels, gbs = [], []
        for m in ms:
            rels.append(m["rel"] + m["_delta"])
            gbs.append(m["gboxes"])
        rel_all = np.concatenate(rels)
        gb_all = np.concatenate(gbs, axis=0)
        order = np.argsort(rel_all, kind="stable")
        u["rel"] = rel_all[order].astype(np.int32)
        u["gboxes"] = gb_all[order]
        u["start_sec"] = min(m["start_sec"] for m in ms)

    units.sort(key=lambda u: u["start_sec"])
    lens = [int(u["rel"][-1]) + 1 for u in units]
    total = sum(lens) or 1
    longest = max(lens) if lens else 1
    est_T = max(longest, int(total / 6))

    # ตรวจจับทำทุก stride เฟรม ทำให้ tube แต่ละตัวมีข้อมูลคนละชุดเฟรม
    # ถ้าเทียบการชนแบบเฟรมต่อเฟรมตรง ๆ วัตถุสองตัวที่เริ่มต่างกันไม่กี่เฟรม
    # จะไม่มีเฟรมร่วมกันเลยและกลายเป็น "ไม่ชน" ทั้งที่ทับกันสนิท
    # จึงยุบเวลาเป็นช่องละ tbin เฟรมก่อนเทียบ
    steps = [int(np.median(np.diff(t["rel"]))) for t in tubes if len(t["rel"]) > 1]
    tbin = max(1, int(np.median(steps))) if steps else 1

    occ: dict[int, np.ndarray] = defaultdict(lambda: np.zeros((gh, gw), np.uint8))
    placed: list[dict] = []
    n = len(units)

    for i, u in enumerate(units):
        rel = u["rel"]
        gb = u["gboxes"]
        # เลือกเฟรมตัวอย่างสำหรับคิดค่าการชน (ไม่ต้องคิดทุกเฟรม)
        nrel = len(rel)
        sample = np.linspace(0, nrel - 1, min(nrel, 18)).astype(int)
        sample = np.unique(sample)

        ideal = int(chrono * (i / max(n - 1, 1)) * est_T)
        o = max(0, ideal - ideal % step)
        limit = ideal + est_T * 3 + longest

        best_o, best_ratio = o, 1e9
        while o <= limit:
            worst = 0.0
            total_hits = 0
            total_cells = 0
            for j in sample:
                a = occ.get(int((o + rel[j]) // tbin))
                x1, y1, x2, y2 = gb[j]
                cells = max(1, (x2 - x1) * (y2 - y1))
                hits = int(np.count_nonzero(a[y1:y2, x1:x2])) if a is not None else 0
                total_hits += hits
                total_cells += cells
                worst = max(worst, hits / cells)
            # ถ่วงน้ำหนักทั้งค่าเฉลี่ยและช่วงที่แย่ที่สุด
            # ถ้าดูแต่ค่าเฉลี่ย วัตถุจะกองรวมกันเป็นกระจุกในบางวินาที
            ratio = 0.45 * (total_hits / max(total_cells, 1)) + 0.55 * worst
            if ratio < best_ratio:
                best_ratio, best_o = ratio, o
            if ratio <= thresh:
                break
            o += step

        o = best_o
        n_rel = len(rel)
        for j in range(n_rel):
            x1, y1, x2, y2 = gb[j]
            b0 = int((o + rel[j]) // tbin)
            b1 = int((o + rel[j + 1]) // tbin) if j + 1 < n_rel else b0
            for b in range(b0, max(b0, b1) + 1):
                occ[b][y1:y2, x1:x2] = 1
        for m in u["members"]:
            m = dict(m)
            m["out_start"] = int(o + m["_delta"])
            m["out_end"] = int(m["out_start"] + m["rel"][-1])
            m["collision"] = round(float(best_ratio), 4)
            m["group_size"] = len(u["members"])
            placed.append(m)

    return placed


# -------------------------------------------------------------------- เรนเดอร์
def _hms(sec: float) -> str:
    """แปลงวินาทีเป็น ชช:นน:วว สำหรับป้าย 'เวลาในไฟล์'

    ตัดเศษทิ้ง (ไม่ปัดขึ้น) ให้ตรงกับวิธีคิดของ db.wall_clock
    ไม่งั้นโหมด "ทั้งสองอย่าง" จะแสดงสองบรรทัดต่างกัน 1 วินาที
    """
    s = max(0, int(sec))
    return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"


def _ampm(started_at: str | None, sec: float) -> str:
    """เวลาแบบ 12 ชั่วโมง มี AM/PM ไม่เอาวินาที - รูปแบบเดียวกับ BriefCam

    ถ้ายังไม่ได้ตั้งเวลาเริ่มบันทึก การแปลงเป็น AM/PM ไม่มีความหมาย
    จึงถอยไปใช้เวลาในไฟล์แทน ดีกว่าโชว์เลขที่ตีความผิดได้
    """
    if not started_at:
        return _hms(sec)
    txt = db.wall_clock(started_at, sec)
    part = txt.split(" ")[-1]
    try:
        hh, mm = part.split(":")[:2]
        h = int(hh)
    except ValueError:
        return part
    ap = "AM" if h < 12 else "PM"
    return f"{h % 12 or 12}:{mm} {ap}"



# ------------------------------------------------------------------ เรนเดอร์
def _bg_timeline(placed: list[dict], T: int, duration: float) -> np.ndarray:
    """เวลาเฉลี่ย (วินาทีต้นฉบับ) ของวัตถุที่แสดงอยู่ในแต่ละเฟรมผลลัพธ์ หลังทำให้เรียบแล้ว

    ใช้เลือกภาพพื้นหลังให้กลมกลืนกับวัตถุที่กำลังแสดง คำนวณล่วงหน้าทั้งเส้นเวลาด้วย
    difference array (O(N+T)) เพื่อให้ทุกโปรเซสที่เรนเดอร์คนละช่วง ได้พื้นหลังตรงกันเป๊ะ
    """
    cnt = np.zeros(T + 1, np.float64)
    tot = np.zeros(T + 1, np.float64)
    for tb in placed:
        a = int(tb["out_start"])
        b = min(T, int(tb["out_start"]) + int(tb["rel"][-1]) + 1)
        if b <= a:
            continue
        cnt[a] += 1
        cnt[b] -= 1
        tot[a] += tb["start_sec"]
        tot[b] -= tb["start_sec"]
    cnt = np.cumsum(cnt)[:T]
    tot = np.cumsum(tot)[:T]
    mean = np.where(cnt > 0, tot / np.maximum(cnt, 1), duration / 2.0)
    out = np.empty(T, np.float64)
    sm = None
    for t in range(T):
        sm = mean[t] if sm is None else sm * 0.94 + mean[t] * 0.06
        out[t] = sm
    return out


class _LabelCache:
    """ป้ายเวลา: วาดตัวอักษรครั้งเดียวต่อข้อความ แล้วแปะซ้ำ

    cv2.putText แบบมีขอบดำเป็นงานหนักอันดับสองของการเรนเดอร์ (วาด 2 รอบต่อป้ายต่อเฟรม)
    แต่ข้อความเดิมซ้ำกันเป็นสิบ ๆ เฟรม (เวลาเปลี่ยนวินาทีละครั้ง) จึงวาดเก็บไว้แล้วแปะแทน
    """
    FONT = cv2.FONT_HERSHEY_SIMPLEX
    SCALE = 0.42

    def __init__(self):
        self.items: dict[tuple, tuple] = {}

    def get(self, txt: str, col: tuple) -> tuple[np.ndarray, np.ndarray, int]:
        key = (txt, col)
        it = self.items.get(key)
        if it is None:
            (tw, th), base = cv2.getTextSize(txt, self.FONT, self.SCALE, 3)
            w, h = tw + 6, th + base + 6
            img = np.zeros((h, w, 3), np.uint8)
            msk = np.zeros((h, w), np.uint8)
            org = (3, 3 + th)
            cv2.putText(msk, txt, org, self.FONT, self.SCALE, 255, 3, cv2.LINE_AA)
            cv2.putText(img, txt, org, self.FONT, self.SCALE, col, 1, cv2.LINE_AA)
            it = (img, msk, 3 + th)
            if len(self.items) > 4000:
                self.items.clear()
            self.items[key] = it
        return it

    def blit(self, canvas: np.ndarray, txt: str, x: int, baseline_y: int, col: tuple) -> None:
        img, msk, asc = self.get(txt, col)
        h, w = msk.shape
        x0, y0 = x - 3, baseline_y - asc
        H, W = canvas.shape[:2]
        cx0, cy0 = max(0, x0), max(0, y0)
        cx1, cy1 = min(W, x0 + w), min(H, y0 + h)
        if cx1 <= cx0 or cy1 <= cy0:
            return
        sub = (slice(cy0 - y0, cy1 - y0), slice(cx0 - x0, cx1 - x0))
        # คัดลอกเฉพาะพิกเซลตัวอักษรลงบนภาพโดยตรง (ใน C) เร็วกว่า boolean index ของ numpy ~2.5 เท่า
        cv2.copyTo(np.ascontiguousarray(img[sub]), np.ascontiguousarray(msk[sub]), canvas[cy0:cy1, cx0:cx1])


def _label_lines(tb: dict, j: int, started_at, time_mode: str) -> list[str]:
    sec_here = float(tb["secs"][j])
    clock = db.wall_clock(started_at, sec_here)
    clock = clock.split(" ")[-1] if " " in clock else clock
    infile = _hms(sec_here)
    if time_mode == "file":
        return [infile]
    if time_mode == "ampm":
        return [_ampm(started_at, sec_here)]
    if time_mode == "both":
        return [clock, infile]
    return [clock]


def _render_segment(job: dict, a: int, b: int, seg_path: str, prog_path: str | None = None,
                    encoder: str | None = None, on_progress=None) -> dict:
    """เรนเดอร์เฟรมผลลัพธ์ [a, b) ลงไฟล์ seg_path — เรียกได้ทั้งในโปรเซสหลักและโปรเซสลูก

    คืน boxlog {tube_id: [[t, x, y, w, h, src_sec], ...]} ของช่วงนั้น
    """
    placed = job["placed"]
    rw, rh = job["rw"], job["rh"]
    show_ts, show_box = job["show_ts"], job["show_box"]
    started_at, time_mode = job["started_at"], job["time_mode"]
    bg_mean = job["bg_mean"]

    con = db.connect()
    try:
        bgs = Backgrounds(con, job["video_id"], (rw, rh), job["src_path"])
    finally:
        con.close()
    labels = _LabelCache()
    writer = media.FrameWriter(seg_path, rw, rh, job["fps"], encoder=encoder or job["encoder"])

    # วัตถุที่ต้องแสดงในช่วงนี้: เริ่มก่อนหรือระหว่างช่วง และยังไม่จบก่อนช่วงเริ่ม
    starts: dict[int, list[dict]] = defaultdict(list)
    active: dict[int, dict] = {}
    for tb in placed:
        s0, s1 = int(tb["out_start"]), int(tb["out_start"]) + int(tb["rel"][-1])
        if s1 < a or s0 >= b:
            continue
        starts[max(s0, a)].append(tb)

    boxlog: dict[int, list] = defaultdict(list)
    canvas = np.empty((rh, rw, 3), np.uint8)
    try:
        for t in range(a, b):
            for tb in starts.get(t, []):
                tb = dict(tb)
                tb["data"] = tubestore.TubeData(tb["data_path"])
                tb["_j"] = -1
                active[tb["id"]] = tb

            np.copyto(canvas, bgs.at(float(bg_mean[t])))

            drop = []
            for tid, tb in active.items():
                local = t - tb["out_start"]
                rel = tb["rel"]
                if local > rel[-1]:
                    drop.append(tid)
                    continue
                j = int(np.searchsorted(rel, local, side="right")) - 1
                j = max(0, min(len(rel) - 1, j))

                # ตำแหน่งกล่องแบบต่อเนื่อง (ลดอาการกระตุกเพราะข้ามเฟรม)
                box = tb["sboxes"][j].astype(np.float32)
                if j + 1 < len(rel):
                    span = float(rel[j + 1] - rel[j])
                    if span > 0:
                        f = min(1.0, max(0.0, (local - float(rel[j])) / span))
                        box = box * (1 - f) + tb["sboxes"][j + 1].astype(np.float32) * f

                x1, y1, x2, y2 = [int(round(u)) for u in box]
                x1, y1 = max(0, x1), max(0, y1)
                x2, y2 = min(rw, x2), min(rh, y2)
                if x2 - x1 < 2 or y2 - y1 < 2:
                    continue

                # เก็บตำแหน่งไว้ให้หน้าเว็บใช้ทำ "คลิกวัตถุแล้วกระโดดไปดูต้นฉบับ"
                if t % 5 == 0:
                    boxlog[tid].append([t, x1, y1, x2 - x1, y2 - y1,
                                        round(float(tb["secs"][j]), 2)])

                # ถอดรหัสภาพชิ้นส่วน+หน้ากากครั้งเดียวต่อเฟรมต้นฉบับ (เฟรมผลลัพธ์ใช้ซ้ำ 2-3 ครั้ง)
                if tb["_j"] != j:
                    patch = tb["data"].patch(j)
                    if patch is not None:
                        mask = tb["data"].mask(j)
                        if mask is not None and mask.size:
                            alpha = mask
                        else:
                            alpha = np.full(patch.shape[:2], 255, np.uint8)
                            cv2.rectangle(alpha, (0, 0), (patch.shape[1] - 1, patch.shape[0] - 1), 0, 1)
                        alpha = cv2.GaussianBlur(alpha, (0, 0), 1.1).astype(np.float32) / 255.0
                        tb["_patch"], tb["_alpha"] = patch, alpha
                    else:
                        tb["_patch"], tb["_alpha"] = None, None
                    tb["_j"] = j
                patch = tb["_patch"]
                if patch is None:
                    continue
                bw, bh = x2 - x1, y2 - y1
                pr = cv2.resize(patch, (bw, bh), interpolation=cv2.INTER_LINEAR)
                al = cv2.resize(tb["_alpha"], (bw, bh), interpolation=cv2.INTER_LINEAR)
                roi = canvas[y1:y2, x1:x2]
                # ผสมภาพแบบ uint8 ใน C ไม่ต้องแปลงเป็น float ไป-กลับใน Python
                canvas[y1:y2, x1:x2] = cv2.blendLinear(pr, roi, al, 1.0 - al)

                col = CLASS_BGR.get(tb["cls"], DEFAULT_BGR)
                if show_box:
                    cv2.rectangle(canvas, (x1, y1), (x2, y2), col, 1, cv2.LINE_AA)
                # ในกลุ่มรถ+คนขับ ให้ขึ้นป้ายเวลาแค่ครั้งเดียวที่ตัวรถ
                gid = tb.get("group_id")
                leader = (gid is None) or (gid == tb["id"])
                if show_ts and leader:
                    lines = _label_lines(tb, j, started_at, time_mode)
                    # วางป้ายไว้เหนือกรอบ ถ้าชิดขอบบนก็ย้ายลงใต้กรอบ
                    top = y1 - 4 - 12 * (len(lines) - 1)
                    ty0 = top if top > 10 else y2 + 12
                    for li, txt in enumerate(lines):
                        labels.blit(canvas, txt, x1, ty0 + 12 * li, col)

            for tid in drop:
                active.pop(tid, None)

            writer.write(canvas)
            if t % 30 == 0:
                if on_progress:
                    on_progress(t - a + 1)
                if prog_path:
                    try:
                        Path(prog_path).write_text(str(t - a + 1))
                    except OSError:
                        pass
    finally:
        writer.close()
    if prog_path:
        try:
            Path(prog_path).write_text(str(b - a))
        except OSError:
            pass
    return {int(k): v for k, v in boxlog.items()}


def _segment_worker(args) -> dict:
    """ตัวห่อสำหรับโปรเซสลูก: ถ้าเข้ารหัสด้วยการ์ดจอไม่สำเร็จ (เช่น เกินจำนวน session ของ NVENC)
    ให้เรนเดอร์ช่วงนั้นซ้ำด้วยซีพียู ดีกว่าล้มทั้งงาน"""
    job, a, b, seg_path, prog_path = args
    try:
        return _render_segment(job, a, b, seg_path, prog_path)
    except RuntimeError as exc:
        if job.get("encoder") == "x264":
            raise
        print(f"[เรนเดอร์] ช่วง {a}-{b} เข้ารหัสด้วยการ์ดจอไม่สำเร็จ ({exc}) — ใช้ซีพียูแทน")
        return _render_segment(job, a, b, seg_path, prog_path, encoder="x264")


def _n_workers(cfg: dict, T: int, encoder: str) -> int:
    want = (cfg.get("render") or {}).get("workers", "auto")
    cpu = os.cpu_count() or 2
    if isinstance(want, int) and want > 0:
        n = want
    else:
        n = max(1, min(cpu - 1, 8))
        if encoder == "nvenc":
            n = min(n, 3)      # การ์ดจอบ้านจำกัดจำนวน session เข้ารหัสพร้อมกัน
    # ช่วงสั้น ๆ ไม่คุ้มค่าเปิดโปรเซสใหม่ (แต่ละตัวต้องโหลด torch/cv2 ใหม่ ~2-4 วินาที)
    n = min(n, max(1, T // 400))
    return max(1, n)


def _render_parallel(job: dict, out_path: Path, cfg: dict, progress) -> dict:
    """แบ่งเฟรมผลลัพธ์เป็นช่วง ๆ ให้หลายโปรเซสเรนเดอร์พร้อมกัน แล้วต่อไฟล์ด้วย ffmpeg

    การเรนเดอร์เป็นงานของซีพียูล้วน (ถอดรหัส JPEG, ผสมภาพ, วาดป้าย) และแต่ละเฟรมไม่ขึ้นกับ
    เฟรมก่อนหน้า (พื้นหลังคำนวณล่วงหน้าแล้วใน bg_mean) จึงแบ่งงานได้เกือบเป็นเส้นตรงตามจำนวนคอร์
    """
    T = job["T"]
    enc = job["encoder"]
    if enc == "auto":
        enc = "nvenc" if media.nvenc_available() else "x264"
        job["encoder"] = enc
    n = _n_workers(cfg, T, enc)
    ff = media.ffmpeg_path()
    if n <= 1 or not ff:
        def prog(t):
            if progress:
                progress(0.05 + 0.9 * (t / max(T, 1)), f"เรนเดอร์ {t:,}/{T:,} เฟรม ({enc})")
        t0 = time.time()
        try:
            res = _render_segment(job, 0, T, str(out_path), None, on_progress=prog)
        except RuntimeError as exc:
            if enc == "x264":
                raise
            print(f"[เรนเดอร์] เข้ารหัสด้วยการ์ดจอไม่สำเร็จ ({exc}) — ใช้ซีพียูแทน")
            job["encoder"] = enc = "x264"
            res = _render_segment(job, 0, T, str(out_path), None, on_progress=prog)
        print(f"[เรนเดอร์] {T:,} เฟรม โปรเซสเดียว ({enc}) ใน {time.time() - t0:.1f} วินาที")
        return res

    # ช่วงยาวเท่า ๆ กัน ตัดที่เลขคู่ไม่จำเป็น เพราะทุกช่วงเข้ารหัสด้วยพารามิเตอร์เดียวกัน
    bounds = [int(round(T * k / n)) for k in range(n + 1)]
    segs = []
    tmp = config.DIR_OUT / f".{out_path.stem}_parts"
    tmp.mkdir(parents=True, exist_ok=True)
    for k in range(n):
        a, b = bounds[k], bounds[k + 1]
        if b <= a:
            continue
        segs.append((a, b, str(tmp / f"part{k:02d}.mp4"), str(tmp / f"part{k:02d}.prog")))

    import concurrent.futures as cf
    boxlog: dict[int, list] = defaultdict(list)
    t0 = time.time()
    try:
        with cf.ProcessPoolExecutor(max_workers=len(segs)) as ex:
            futs = [ex.submit(_segment_worker, (job, a, b, sp, pp)) for a, b, sp, pp in segs]
            pending = set(futs)
            while pending:
                done, pending = cf.wait(pending, timeout=1.0, return_when=cf.FIRST_COMPLETED)
                for f in done:
                    for k, v in f.result().items():      # ถ้าโปรเซสลูกพัง จะ raise ตรงนี้
                        boxlog[k].extend(v)
                if progress:
                    got = 0
                    for _a, _b, _sp, pp in segs:
                        try:
                            got += int(Path(pp).read_text() or 0)
                        except (OSError, ValueError):
                            pass
                    progress(0.05 + 0.9 * (got / max(T, 1)),
                             f"เรนเดอร์ {got:,}/{T:,} เฟรม ({len(segs)} โปรเซส, {enc})")
        # ต่อไฟล์แบบไม่เข้ารหัสใหม่ (เร็วมาก) — ใช้ชื่อไฟล์สัมพัทธ์เลี่ยงปัญหาเส้นทางภาษาไทยใน concat
        lst = tmp / "list.txt"
        lst.write_text("".join(f"file '{Path(sp).name}'\n" for _a, _b, sp, _pp in segs), encoding="utf-8")
        r = subprocess.run(
            [ff, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", "list.txt",
             "-c", "copy", "-movflags", "+faststart", str(out_path)],
            cwd=str(tmp), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0:
            raise RuntimeError("ต่อไฟล์วิดีโอไม่สำเร็จ: " + r.stderr.decode("utf-8", "replace")[-300:])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"[เรนเดอร์] {T:,} เฟรม ด้วย {len(segs)} โปรเซส ({enc}) ใน {time.time() - t0:.1f} วินาที")
    for k in boxlog:
        boxlog[k].sort(key=lambda r: r[0])
    return dict(boxlog)


def render(video_id: int, tube_ids: list[int] | None, out_name: str, cfg: dict,
           chrono: float = 0.25, progress=None, time_mode: str = "clock") -> dict:
    config.ensure_dirs()
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            raise SystemExit(f"ไม่พบวิดีโอ id={video_id}")

        _ensure_stitched(con, video_id)      # ต้องต่อร่องรอยก่อนจับคู่เสมอ
        _ensure_pairs(con, video_id)

        q = "SELECT * FROM tubes WHERE video_id=?"
        args: list = [video_id]
        if tube_ids:
            q += " AND id IN (%s)" % ",".join("?" * len(tube_ids))
            args += list(tube_ids)
        q += " ORDER BY start_sec"
        rows = con.execute(q, args).fetchall()
        if not rows:
            raise SystemExit("ไม่มีวัตถุให้ย่อ ลองผ่อนตัวกรองแล้วลองใหม่")

        # เดิมโค้ดนี้ใช้ LIMIT ซึ่งจะเอาแค่วัตถุ N ตัวแรกเรียงตามเวลา
        # ผลคือวิดีโอย่อของทั้งวันจะครอบคลุมแค่ช่วงเช้า แล้วเงียบ ๆ ไม่บอกอะไรเลย
        # ในงานสืบสวน ความไม่ครบที่ไม่แจ้งเตือนอันตรายกว่าความไม่แม่น
        # จึงเปลี่ยนเป็นสุ่มให้กระจายทั่วช่วงเวลา แล้วแจ้งผู้ใช้ให้ชัดว่าถูกตัด
        total_available = len(rows)
        cap = max(1, int(cfg["synopsis"]["max_tubes"]))
        truncated = total_available > cap
        if truncated:
            keep = set(np.unique(np.linspace(0, total_available - 1, cap).astype(int)).tolist())
            # ถ้าตัดไปโดนสมาชิกกลุ่มบางตัว จะได้รถไม่มีคนขับหรือคนลอยอีก
            # จึงดึงสมาชิกที่เหลือของกลุ่มที่ถูกเลือกกลับเข้ามาให้ครบเสมอ
            gcols = rows[0].keys() if rows and hasattr(rows[0], "keys") else []
            if "group_id" in gcols:
                want = {rows[i]["group_id"] for i in keep if rows[i]["group_id"]}
                for i, r in enumerate(rows):
                    if r["group_id"] in want:
                        keep.add(i)
            rows = [rows[i] for i in sorted(keep)]

        W = int(v["width"] or 1280)
        H = int(v["height"] or 720)
        fps = float(v["fps"] or 25.0)
        rw = min(int(cfg["render"]["width"]), W)
        scale = rw / float(W)
        rw = rw - (rw % 2)
        rh = int(round(H * scale))
        rh = rh - (rh % 2)

        gw = max(1, math.ceil(rw / CELL))
        gh = max(1, math.ceil(rh / CELL))

        # เตรียมข้อมูลแต่ละ tube (เฉพาะดัชนี ยังไม่โหลดภาพ)
        tubes: list[dict] = []
        for r in rows:
            if not r["data_path"] or not Path(r["data_path"]).exists():
                continue
            frames, secs, boxes = tubestore.load_index(r["data_path"])
            if len(frames) < 2:
                continue
            rel = (frames - frames[0]).astype(np.int32)
            sb = (boxes.astype(np.float32) * scale)
            sb[:, 0] = np.clip(sb[:, 0], 0, rw - 1)
            sb[:, 1] = np.clip(sb[:, 1], 0, rh - 1)
            sb[:, 2] = np.clip(sb[:, 2], 1, rw)
            sb[:, 3] = np.clip(sb[:, 3], 1, rh)
            gb = np.stack([
                np.floor(sb[:, 0] / CELL), np.floor(sb[:, 1] / CELL),
                np.ceil(sb[:, 2] / CELL), np.ceil(sb[:, 3] / CELL),
            ], axis=1).astype(np.int32)
            gb[:, 2] = np.clip(np.maximum(gb[:, 2], gb[:, 0] + 1), 1, gw)
            gb[:, 3] = np.clip(np.maximum(gb[:, 3], gb[:, 1] + 1), 1, gh)
            keys = r.keys() if hasattr(r, "keys") else []
            gid = int(r["group_id"]) if ("group_id" in keys and r["group_id"]) else None
            tubes.append({
                "id": int(r["id"]), "cls": r["cls"], "track_id": int(r["track_id"]),
                "start_sec": float(r["start_sec"]), "end_sec": float(r["end_sec"]),
                "data_path": r["data_path"], "group_id": gid, "f0": int(frames[0]),
                "rel": rel, "secs": secs, "sboxes": sb.astype(np.int32), "gboxes": gb,
            })
        if not tubes:
            raise SystemExit("วัตถุที่เลือกไม่มีไฟล์ข้อมูลประกอบ ลองประมวลผลวิดีโอใหม่")

        if progress:
            progress(0.05, f"กำลังจัดเรียงเวลาให้วัตถุ {len(tubes):,} ตัว")
        t0 = time.time()
        placed = arrange(tubes, gw, gh, cfg, chrono)
        T = max(t["out_end"] for t in placed) + 1
        arrange_sec = time.time() - t0

        # ดัชนี: เฟรมไหนมีใครโผล่/หายบ้าง
        starts: dict[int, list[dict]] = defaultdict(list)
        for t in placed:
            starts[t["out_start"]].append(t)

        out_path = config.DIR_OUT / f"{out_name}.mp4"
        out_fps = float(cfg["render"]["fps"] or fps)
        mapping = [{
            "tube_id": tb["id"], "cls": tb["cls"],
            "out_start": tb["out_start"], "out_end": tb["out_end"],
            "src_start": round(tb["start_sec"], 2), "src_end": round(tb["end_sec"], 2),
        } for tb in sorted(placed, key=lambda x: x["out_start"])]

        job = {
            "placed": placed, "T": int(T), "rw": rw, "rh": rh, "fps": out_fps,
            "video_id": video_id, "src_path": media.readable(v), "duration": float(v["duration"] or 0),
            "show_ts": bool(cfg["synopsis"]["show_timestamp"]),
            "show_box": bool(cfg["synopsis"]["show_box"]),
            "started_at": v["started_at"], "time_mode": time_mode,
            "encoder": str((cfg.get("render") or {}).get("encoder", "auto")),
            "bg_mean": _bg_timeline(placed, int(T), float(v["duration"] or 0)),
        }
        con.close()      # ไม่ถือฐานข้อมูลค้างไว้ระหว่างเรนเเดอร์นาน ๆ (โปรเซสลูกเปิดของตัวเอง)
        con = None
        boxlog = _render_parallel(job, out_path, cfg, progress)
        for m in mapping:
            m["boxes"] = boxlog.get(m["tube_id"], [])

        span = max(1e-6, max(t["end_sec"] for t in placed) - min(t["start_sec"] for t in placed))
        result = {
            "video_id": video_id,
            "file": out_path.name,
            "url": f"/media/out/{out_path.name}",
            "frames": int(T),
            "fps": out_fps,
            "duration": round(T / max(out_fps, 1e-6), 1),
            # เทียบกับ "ช่วงเวลาที่ครอบคลุมจริง" ของวัตถุที่เลือก ไม่ใช่ความยาวทั้งไฟล์
            # ไม่งั้นการกรองช่วงเวลาแคบ ๆ จะได้ตัวเลขย่อที่เกินจริง
            "source_duration": round(span, 1),
            "video_duration": round(float(v["duration"] or 0), 1),
            "span_start": round(min(t["start_sec"] for t in placed), 1),
            "span_end": round(max(t["end_sec"] for t in placed), 1),
            "n_tubes": len(placed),
            "total_available": total_available,
            "truncated": bool(truncated),
            "max_tubes": cap,
            "width": rw, "height": rh,
            "started_at": v["started_at"],
            "arrange_sec": round(arrange_sec, 2),
            "objects": mapping,
        }
        result["compression"] = round(span / max(result["duration"], 1e-6), 1)

        with open(config.DIR_OUT / f"{out_name}.json", "w", encoding="utf-8") as fh:
            json.dump(result, fh, ensure_ascii=False)

        db.log("synopsis", {"video_id": video_id, "tubes": len(placed),
                            "duration": result["duration"], "file": out_path.name})
        if progress:
            progress(1.0, "เสร็จแล้ว")
        return result
    finally:
        if con is not None:
            con.close()
