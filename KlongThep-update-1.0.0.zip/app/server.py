"""เว็บเซิร์ฟเวอร์ในเครื่อง - หน้าค้นหา ไทม์ไลน์ และการเรนเดอร์วิดีโอย่อ

ทุกอย่างทำงานบนเครื่องตัวเอง ไม่มีการส่งข้อมูลออกอินเทอร์เน็ต
"""
from __future__ import annotations

import datetime
import json
import os
import subprocess
import sys
import threading
import urllib.parse
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import (FileResponse, HTMLResponse, JSONResponse, Response,
                               StreamingResponse)

from . import (config, dataset, db, guard, maintain, media, paths as paths_mod, riders,
               search, stats, stitch as stitch_mod, synopsis, updater)
from .version import __version__

CFG = config.load()
RUN_MODE = "serve"          # "serve" = เปิดผ่านเบราว์เซอร์, "app" = หน้าต่างโปรแกรม (desktop.py ตั้งให้)

# เผื่อกรณีที่เซิร์ฟเวอร์ถูกเรียกตรง ๆ ไม่ผ่าน cli.py ฐานข้อมูลต้องพร้อมเสมอ
# รวมถึงการอัปเดตโครงสร้างเมื่อเพิ่มฟีเจอร์ใหม่ ทำซ้ำได้ ไม่มีผลข้างเคียง
db.init()

app = FastAPI(title="กล้องเทพ", docs_url=None, redoc_url=None)

_jobs_lock = threading.Lock()


@app.exception_handler(Exception)
async def _any_error(request: Request, exc: Exception):
    """ข้อผิดพลาดที่หลุดมาถึงตรงนี้ต้องไม่กลายเป็นหน้าจอขาว ๆ กับ traceback ภาษาอังกฤษ

    ลงล็อกเต็ม ๆ ไว้ให้คนซ่อม ส่วนผู้ใช้ได้ข้อความสั้น ๆ ที่พอบอกได้ว่าเกิดอะไร
    """
    import traceback
    print(f"[ผิดพลาด] {request.method} {request.url.path}: {type(exc).__name__}: {exc}")
    traceback.print_exc()
    msg = str(exc) or type(exc).__name__
    if isinstance(exc, __import__("sqlite3").OperationalError):
        if "locked" in msg or "busy" in msg:
            msg = "ฐานข้อมูลกำลังถูกใช้งานอยู่ ลองใหม่อีกครั้งในไม่กี่วินาที"
        elif "disk I/O" in msg or "readonly" in msg:
            msg = "เขียนฐานข้อมูลไม่ได้ — ตรวจว่าดิสก์ไม่เต็มและโฟลเดอร์ไม่ได้อยู่บนไดรฟ์เครือข่าย"
    elif isinstance(exc, (FileNotFoundError, PermissionError)):
        msg = f"เข้าถึงไฟล์ไม่ได้: {msg}"
    elif isinstance(exc, MemoryError):
        msg = "หน่วยความจำไม่พอ ปิดโปรแกรมอื่นแล้วลองใหม่"
    return JSONResponse(status_code=500,
                        content={"detail": f"{msg} (ดูรายละเอียดใน data/logs/klongthep.log)"})


@app.middleware("http")
async def _remember_user(request: Request, call_next):
    """หน้าเว็บส่งชื่อผู้ใช้มากับทุกคำขอ เพื่อให้ประวัติการใช้งานระบุตัวได้จริง"""
    # หน้าเว็บเข้ารหัสชื่อมาแบบ percent-encoding เพราะ HTTP header ส่งภาษาไทยตรง ๆ ไม่ได้
    raw = (request.headers.get("x-user") or "").strip()
    try:
        who = urllib.parse.unquote(raw)[:80]
    except Exception:  # noqa: BLE001
        who = raw[:80]
    token = db.CURRENT_USER.set(who or "ไม่ระบุชื่อ")
    try:
        return await call_next(request)
    finally:
        db.CURRENT_USER.reset(token)


# --------------------------------------------------------------- ไฟล์หน้าเว็บ
@app.get("/", response_class=HTMLResponse)
def index() -> HTMLResponse:
    return HTMLResponse((config.WEB_DIR / "index.html").read_text(encoding="utf-8"))


@app.get("/app.js")
def appjs() -> Response:
    return Response((config.WEB_DIR / "app.js").read_text(encoding="utf-8"),
                    media_type="application/javascript; charset=utf-8")


@app.get("/style.css")
def appcss() -> Response:
    return Response((config.WEB_DIR / "style.css").read_text(encoding="utf-8"),
                    media_type="text/css; charset=utf-8")


# ------------------------------------------------------------------ สตรีมวิดีโอ
def _range_stream(path: str, request: Request) -> Response:
    size = os.path.getsize(path)
    rng = request.headers.get("range")
    ctype = "video/mp4"
    if not rng:
        return FileResponse(path, media_type=ctype,
                            headers={"Accept-Ranges": "bytes", "Cache-Control": "no-cache"})
    try:
        units, _, rest = rng.partition("=")
        start_s, _, end_s = rest.partition("-")
        start = int(start_s) if start_s else 0
        end = int(end_s) if end_s else size - 1
    except ValueError:
        raise HTTPException(416, "ช่วงข้อมูลไม่ถูกต้อง")
    start = max(0, min(start, size - 1))
    end = max(start, min(end, size - 1))
    length = end - start + 1

    def gen():
        with open(path, "rb") as fh:
            fh.seek(start)
            left = length
            while left > 0:
                chunk = fh.read(min(1 << 20, left))
                if not chunk:
                    break
                left -= len(chunk)
                yield chunk

    return StreamingResponse(gen(), status_code=206, media_type=ctype, headers={
        "Content-Range": f"bytes {start}-{end}/{size}",
        "Accept-Ranges": "bytes",
        "Content-Length": str(length),
        "Cache-Control": "no-cache",
    })


@app.get("/media/video/{video_id}")
def media_video(video_id: int, request: Request):
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
    finally:
        con.close()
    if not v:
        raise HTTPException(404, "ไม่พบวิดีโอ")
    path = v["proxy_path"] or media.readable(v)
    if not path or not os.path.exists(path):
        path = media.readable(v)
    if not os.path.exists(path):
        raise HTTPException(404, "ไฟล์วิดีโอหายไปจากดิสก์")
    return _range_stream(path, request)


@app.get("/media/out/{name}")
def media_out(name: str, request: Request):
    p = config.DIR_OUT / Path(name).name
    if not p.exists():
        raise HTTPException(404, "ไม่พบไฟล์ผลลัพธ์")
    return _range_stream(str(p), request)


# ---------------------------------------------------------------------- วิดีโอ
@app.get("/api/videos")
def api_videos():
    con = db.connect()
    try:
        rows = con.execute("SELECT * FROM videos ORDER BY id DESC").fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["exists"] = bool(d["path"] and os.path.exists(d["path"]))
            out.append(d)
        return out
    finally:
        con.close()


@app.get("/api/browse")
def api_browse(path: str = ""):
    """ดูรายชื่อไฟล์วิดีโอในโฟลเดอร์ (ไว้เลือกไฟล์จากหน้าเว็บ)"""
    exts = media.VIDEO_EXTS
    base = Path(path).expanduser() if path else config.ROOT
    if not base.exists():
        raise HTTPException(404, f"ไม่พบโฟลเดอร์: {base}")
    if base.is_file():
        base = base.parent
    dirs, files = [], []
    try:
        for e in sorted(base.iterdir(), key=lambda p: p.name.lower()):
            if e.name.startswith("."):
                continue
            if e.is_dir():
                dirs.append({"name": e.name, "path": str(e)})
            elif e.suffix.lower() in exts:
                files.append({"name": e.name, "path": str(e),
                              "size_mb": round(e.stat().st_size / 1e6, 1)})
    except PermissionError:
        raise HTTPException(403, "เข้าถึงโฟลเดอร์นี้ไม่ได้")
    return {"cwd": str(base), "parent": str(base.parent), "dirs": dirs, "files": files}


@app.post("/api/ingest")
async def api_ingest(request: Request):
    body = await request.json()
    path = str(body.get("path") or "").strip()
    if not path or not os.path.exists(path):
        raise HTTPException(400, "ไม่พบไฟล์ที่ระบุ")
    args = _cli_cmd() + ["ingest", path]
    if body.get("started_at"):
        args += ["--start", str(body["started_at"])]
    if body.get("limit_sec"):
        args += ["--limit-sec", str(body["limit_sec"])]
    if guard.free_gb() < guard.MIN_FREE_GB:
        raise HTTPException(400, f"พื้นที่ดิสก์เหลือ {guard.free_gb():.1f} GB ไม่พอ ลบวิดีโอเก่าออกก่อน")
    _spawn(args)
    holder = guard.lock_holder()
    db.log("ingest_start", {"path": path})
    if holder:
        return {"ok": True, "message": f"เข้าคิวแล้ว — จะเริ่มหลัง {Path(holder.get('path', '')).name} เสร็จ"}
    return {"ok": True, "message": "เริ่มประมวลผลแล้ว ดูความคืบหน้าที่รายการวิดีโอ"}


def _cli_cmd() -> list[str]:
    """คำสั่งเรียกตัวเองในอีกโปรเซส

    รันจากซอร์ส = python cli.py ...   รันจาก .exe = โปรแกรม.exe ... (launcher จะส่งต่อให้ cli)
    """
    if config.FROZEN:
        # ชุดติดตั้งมีสองตัว: KlongThep.exe (หน้าต่าง) และ klongthep-cli.exe (คอนโซล)
        # งานประมวลผลเบื้องหลังใช้ตัวคอนโซล เพราะไม่ต้องโหลด WebView และพิมพ์ล็อกได้ครบ
        cli = config.ROOT / "klongthep-cli.exe"
        return [str(cli) if cli.exists() else sys.executable]
    return [sys.executable, str(config.ROOT / "cli.py")]


def _spawn(args: list[str]) -> None:
    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(args, cwd=str(config.ROOT), creationflags=creationflags)


@app.post("/api/videos/{video_id}/resume")
def api_resume(video_id: int):
    """ทำต่อจากจุดที่ค้าง สำหรับงานที่ถูกขัดจังหวะ (เครื่องดับ/ปิดหน้าต่าง)"""
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            raise HTTPException(404, "ไม่พบวิดีโอ")
        if not v["path"] or not os.path.exists(v["path"]):
            raise HTTPException(400, "ไฟล์วิดีโอต้นฉบับหายไปจากดิสก์ ทำต่อไม่ได้")
        if v["status"] == "processing" and guard.lock_holder():
            raise HTTPException(400, "วิดีโอนี้กำลังประมวลผลอยู่แล้ว")
        con.execute("UPDATE videos SET status='queued', message='รอทำต่อ' WHERE id=?", (video_id,))
        con.commit()
        args = _cli_cmd() + ["ingest", str(v["path"]), "--resume"]
        if v["started_at"]:
            args += ["--start", str(v["started_at"])]
    finally:
        con.close()
    _spawn(args)
    db.log("ingest_resume", {"video_id": video_id})
    return {"ok": True, "message": "กำลังทำต่อจากจุดที่ค้าง"}


@app.get("/api/system")
def api_system():
    """สถานะเครื่องแบบสั้น ๆ ให้หน้าเว็บโชว์ได้ตลอด"""
    holder = guard.lock_holder()
    return {
        "free_gb": round(guard.free_gb(), 1),
        "busy": bool(holder),
        "busy_file": Path(holder.get("path", "")).name if holder else None,
        "log": str(config.DATA / "logs" / "klongthep.log"),
    }


@app.get("/api/videos/{video_id}/usage")
def api_usage(video_id: int):
    """บอกว่าจะลบอะไรบ้าง ก่อนผู้ใช้ยืนยัน"""
    u = maintain.usage(video_id)
    if not u:
        raise HTTPException(404, "ไม่พบวิดีโอ")
    return u


@app.post("/api/videos/{video_id}/started_at")
async def api_set_started(video_id: int, request: Request):
    """แก้เวลาเริ่มบันทึกโดยไม่ต้องประมวลผลใหม่

    เวลาเริ่มบันทึกเป็นแค่ค่าอ้างอิงตัวเดียวที่ใช้บวกกับวินาทีในไฟล์
    ตอนแสดงผล ไม่ได้ฝังอยู่ในข้อมูลวัตถุ จึงแก้ทีหลังได้ทันที
    ถ้าตอนเพิ่มวิดีโอไม่ได้กรอก โปรแกรมจะเดาจากเวลาไฟล์ ซึ่งมักผิด
    เพราะเป็นเวลาที่ก๊อปไฟล์มา ไม่ใช่เวลาที่กล้องบันทึก
    """
    body = await request.json()
    val = (body.get("started_at") or "").strip()
    if val:
        val = val.replace("T", " ")
        if len(val) == 16:
            val += ":00"
        try:
            datetime.datetime.strptime(val, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            raise HTTPException(400, "รูปแบบเวลาไม่ถูกต้อง ต้องเป็น ปปปป-ดด-วว ชช:นน:ss")
    else:
        val = None
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
        if not v:
            raise HTTPException(404, "ไม่พบวิดีโอ")
        old = v["started_at"]
        con.execute("UPDATE videos SET started_at=? WHERE id=?", (val, video_id))
        con.commit()
    finally:
        con.close()
    db.log("แก้เวลาเริ่มบันทึก", {"video_id": video_id, "เดิม": old, "ใหม่": val})
    return {"ok": True, "video_id": video_id, "started_at": val, "old": old}


@app.post("/api/videos/{video_id}/delete")
def api_delete(video_id: int):
    r = maintain.delete_video(video_id)
    if not r:
        raise HTTPException(404, "ไม่พบวิดีโอ")
    return r


# --------------------------------------------------------------- ดูแลข้อมูล
@app.get("/api/maintenance")
def api_maintenance():
    m = CFG.get("maintenance") or {}
    days = int(m.get("retention_days", 0) or 0)
    return {
        "retention_days": days,
        "expiring": maintain.expired(days) if days > 0 else [],
        "backup_keep": int(m.get("backup_keep", 7)),
        "backups": sorted((p.name for p in maintain.backup_dir().glob("klongthep-*.db")),
                          reverse=True),
        "disk": maintain.disk_usage(),
    }


@app.post("/api/maintenance/backup")
def api_backup():
    return maintain.backup_db(int((CFG.get("maintenance") or {}).get("backup_keep", 7)),
                              force=True)


@app.post("/api/maintenance/cleanup")
def api_cleanup():
    days = int((CFG.get("maintenance") or {}).get("retention_days", 0) or 0)
    if days <= 0:
        raise HTTPException(400, "ยังไม่ได้ตั้งอายุการเก็บข้อมูลใน config.yaml")
    return maintain.cleanup(days)


@app.get("/api/all/summary")
def api_summary_all():
    return stats.summary_all()


@app.get("/api/all/timeline")
def api_timeline_all(bucket: float = 60.0, classes: str = ""):
    cls = [c for c in classes.split(",") if c] or None
    return stats.timeline_all(bucket, cls)


@app.get("/api/videos/{video_id}/summary")
def api_summary(video_id: int):
    return stats.summary(video_id)


@app.get("/api/videos/{video_id}/timeline")
def api_timeline(video_id: int, bucket: float = 60.0, classes: str = ""):
    cls = [c for c in classes.split(",") if c] or None
    return stats.timeline(video_id, bucket, cls)


@app.get("/api/videos/{video_id}/still")
def api_still(video_id: int, sec: float = 0.0):
    con = db.connect()
    try:
        v = db.get_video(con, video_id)
    finally:
        con.close()
    if not v:
        raise HTTPException(404, "ไม่พบวิดีโอ")
    row = None
    con = db.connect()
    try:
        row = con.execute(
            "SELECT path FROM backgrounds WHERE video_id=? ORDER BY bucket LIMIT 1", (video_id,)
        ).fetchone()
    finally:
        con.close()
    if row and os.path.exists(row["path"]) and sec <= 0:
        return FileResponse(row["path"], media_type="image/jpeg")
    data = media.grab_frame(media.readable(v), sec)
    if not data:
        raise HTTPException(404, "ดึงภาพนิ่งไม่สำเร็จ")
    return Response(data, media_type="image/jpeg")


@app.get("/api/videos/{video_id}/heatmap")
def api_heatmap(video_id: int, classes: str = "", t0: float | None = None, t1: float | None = None):
    f = {"classes": [c for c in classes.split(",") if c], "t0": t0, "t1": t1}
    data = stats.heatmap_png(video_id, f)
    if not data:
        raise HTTPException(404, "ไม่มีข้อมูลพอสำหรับทำภาพความหนาแน่น")
    return Response(data, media_type="image/png")


@app.post("/api/tubes/improve")
async def api_improve(request: Request):
    """ต่อร่องรอยที่ขาด แล้วจับคู่คนขับ ให้กับข้อมูลที่วิเคราะห์ไว้แล้ว

    ลำดับสำคัญ: ต้องต่อร่องรอยก่อนจับคู่เสมอ เพราะการจับคู่อ้างจาก id ของ tube
    ทำจากข้อมูลในฐานข้อมูลล้วน ๆ ไม่ต้องเปิดไฟล์วิดีโอ
    """
    body = await request.json() if await request.body() else {}
    vid = body.get("video_id")
    con = db.connect()
    try:
        if vid in (None, "", search.ALL):
            vids = [int(r["id"]) for r in con.execute(
                "SELECT id FROM videos WHERE status='done' ORDER BY id")]
        else:
            vids = [int(vid)]
        merged = groups = riders_n = 0
        before = after = 0
        for v in vids:
            st = stitch_mod.stitch(v, con)
            con.execute("UPDATE videos SET stitched=1 WHERE id=?", (v,))
            merged += st["merged"]; before += st["before"]; after += st["after"]
            rp = riders.pair(v, con)
            groups += rp["groups"]; riders_n += rp["riders"]
        con.commit()
    finally:
        con.close()
    db.log("ปรับปรุงร่องรอย", {"วิดีโอ": len(vids), "ต่อ": merged,
                               "รถที่จับคู่": groups, "คนขับ": riders_n})
    return {"ok": True, "videos": len(vids), "merged": merged,
            "before": before, "after": after, "groups": groups, "riders": riders_n}


@app.post("/api/riders/pair")
async def api_pair_riders(request: Request):
    """จับคู่คนขับกับรถสองล้อย้อนหลัง ใช้กับวิดีโอที่วิเคราะห์ไว้ก่อนมีฟีเจอร์นี้

    ทำงานจากข้อมูลที่เก็บไว้แล้วล้วน ๆ ไม่ต้องเปิดไฟล์วิดีโอ จึงเสร็จในไม่กี่วินาที
    """
    body = await request.json() if await request.body() else {}
    vid = body.get("video_id")
    if vid in (None, "", search.ALL):
        res = riders.pair_all()
    else:
        res = [riders.pair(int(vid))]
    tot_g = sum(r["groups"] for r in res)
    tot_r = sum(r["riders"] for r in res)
    db.log("จับคู่คนขับ", {"วิดีโอ": len(res), "คัน": tot_g, "คน": tot_r})
    return {"ok": True, "videos": len(res), "groups": tot_g, "riders": tot_r, "detail": res}


@app.post("/api/paths")
async def api_paths(request: Request):
    """เส้นทางการเคลื่อนที่ของวัตถุที่ตรงตัวกรอง ไว้วาดทับภาพนิ่ง"""
    f = dict(await request.json())
    return paths_mod.paths(f, limit=int(f.get("limit") or paths_mod.MAX_PATHS))


# ---------------------------------------------------------------------- ค้นหา
@app.post("/api/search")
async def api_search(request: Request):
    f = await request.json()
    limit = int(f.pop("limit", 300))
    offset = int(f.pop("offset", 0))
    res = search.search(f, limit, offset)
    db.log("search", {k: v for k, v in f.items() if v not in (None, [], "")})
    return res


@app.get("/api/tube/{tube_id}/crop")
def api_crop(tube_id: int):
    con = db.connect()
    try:
        r = con.execute("SELECT crop_path FROM tubes WHERE id=?", (tube_id,)).fetchone()
    finally:
        con.close()
    if not r or not r["crop_path"] or not os.path.exists(r["crop_path"]):
        raise HTTPException(404, "ไม่พบภาพ")
    return FileResponse(r["crop_path"], media_type="image/jpeg",
                        headers={"Cache-Control": "max-age=86400"})


@app.get("/api/tube/{tube_id}/track")
def api_track(tube_id: int):
    con = db.connect()
    try:
        rows = con.execute(
            "SELECT frame,sec,cx,cy,x1,y1,x2,y2 FROM tube_points WHERE tube_id=? ORDER BY frame",
            (tube_id,),
        ).fetchall()
        t = con.execute("SELECT * FROM tubes WHERE id=?", (tube_id,)).fetchone()
        v = db.get_video(con, int(t["video_id"])) if t else None
    finally:
        con.close()
    if not t:
        raise HTTPException(404, "ไม่พบวัตถุ")
    # ส่งข้อมูลวิดีโอไปด้วย เพราะโหมดทุกกล้องต้องรู้ว่าวัตถุนี้มาจากกล้องไหน
    vd = {}
    if v:
        vd = {"id": v["id"], "name": v["name"], "width": v["width"],
              "height": v["height"], "started_at": v["started_at"]}
    return {"tube": dict(t), "points": db.rows_to_dicts(rows), "video": vd}


# ------------------------------------------------------------------ วิดีโอย่อ
def _run_synopsis(job_id: int, video_id: int, tube_ids, chrono: float,
                  time_mode: str = "clock"):
    def prog(p, msg):
        db.job_update(job_id, progress=float(p), message=str(msg), status="running")

    try:
        db.job_update(job_id, status="running", progress=0.01, message="กำลังเตรียม")
        name = f"synopsis_{video_id}_{job_id}"
        res = synopsis.render(video_id, tube_ids, name, CFG, chrono, prog,
                              time_mode=time_mode)
        db.job_update(job_id, status="done", progress=1.0,
                      message="เสร็จแล้ว", result=res)
    except SystemExit as exc:
        db.job_update(job_id, status="error", message=str(exc))
    except Exception as exc:  # noqa: BLE001
        db.job_update(job_id, status="error", message=f"{type(exc).__name__}: {exc}")


@app.post("/api/synopsis")
async def api_synopsis(request: Request):
    body = await request.json()
    video_id = int(body["video_id"])
    chrono = float(body.get("chrono", 0.25))
    time_mode = str(body.get("time_mode") or "clock")
    if time_mode not in ("clock", "ampm", "file", "both"):
        time_mode = "clock"
    tube_ids = body.get("tube_ids")
    if not tube_ids:
        f = dict(body.get("filters") or {})
        f["video_id"] = video_id
        # ส่งวัตถุที่ตรงเงื่อนไข "ทั้งหมด" เข้าไป อย่าตัดตรงนี้
        # เพราะถ้าตัดที่นี่ ตัวเรนเดอร์จะไม่รู้ว่ามีของถูกตัดทิ้ง แล้วจะไม่เตือนผู้ใช้
        # การตัดต้องเกิดที่เดียวคือในตัวเรนเดอร์ ซึ่งเลือกให้กระจายทั่วช่วงเวลาและรายงานกลับมา
        res = search.search(f, limit=100000)
        tube_ids = [it["id"] for it in res["items"]]
    if not tube_ids:
        raise HTTPException(400, "ไม่มีวัตถุที่ตรงกับตัวกรอง")
    job_id = db.job_create("synopsis", video_id,
                           {"n": len(tube_ids), "chrono": chrono, "time_mode": time_mode})
    threading.Thread(target=_run_synopsis,
                     args=(job_id, video_id, tube_ids, chrono, time_mode),
                     daemon=True).start()
    return {"job_id": job_id, "n_tubes": len(tube_ids)}


@app.get("/api/job/{job_id}")
def api_job(job_id: int):
    j = db.job_get(job_id)
    if not j:
        raise HTTPException(404, "ไม่พบงาน")
    if j.get("result"):
        try:
            j["result"] = json.loads(j["result"])
        except Exception:  # noqa: BLE001
            pass
    return j


# ------------------------------------------------------------- สอนโมเดล
@app.get("/api/dataset/stats")
def api_ds_stats():
    st = dataset.stats()
    st["classes"] = dataset.classes(CFG)
    return st


@app.post("/api/dataset/collect")
async def api_ds_collect(request: Request):
    body = await request.json()
    r = dataset.collect(int(body["video_id"]), int(body.get("n", 40)), CFG)
    if not r.get("ok"):
        raise HTTPException(400, r.get("reason", "เก็บภาพไม่สำเร็จ"))
    return r


@app.get("/api/dataset/next")
def api_ds_next():
    f = dataset.next_frame()
    if not f:
        return {"done": True}
    full = dataset.get_frame(int(f["id"]))
    full["done"] = False
    return full


@app.get("/api/dataset/frame/{frame_id}")
def api_ds_frame(frame_id: int):
    f = dataset.get_frame(frame_id)
    if not f:
        raise HTTPException(404, "ไม่พบภาพ")
    return f


@app.get("/api/dataset/image/{frame_id}")
def api_ds_image(frame_id: int):
    f = dataset.get_frame(frame_id)
    if not f or not f.get("image_path") or not os.path.exists(f["image_path"]):
        raise HTTPException(404, "ไม่พบไฟล์ภาพ")
    return FileResponse(f["image_path"], media_type="image/jpeg",
                        headers={"Cache-Control": "no-cache"})


@app.post("/api/dataset/frame/{frame_id}")
async def api_ds_save(frame_id: int, request: Request):
    body = await request.json()
    r = dataset.save_frame(frame_id, body.get("boxes") or [],
                           str(body.get("status") or "done"))
    if not r:
        raise HTTPException(404, "ไม่พบภาพ")
    return r


@app.post("/api/dataset/export")
def api_ds_export():
    r = dataset.export(CFG)
    if not r.get("ok"):
        raise HTTPException(400, r.get("reason", "ส่งออกไม่สำเร็จ"))
    return r


# ------------------------------------------------------------------ ประวัติใช้งาน
@app.get("/api/audit")
def api_audit(limit: int = 200):
    con = db.connect()
    try:
        rows = con.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return db.rows_to_dicts(rows)
    finally:
        con.close()


# --------------------------------------------------------------- อัปเดตโปรแกรม
def _update_url() -> str:
    return str((CFG.get("update") or {}).get("url") or updater.DEFAULT_URL)


@app.get("/api/update/check")
def api_update_check(force: int = 0):
    return updater.check(_update_url(), force=bool(force))


def _run_update(job_id: int):
    def prog(msg):
        db.job_update(job_id, status="running", message=str(msg))
    try:
        info = updater.check(_update_url(), force=True)
        res = updater.apply(info, on_status=prog)
        db.job_update(job_id, status="done", progress=1.0, message="อัปเดตแล้ว รีสตาร์ทเพื่อใช้รุ่นใหม่", result=res)
    except SystemExit as exc:
        db.job_update(job_id, status="error", message=str(exc))
    except Exception as exc:  # noqa: BLE001
        db.job_update(job_id, status="error", message=f"{type(exc).__name__}: {exc}")


@app.post("/api/update/apply")
def api_update_apply():
    if guard.lock_holder():
        raise HTTPException(400, "กำลังประมวลผลวิดีโออยู่ รอให้เสร็จก่อนแล้วค่อยอัปเดต")
    job_id = db.job_create("update", None, {"from": __version__})
    threading.Thread(target=_run_update, args=(job_id,), daemon=True).start()
    return {"job_id": job_id}


@app.post("/api/update/restart")
def api_update_restart():
    """ปิดตัวเองแล้วเปิดใหม่ในโหมดเดิม — โปรเซสใหม่จะรอให้ตัวนี้ตายก่อนค่อยเริ่ม"""
    if guard.lock_holder():
        raise HTTPException(400, "กำลังประมวลผลวิดีโออยู่ รอให้เสร็จก่อน")
    args = _cli_cmd() + [RUN_MODE, "--after-pid", str(os.getpid())]

    def go():
        import time
        time.sleep(0.8)
        try:
            creationflags = 0
            if os.name == "nt":
                # แยกตัวจากคอนโซลของโปรเซสเดิม ไม่งั้นพอตัวเดิมปิด ตัวใหม่จะโดนปิดตาม
                creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
                if RUN_MODE == "serve":
                    creationflags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            subprocess.Popen(args, cwd=str(config.ROOT), creationflags=creationflags, close_fds=True)
        except Exception as exc:  # noqa: BLE001
            print(f"[อัปเดต] เปิดโปรแกรมใหม่ไม่สำเร็จ: {exc} — เปิดเองด้วย run.bat")
        print("[อัปเดต] ปิดโปรแกรมเพื่อเปิดรุ่นใหม่")
        try:
            sys.stdout.flush()
        except Exception:  # noqa: BLE001
            pass
        os._exit(0)

    threading.Thread(target=go, daemon=True).start()
    return {"ok": True, "mode": RUN_MODE}


def _startup_update_check() -> None:
    if not (CFG.get("update") or {}).get("check_on_start", True):
        return
    def go():
        import time
        time.sleep(4)
        try:
            info = updater.check(_update_url())
            if info.get("available"):
                print(f"[อัปเดต] มีรุ่นใหม่ {info['latest']} (ปัจจุบัน {__version__}) — อัปเดตได้ที่แท็บ “สรุป & ประวัติการใช้งาน”")
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=go, daemon=True).start()


@app.get("/api/health")
def api_health():
    ok_ff = media.ffmpeg_path() is not None
    try:
        import ultralytics  # noqa: F401
        ok_yolo = True
    except Exception:  # noqa: BLE001
        ok_yolo = False
    gpu = ""
    try:
        import torch

        gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "ไม่พบการ์ดจอ (ใช้ซีพียู)"
    except Exception:  # noqa: BLE001
        gpu = "ยังไม่ได้ติดตั้ง torch"
    return {"ffmpeg": ok_ff, "ultralytics": ok_yolo, "gpu": gpu,
            "model": CFG["detector"]["model"], "data_dir": str(config.DATA),
            "version": __version__, "frozen": config.FROZEN, "mode": RUN_MODE,
            "code_dir": str(config.PKG)}


def prepare() -> None:
    """เตรียมทุกอย่างก่อนเปิดให้บริการ (ใช้ร่วมกันทั้งโหมดเว็บและโหมดหน้าต่างโปรแกรม)"""
    db.init()
    config.ensure_dirs()

    # งานที่ค้างจากคราวก่อน (เครื่องดับ/ปิดหน้าต่าง) ต้องไม่ค้างเป็น "กำลังประมวลผล" ตลอดไป
    try:
        con = db.connect()
        rec = guard.recover(con)
        con.close()
        if rec["videos"] or rec["jobs"]:
            print(f"  พบงานที่ถูกขัดจังหวะ: วิดีโอ {rec['videos']} รายการ, งานเรนเดอร์ {rec['jobs']} รายการ "
                  "— กด “ทำต่อ” ในหน้าเว็บได้")
    except Exception as exc:  # noqa: BLE001
        print(f"  [เตือน] กู้สถานะงานค้างไม่สำเร็จ: {exc}")

    _startup_update_check()
    r = maintain.startup(CFG)
    b = r.get("backup") or {}
    if b.get("ok") and not b.get("skipped"):
        print(f"  สำรองฐานข้อมูลแล้ว: {Path(b['path']).name}")
    c = r.get("cleanup") or {}
    if c.get("deleted"):
        print(f"  ลบข้อมูลเกินอายุ {c['days']} วัน: {c['deleted']} รายการ "
              f"({c['freed']/1048576:.0f} MB)")


def serve() -> None:
    import uvicorn

    prepare()
    host = CFG["server"]["host"]
    port = int(CFG["server"]["port"])
    url = f"http://{host}:{port}"
    print("=" * 58)
    print("  กล้องเทพ - ระบบวิเคราะห์ภาพวงจรปิด")
    print(f"  เปิดเบราว์เซอร์ไปที่: {url}")
    print("  ปิดโปรแกรมด้วย Ctrl+C")
    print("=" * 58)
    if CFG["server"].get("open_browser"):
        threading.Timer(1.5, lambda: __import__("webbrowser").open(url)).start()
    uvicorn.run(app, host=host, port=port, log_level="warning")
