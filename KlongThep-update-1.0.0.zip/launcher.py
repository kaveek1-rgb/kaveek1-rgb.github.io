#!/usr/bin/env python3
"""จุดเริ่มของโปรแกรมเมื่อรันเป็น .exe

  ดับเบิลคลิก KlongThep.exe            -> เปิดเป็นหน้าต่างโปรแกรม
  KlongThep.exe ingest "C:\\a.mp4"      -> ทำงานเหมือน python cli.py ingest ...
  KlongThep.exe serve --port 8600       -> โหมดเว็บแบบเดิม

ตอนรันจากซอร์สก็ใช้ได้เหมือนกัน: python launcher.py

การอัปเดต: โค้ดของกล้องเทพ (app/, cli.py) ไม่ได้ถูกอัดรวมใน .exe แต่วางเป็นไฟล์ใน _internal/
ถ้าตัวอัปเดตเคยวางโฟลเดอร์ app/ กับ cli.py ไว้ "ข้าง .exe" จะใช้ชุดนั้นก่อน (รุ่นใหม่กว่า)
ต้องตั้ง sys.path ตรงนี้ก่อน import อะไรทั้งนั้น รวมถึงก่อน multiprocessing.freeze_support()
เพราะโปรเซสลูกที่เรนเดอร์วิดีโอย่อก็ต้องเห็นโค้ดชุดเดียวกัน
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_FROZEN = bool(getattr(sys, "frozen", False))
_ROOT = Path(sys.executable).resolve().parent if _FROZEN else _HERE


def _pick_code_dir() -> Path:
    if _FROZEN:
        over = _ROOT
        if (over / "app" / "__init__.py").exists() and (over / "cli.py").exists():
            return over
    return _HERE


_CODE = _pick_code_dir()
sys.path.insert(0, str(_CODE))
if _FROZEN and _CODE != _HERE:
    os.environ.setdefault("KLONGTHEP_CODE_DIR", str(_CODE))


def main() -> None:
    import cli

    argv = sys.argv[1:]
    if not argv:
        argv = ["app"]
    cli.main(argv)


if __name__ == "__main__":
    # PyInstaller + multiprocessing (ใช้ตอนเรนเดอร์หลายโปรเซส) ต้องมีบรรทัดนี้
    # ไม่งั้นโปรเซสลูกจะเปิดหน้าต่างโปรแกรมซ้อนขึ้นมาอีกอัน
    try:
        import multiprocessing
        multiprocessing.freeze_support()
    except Exception:  # noqa: BLE001
        pass
    main()
