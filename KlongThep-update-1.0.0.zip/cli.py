#!/usr/bin/env python3
"""กล้องเทพ - ระบบวิเคราะห์ภาพวงจรปิด

ใช้งาน:
  python cli.py app                            เปิดเป็นหน้าต่างโปรแกรม (ใช้บ่อยสุด)
  python cli.py serve                          เปิดเป็นเว็บ ใช้ผ่านเบราว์เซอร์
  python cli.py ingest "D:\\cctv\\กล้อง1.mp4"   ประมวลผลวิดีโอหนึ่งไฟล์
  python cli.py ingest-dir "D:\\cctv"           ประมวลผลทั้งโฟลเดอร์
  python cli.py synopsis 1                     สร้างวิดีโอย่อจากวิดีโอ id=1
  python cli.py list                           ดูรายการวิดีโอที่ประมวลผลแล้ว
  python cli.py doctor                         ตรวจว่าเครื่องพร้อมหรือยัง
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

# ให้ข้อความภาษาไทยแสดงผลถูกต้องบน Command Prompt ของ Windows
# (คอนโซลไทยใช้ code page 874 ซึ่งพิมพ์บางอักขระไม่ได้)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from app import config, db  # noqa: E402

from app.media import VIDEO_EXTS  # noqa: E402


def cmd_ingest(a) -> None:
    from app.ingest import ingest

    cfg = config.load(a.config)
    vid = ingest(a.path, started_at=a.start, cfg=cfg,
                 limit_sec=a.limit_sec, resume=bool(getattr(a, "resume", False)))
    print(f"video_id = {vid}")


def cmd_ingest_dir(a) -> None:
    from app.ingest import ingest

    cfg = config.load(a.config)
    root = Path(a.path)
    files = sorted(p for p in root.rglob("*") if p.suffix.lower() in VIDEO_EXTS)
    if not files:
        print(f"ไม่พบไฟล์วิดีโอใน {root}")
        return
    print(f"พบ {len(files)} ไฟล์")
    for i, f in enumerate(files, 1):
        print(f"\n--- [{i}/{len(files)}] {f.name} ---")
        try:
            ingest(f, started_at=None, cfg=cfg, limit_sec=a.limit_sec)
        except SystemExit as exc:
            print(f"ข้ามไฟล์นี้: {exc}")


def cmd_synopsis(a) -> None:
    from app import synopsis

    cfg = config.load(a.config)
    res = synopsis.render(a.video_id, None, a.name or f"synopsis_{a.video_id}", cfg,
                          chrono=a.chrono,
                          progress=lambda p, m: print(f"\r  {int(p*100):3d}%  {m}   ", end="", flush=True))
    print()
    print(f"ไฟล์ผลลัพธ์: {config.DIR_OUT / (res['file'])}")
    print(f"ยาว {res['duration']:.0f} วินาที จากต้นฉบับ {res['source_duration']:.0f} วินาที "
          f"(ย่อลง {res['compression']} เท่า, วัตถุ {res['n_tubes']} ตัว)")


def cmd_list(_a) -> None:
    db.init()
    con = db.connect()
    rows = con.execute("SELECT id,name,status,progress,n_tubes,duration,started_at FROM videos ORDER BY id").fetchall()
    con.close()
    if not rows:
        print("ยังไม่มีวิดีโอในระบบ")
        return
    print(f"{'id':>3}  {'สถานะ':<12} {'วัตถุ':>7}  {'ความยาว':>9}  ชื่อไฟล์")
    for r in rows:
        dur = f"{(r['duration'] or 0)/60:.1f} น."
        st = r["status"] if r["status"] != "processing" else f"{int((r['progress'] or 0)*100)}%"
        print(f"{r['id']:>3}  {st:<12} {r['n_tubes'] or 0:>7}  {dur:>9}  {r['name']}")


def cmd_delete(a) -> None:
    from app import maintain

    info = maintain.usage(a.video_id)
    if not info:
        print(f"ไม่พบวิดีโอ id={a.video_id}")
        return
    print(f"จะลบ: {info['name']}")
    print(f"  วัตถุ {info['n_tubes']:,} รายการ | ไฟล์ {info['n_files']:,} ไฟล์ | "
          f"{info['bytes']/1048576:.1f} MB")
    print(f"  ไฟล์วิดีโอต้นฉบับจะไม่ถูกลบ: {info['path']}")
    if not a.yes:
        if input("ยืนยันลบ? พิมพ์ y แล้ว Enter: ").strip().lower() not in ("y", "yes"):
            print("ยกเลิก")
            return
    r = maintain.delete_video(a.video_id)
    print(f"ลบแล้ว — คืนพื้นที่ {r['freed']/1048576:.1f} MB")


def cmd_cleanup(a) -> None:
    from app import maintain

    cfg = config.load(a.config)
    days = a.days if a.days is not None else int(
        (cfg.get("maintenance") or {}).get("retention_days", 0) or 0)
    if days <= 0:
        print("ยังไม่ได้ตั้งอายุการเก็บข้อมูล")
        print("แก้ maintenance.retention_days ใน config.yaml หรือใส่ --days")
        return
    r = maintain.cleanup(days, dry_run=a.dry_run)
    if not r["found"]:
        print(f"ไม่มีข้อมูลที่เก่ากว่า {days} วัน")
        return
    if a.dry_run:
        print(f"พบ {r['found']} รายการที่เก่ากว่า {days} วัน (ยังไม่ได้ลบ):")
        for n in r["items"]:
            print("   ", n)
        print("สั่งจริงโดยไม่ใส่ --dry-run")
    else:
        print(f"ลบแล้ว {r['deleted']} รายการ คืนพื้นที่ {r['freed']/1048576:.1f} MB")


def cmd_backup(a) -> None:
    from app import maintain

    cfg = config.load(a.config)
    r = maintain.backup_db(int((cfg.get("maintenance") or {}).get("backup_keep", 7)), force=True)
    if r.get("ok"):
        print(f"สำรองแล้ว: {r['path']}  ({r['bytes']/1048576:.1f} MB)")
        if r.get("removed_old"):
            print(f"  ลบชุดเก่าออก {r['removed_old']} ชุด")
    else:
        print("สำรองไม่สำเร็จ:", r.get("reason"))


def cmd_usage(_a) -> None:
    from app import maintain

    u = maintain.disk_usage()
    print("พื้นที่ที่ระบบใช้อยู่")
    print("-" * 40)
    for k, v in u["parts"].items():
        print(f"  {k:<14} {v/1048576:>9.1f} MB")
    print("-" * 40)
    print(f"  {'รวม':<14} {u['total']/1048576:>9.1f} MB")


def cmd_doctor(_a) -> None:
    from app import media

    print("ตรวจความพร้อมของเครื่อง")
    print("-" * 46)
    print(f"Python           : {sys.version.split()[0]}")
    for mod in ("numpy", "cv2", "yaml", "fastapi", "uvicorn"):
        try:
            m = __import__(mod)
            print(f"{mod:<17}: OK {getattr(m, '__version__', '')}")
        except ImportError:
            print(f"{mod:<17}: ไม่พบ  -> pip install -r requirements.txt")
    try:
        import ultralytics
        print(f"{'ultralytics':<17}: OK {ultralytics.__version__}")
    except ImportError:
        print(f"{'ultralytics':<17}: ไม่พบ -> pip install ultralytics  (จำเป็นสำหรับใช้งานจริง)")
    try:
        import torch
        gpu = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "ไม่พบ - จะใช้ซีพียู (ช้ากว่ามาก)"
        print(f"{'การ์ดจอ':<15}: {gpu}")
    except ImportError:
        print(f"{'torch':<17}: ไม่พบ")
    ff = media.ffmpeg_path()
    print(f"{'ffmpeg':<17}: {ff or 'ไม่พบ -> จำเป็นสำหรับแปลงไฟล์และเรนเดอร์วิดีโอย่อ'}")
    print(f"{'โฟลเดอร์ข้อมูล':<12}: {config.DATA}")


def _wait_pid(pid: int | None, seconds: float = 40.0) -> None:
    """ตอนรีสตาร์ทหลังอัปเดต: รอให้โปรเซสเดิมปิดจริง ๆ ก่อน ไม่งั้นพอร์ตยังถูกใช้อยู่"""
    if not pid:
        return
    import time
    from app import guard
    t0 = time.time()
    while guard.pid_alive(int(pid)) and time.time() - t0 < seconds:
        time.sleep(0.3)


def cmd_serve(a) -> None:
    from app import server

    _wait_pid(getattr(a, "after_pid", None))
    if a.port:
        server.CFG["server"]["port"] = a.port
    server.serve()


def cmd_app(a) -> None:
    from app import desktop, server

    _wait_pid(getattr(a, "after_pid", None))
    if a.port:
        server.CFG["server"]["port"] = a.port
    raise SystemExit(desktop.main(force_browser=bool(a.browser)))


def cmd_update(a) -> None:
    from app import updater
    from app.version import __version__

    if getattr(a, "rollback", False):
        r = updater.rollback()
        print(f"ย้อนกลับแล้ว {r['files']} ไฟล์ (จาก {r['from']}) — เปิดโปรแกรมใหม่")
        return
    url = str((config.load(a.config).get("update") or {}).get("url") or updater.DEFAULT_URL)
    info = updater.check(url, force=True)
    if not info.get("ok"):
        raise SystemExit(info.get("error"))
    if not info.get("available"):
        print(f"เป็นรุ่นล่าสุดอยู่แล้ว ({__version__})")
        return
    print(f"มีรุ่นใหม่ {info['latest']} (ปัจจุบัน {__version__})")
    if info.get("notes"):
        print("  " + str(info["notes"]).replace("\n", "\n  "))
    if not a.yes and input("อัปเดตเลยไหม? พิมพ์ y แล้ว Enter: ").strip().lower() not in ("y", "yes"):
        print("ยกเลิก")
        return
    r = updater.apply(info)
    print(f"เสร็จแล้ว {r['files']} ไฟล์ — เปิดโปรแกรมใหม่เพื่อใช้รุ่น {r['version']}")


def main(argv: list[str] | None = None) -> None:
    from app import guard
    guard.setup_logging("cli")
    p = argparse.ArgumentParser(prog="klongthep", description="กล้องเทพ - ระบบวิเคราะห์ภาพวงจรปิด")
    p.add_argument("--config", default=None, help="ไฟล์ตั้งค่า (ค่าเริ่มต้น config.yaml)")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("ingest", help="ประมวลผลวิดีโอหนึ่งไฟล์")
    s.add_argument("--resume", action="store_true",
                   help="ทำต่อจากจุดที่ค้าง (ไม่ลบข้อมูลที่วิเคราะห์ไว้แล้ว)")
    s.add_argument("path")
    s.add_argument("--start", default=None, help="เวลาจริงของวินาทีที่ 0 เช่น '2026-08-30 08:00:00'")
    s.add_argument("--limit-sec", type=float, default=None, help="ประมวลผลแค่กี่วินาทีแรก (ไว้ทดสอบ)")
    s.set_defaults(func=cmd_ingest)

    s = sub.add_parser("ingest-dir", help="ประมวลผลทุกไฟล์ในโฟลเดอร์")
    s.add_argument("path")
    s.add_argument("--limit-sec", type=float, default=None)
    s.set_defaults(func=cmd_ingest_dir)

    s = sub.add_parser("synopsis", help="สร้างวิดีโอย่อ")
    s.add_argument("video_id", type=int)
    s.add_argument("--name", default=None)
    s.add_argument("--chrono", type=float, default=0.25,
                   help="0 = ย่อสั้นที่สุด, 1 = รักษาลำดับเวลาเดิม")
    s.set_defaults(func=cmd_synopsis)

    s = sub.add_parser("list", help="ดูรายการวิดีโอ")
    s.set_defaults(func=cmd_list)

    s = sub.add_parser("delete", help="ลบวิดีโอออกจากระบบ (ไม่ลบไฟล์ต้นฉบับ)")
    s.add_argument("video_id", type=int)
    s.add_argument("--yes", action="store_true", help="ไม่ต้องถามยืนยัน")
    s.set_defaults(func=cmd_delete)

    s = sub.add_parser("cleanup", help="ลบข้อมูลที่เกินอายุการเก็บ")
    s.add_argument("--days", type=int, default=None, help="อายุเป็นวัน (ไม่ใส่ = ใช้ค่าใน config)")
    s.add_argument("--dry-run", action="store_true", help="ดูว่าจะลบอะไรบ้างโดยยังไม่ลบจริง")
    s.set_defaults(func=cmd_cleanup)

    s = sub.add_parser("backup", help="สำรองฐานข้อมูลเดี๋ยวนี้")
    s.set_defaults(func=cmd_backup)

    s = sub.add_parser("usage", help="ดูว่าระบบใช้พื้นที่เท่าไร")
    s.set_defaults(func=cmd_usage)

    s = sub.add_parser("doctor", help="ตรวจความพร้อมของเครื่อง")
    s.set_defaults(func=cmd_doctor)

    s = sub.add_parser("serve", help="เปิดเป็นเว็บ (ใช้ผ่านเบราว์เซอร์)")
    s.add_argument("--port", type=int, default=None)
    s.add_argument("--after-pid", type=int, default=None, help=argparse.SUPPRESS)
    s.set_defaults(func=cmd_serve)

    s = sub.add_parser("app", help="เปิดเป็นหน้าต่างโปรแกรม (ค่าเริ่มต้นของ run.bat)")
    s.add_argument("--port", type=int, default=None)
    s.add_argument("--browser", action="store_true", help="บังคับเปิดในเบราว์เซอร์แทนหน้าต่างโปรแกรม")
    s.add_argument("--after-pid", type=int, default=None, help=argparse.SUPPRESS)
    s.set_defaults(func=cmd_app)

    s = sub.add_parser("update", help="ตรวจและอัปเดตโปรแกรมจากเว็บ")
    s.add_argument("--yes", action="store_true", help="ไม่ต้องถามยืนยัน")
    s.add_argument("--rollback", action="store_true", help="ย้อนกลับไปรุ่นก่อนอัปเดตล่าสุด")
    s.set_defaults(func=cmd_update)

    a = p.parse_args(argv)
    # doctor คือคำสั่งไว้วินิจฉัยตอนเครื่องยังไม่พร้อม จึงต้องไม่แตะฐานข้อมูล
    if a.cmd not in ("doctor", "update"):
        db.init()
    try:
        a.func(a)
    except SystemExit as exc:
        # ข้อความที่ตั้งใจส่งถึงผู้ใช้ ให้แสดงสวย ๆ ไม่ใช่ traceback
        if exc.code not in (None, 0):
            print(f"\n[กล้องเทพ] {exc.code}")
        raise
    except KeyboardInterrupt:
        print("\n[กล้องเทพ] หยุดโดยผู้ใช้")
        raise SystemExit(130)
    except Exception as exc:  # noqa: BLE001
        import traceback
        print(f"\n[กล้องเทพ] เกิดข้อผิดพลาดที่ไม่คาดคิด: {type(exc).__name__}: {exc}")
        print("  รายละเอียดอยู่ในไฟล์ data/logs/klongthep.log")
        traceback.print_exc()
        raise SystemExit(1)


if __name__ == "__main__":
    main()
