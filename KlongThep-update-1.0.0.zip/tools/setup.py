#!/usr/bin/env python3
"""ตัวติดตั้งของกล้องเทพ

ข้อความภาษาไทยทั้งหมดอยู่ในไฟล์นี้ ไม่ได้อยู่ในไฟล์ .bat
เหตุผล: cmd.exe ของ Windows อ่านไฟล์ .bat เป็นไบต์ทีละบรรทัด
ถ้ามีตัวอักษรไทย (ซึ่งใช้หลายไบต์ต่อตัว) การนับตำแหน่งจะเพี้ยน
แล้วบรรทัดถัด ๆ ไปจะถูกตีความเป็นคำสั่งมั่ว ๆ ทั้งไฟล์
ไฟล์ .bat จึงต้องเป็นภาษาอังกฤษล้วน แล้วโยนงานทุกอย่างมาให้ Python ทำ

รันซ้ำได้เสมอ ของที่ติดตั้งไปแล้วจะไม่ทำใหม่
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENV = ROOT / ".venv"
LINE = "=" * 60

# แหล่งดาวน์โหลด PyTorch แบบใช้การ์ดจอ เรียงจากใหม่ไปเก่า
# ต้องเรียงแบบนี้เพราะ Python รุ่นใหม่ ๆ จะมีเฉพาะใน CUDA รุ่นใหม่เท่านั้น
CUDA_INDEXES = ["cu130", "cu129", "cu128", "cu126", "cu124", "cu121"]
PT = "https://download.pytorch.org/whl/"

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def out(s: str = "") -> None:
    print(s, flush=True)


def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def run(cmd: list, show: bool = True) -> int:
    if show:
        out("    $ " + " ".join(str(c) for c in cmd[2:]))
    try:
        return subprocess.run(cmd, cwd=str(ROOT)).returncode
    except FileNotFoundError:
        return 1


def probe(py: str, code: str) -> str:
    """รันโค้ดสั้น ๆ ใน venv แล้วเอาผลลัพธ์กลับมา"""
    try:
        r = subprocess.run([py, "-c", code], capture_output=True, text=True, timeout=180)
        return (r.stdout or "").strip()
    except Exception:
        return ""


def ask_yes(question: str) -> bool:
    while True:
        try:
            a = input(question + "  [y=ใช่ / n=ไม่ใช่]: ").strip().lower()
        except EOFError:
            return False
        if a in ("y", "yes", "ใช่", "ม", "มี"):
            return True
        if a in ("n", "no", "ไม่", "ไม่มี"):
            return False
        out("    ตอบ y หรือ n เท่านั้น")


def step(n: int, total: int, title: str) -> None:
    out("")
    out(f"[{n}/{total}] {title}")


TOTAL = 6


def main() -> int:
    out(LINE)
    out("  กล้องเทพ — ติดตั้ง / ซ่อมการติดตั้ง")
    out(f"  โฟลเดอร์: {ROOT}")
    out(LINE)

    if sys.version_info < (3, 10):
        out("")
        out(f"[ผิดพลาด] Python เก่าเกินไป (พบ {sys.version.split()[0]}) ต้องใช้ 3.10 ขึ้นไป")
        out("          ดาวน์โหลดที่ https://www.python.org/downloads/")
        return 1
    out(f"  Python {sys.version.split()[0]}")

    # ---------------------------------------------------------- 1) venv
    step(1, TOTAL, "สภาพแวดล้อมเสมือน (.venv)")
    if venv_python().exists():
        out("    มีอยู่แล้ว ข้ามขั้นนี้")
    else:
        if VENV.exists():
            out("    พบ .venv ที่ไม่สมบูรณ์ ลบทิ้งแล้วสร้างใหม่")
            shutil.rmtree(VENV, ignore_errors=True)
        if run([sys.executable, "-m", "venv", str(VENV)]) != 0 or not venv_python().exists():
            out("")
            out("[ผิดพลาด] สร้าง .venv ไม่สำเร็จ")
            out("          ลองเปิด Command Prompt ในโฟลเดอร์นี้แล้วพิมพ์:  python -m venv .venv")
            return 1
        out("    สร้างเสร็จแล้ว")

    py = str(venv_python())
    run([py, "-m", "pip", "install", "--upgrade", "pip", "--quiet",
         "--disable-pip-version-check"], show=False)
    # แคชของ pip ที่เสียทำให้ขึ้น WARNING: Cache entry deserialization failed รัว ๆ
    run([py, "-m", "pip", "cache", "purge"], show=False)

    # ---------------------------------------------------------- 2) torch
    step(2, TOTAL, "PyTorch (ตัวประมวลผลของโมเดล)")
    cur = probe(py, "import torch;print(torch.__version__, torch.cuda.is_available())")
    if cur:
        ver, has_cuda = (cur.split() + ["False"])[:2]
        out(f"    ติดตั้งอยู่แล้ว: torch {ver} | ใช้การ์ดจอได้: {has_cuda}")
        if has_cuda == "True":
            out("    ใช้งานการ์ดจอได้อยู่แล้ว ข้ามขั้นนี้")
            gpu = None
        else:
            out("    ตอนนี้เป็นเวอร์ชันซีพียู (ช้ากว่าการ์ดจอ 10-30 เท่า)")
            gpu = ask_yes("    ต้องการเปลี่ยนไปใช้เวอร์ชันการ์ดจอ NVIDIA ไหม")
    else:
        out("    เครื่องนี้มีการ์ดจอ NVIDIA หรือไม่?")
        out("    มีการ์ดจอ = ประมวลผลเร็วกว่าซีพียูล้วนราว 10-30 เท่า")
        out("    (ถ้าไม่แน่ใจ ตอบ n ไปก่อนได้ แล้วค่อยรันไฟล์นี้ใหม่ทีหลัง)")
        gpu = ask_yes("    ตอบ")

    if gpu is not None:
        ok = False
        if gpu:
            out("    ไล่หาชุดติดตั้งการ์ดจอที่ตรงกับ Python รุ่นนี้")
            out("    (ไฟล์ใหญ่ราว 2-3 GB ใช้เวลาสักพัก)")
            for cu in CUDA_INDEXES:
                out(f"    -- ลอง {cu}")
                if run([py, "-m", "pip", "install", "torch", "torchvision",
                        "--index-url", PT + cu]) == 0:
                    out(f"    สำเร็จด้วย {cu}")
                    ok = True
                    break
            if not ok:
                out("    ไม่มีชุดการ์ดจอที่ตรงกับ Python รุ่นนี้ จะติดตั้งเวอร์ชันซีพียูแทน")
        if not ok:
            ok = run([py, "-m", "pip", "install", "torch", "torchvision",
                      "--index-url", PT + "cpu"]) == 0
        if not ok:
            ok = run([py, "-m", "pip", "install", "torch", "torchvision"]) == 0
        if not ok:
            out("")
            out("[ผิดพลาด] ติดตั้ง PyTorch ไม่สำเร็จ — มักเป็นเพราะเน็ตหลุดกลางทาง")
            out("          รันไฟล์นี้ใหม่อีกครั้งได้เลย")
            return 1

    # ---------------------------------------------------- 3) ไลบรารีที่เหลือ
    step(3, TOTAL, "ไลบรารีที่เหลือ")
    if run([py, "-m", "pip", "install", "-r", "requirements.txt"]) != 0:
        out("")
        out("[ผิดพลาด] ติดตั้งไลบรารีไม่สำเร็จ ลองรันไฟล์นี้ใหม่อีกครั้ง")
        return 1

    # ---------------------------------------------------------- 4) โมเดล
    step(4, TOTAL, "โมเดลตรวจจับ")
    (ROOT / "models").mkdir(exist_ok=True)
    model = ROOT / "models" / "yolo26s-seg.pt"
    if model.exists():
        out(f"    มีอยู่แล้ว: models/yolo26s-seg.pt ({model.stat().st_size/1e6:.1f} MB)")
    else:
        out("    ไม่พบโมเดล กำลังดาวน์โหลด yolo26s-seg.pt (22 MB)")
        run([py, "-c", "from ultralytics import YOLO; YOLO(r'%s')" % str(model)], show=False)
        if not model.exists():
            out("    [เตือน] ดาวน์โหลดไม่สำเร็จ — โปรแกรมจะลองใหม่ตอนใช้งานครั้งแรก "
                "หรือดาวน์โหลด yolo26s-seg.pt มาวางใน models\\ เอง")

    # --------------------------------------------------------- 5) ffmpeg
    step(5, TOTAL, "ffmpeg")
    ff = shutil.which("ffmpeg") or next(
        (str(p) for p in [ROOT / "ffmpeg" / "bin" / "ffmpeg.exe",
                          ROOT / "ffmpeg" / "ffmpeg.exe",
                          ROOT / "ffmpeg.exe"] if p.exists()), None)
    if ff:
        out(f"    พบแล้ว: {ff}")
    else:
        out("    [เตือน] ไม่พบ ffmpeg — จำเป็นสำหรับแปลงไฟล์กล้องและเรนเดอร์วิดีโอย่อ")
        out("            เปิด PowerShell แล้วพิมพ์:   winget install Gyan.FFmpeg")
        out("            แล้วปิด-เปิดหน้าต่างใหม่ จากนั้นรันไฟล์นี้อีกครั้ง")
        out("            หรือดาวน์โหลดจาก https://www.gyan.dev/ffmpeg/builds/")
        out("            แตกไฟล์มาไว้เป็น  ffmpeg\\bin\\ffmpeg.exe  ในโฟลเดอร์นี้")

    # ------------------------------------------------------ 6) ตรวจของจริง
    step(6, TOTAL, "ทดสอบว่าเรียกใช้ได้จริง")
    problems = []
    for mod, why in (("numpy", "คำนวณตัวเลข"), ("cv2", "อ่านและเขียนวิดีโอ"),
                     ("yaml", "อ่านไฟล์ตั้งค่า"), ("fastapi", "เว็บเซิร์ฟเวอร์"),
                     ("uvicorn", "เว็บเซิร์ฟเวอร์"), ("torch", "ตัวประมวลผลโมเดล"),
                     ("ultralytics", "ตรวจจับวัตถุ")):
        got = probe(py, f"import {mod};print('ok')")
        if got == "ok":
            out(f"    {mod:<13} ใช้ได้")
        else:
            problems.append((mod, why))
            out(f"    {mod:<13} เรียกใช้ไม่ได้  ({why})")

    cuda = probe(py, "import torch;print(torch.cuda.is_available(),"
                     "torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')")
    if cuda.startswith("True"):
        out(f"    การ์ดจอ       ใช้ได้: {cuda[5:].strip()}")
    elif cuda:
        out("    การ์ดจอ       ไม่ได้ใช้ — จะประมวลผลด้วยซีพียู (ช้ากว่ามาก)")

    if problems:
        out("")
        out(LINE)
        out("  ติดตั้งยังไม่ครบ")
        out(LINE)
        out("  ไลบรารีที่ยังใช้ไม่ได้: " + ", ".join(m for m, _ in problems))
        if sys.version_info >= (3, 14):
            out("")
            out(f"  สาเหตุที่เป็นไปได้มากที่สุด: Python {sys.version.split()[0]} ใหม่เกินไป")
            out("  ไลบรารีด้านภาพหลายตัวยังตามไม่ทัน Python รุ่นล่าสุด")
            out("  ทางแก้ที่ได้ผลแน่นอน:")
            out("    1. ติดตั้ง Python 3.12 เพิ่ม (ไม่ต้องลบตัวเดิม)")
            out("       https://www.python.org/downloads/release/python-3129/")
            out("       เลือก Windows installer (64-bit) และติ๊ก Add python.exe to PATH")
            out("    2. ลบโฟลเดอร์ .venv ในโฟลเดอร์นี้ทิ้ง")
            out("    3. เปิด Command Prompt ในโฟลเดอร์นี้ แล้วพิมพ์:")
            out("         py -3.12 tools\\setup.py")
        else:
            out("  ลองรันไฟล์นี้ใหม่อีกครั้ง ถ้ายังไม่หายให้ส่งข้อความนี้มาให้ดู")
        return 1

    out("")
    out(LINE)
    out("  ติดตั้งเสร็จเรียบร้อย")
    out("  ต่อไปให้ดับเบิลคลิกไฟล์  run.bat  เพื่อเปิดโปรแกรม")
    out(LINE)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        out("\nยกเลิกการติดตั้ง")
        sys.exit(1)
