#!/usr/bin/env python3
"""สร้างชุดโปรแกรม กล้องเทพ สำหรับแจกจ่าย (รันผ่าน build_exe.bat)

ต้องรันบน Windows ด้วย python ใน .venv ที่ติดตั้งครบแล้ว (setup_windows.bat)
เพราะ PyInstaller เก็บไลบรารีจากเครื่องที่สร้าง: สร้างบนเครื่องที่ติดตั้ง torch แบบ CUDA
ชุดโปรแกรมก็จะใช้การ์ดจอได้ (และมีขนาดใหญ่ ราว 3-5 GB)

ผลลัพธ์ใน dist/
  KlongThep/                        โฟลเดอร์โปรแกรมพร้อมใช้ (คัดลอกไปเครื่องไหนก็ได้)
  KlongThep-<รุ่น>-win64.zip        ไฟล์ zip สำหรับเอาขึ้นเว็บ
  KlongThep-<รุ่น>-setup.exe        ตัวติดตั้ง (ถ้าเครื่องมี Inno Setup 6)
  KlongThep-<รุ่น>-source.zip       ซอร์สโค้ด (ต้องแจกคู่กันตามสัญญาอนุญาต AGPL ของ ultralytics)
  KlongThep-update-<รุ่น>.zip       ไฟล์อัปเดตย่อย (ไม่กี่ร้อย KB) วางบนเว็บให้โปรแกรมเก่าอัปเดตตัวเอง
  klongthep.json                    ไฟล์ประกาศรุ่นสำหรับเว็บ — เติมลิงก์ Google Drive ของชุดเต็มแล้วอัปโหลด
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

from app.version import __version__, APP_NAME, APP_NAME_TH  # noqa: E402

DIST = ROOT / "dist"
OUT = DIST / APP_NAME
SOURCE_ITEMS = ["app", "tools", "cli.py", "launcher.py", "requirements.txt", "config.yaml",
                "klongthep.spec", "installer.iss", "README.md", "THIRD_PARTY.md",
                "run.bat", "run_web.bat", "setup_windows.bat", "build_exe.bat",
                "ประมวลผลทั้งโฟลเดอร์.bat", "สอนโมเดล.bat"]
# สิ่งที่ไฟล์อัปเดตย่อยเปลี่ยนได้ (ต้องตรงกับ ALLOWED_ROOTS ใน app/updater.py)
UPDATE_ITEMS = ["app", "tools", "cli.py", "launcher.py", "README.md", "THIRD_PARTY.md"]
SITE_BASE = "https://kaveek1-rgb.github.io"


def out(msg: str = "") -> None:
    print(msg, flush=True)


def run(cmd: list[str], **kw) -> int:
    out("  > " + " ".join(str(c) for c in cmd))
    return subprocess.call(cmd, **kw)


def need(mod: str, pip_name: str) -> None:
    try:
        __import__(mod)
        return
    except ImportError:
        out(f"  ติดตั้ง {pip_name} ...")
        if run([sys.executable, "-m", "pip", "install", pip_name]) != 0:
            raise SystemExit(f"ติดตั้ง {pip_name} ไม่สำเร็จ (ต้องต่ออินเทอร์เน็ต)")


def make_icon() -> Path | None:
    """สร้างไอคอนง่าย ๆ ถ้ายังไม่มี (วงกลมเลนส์บนพื้นน้ำเงิน) — เปลี่ยนเป็นของตัวเองได้ที่ app/web/icon.ico"""
    ico = ROOT / "app" / "web" / "icon.ico"
    if ico.exists():
        return ico
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    frames = []
    for size in (256, 128, 64, 48, 32, 16):
        im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        r = size * 0.18
        d.rounded_rectangle((0, 0, size - 1, size - 1), radius=r, fill=(22, 52, 96, 255))
        c = size / 2
        for k, col in ((0.36, (240, 244, 250, 255)), (0.27, (22, 52, 96, 255)),
                       (0.20, (66, 160, 255, 255)), (0.08, (240, 244, 250, 255))):
            rr = size * k
            d.ellipse((c - rr, c - rr, c + rr, c + rr), fill=col)
        frames.append(im)
    frames[0].save(ico, format="ICO", sizes=[(f.width, f.height) for f in frames])
    out(f"  สร้างไอคอน {ico.relative_to(ROOT)}")
    return ico


def write_version_info() -> None:
    """ข้อมูลรุ่นที่ Windows แสดงใน Properties ของไฟล์ .exe"""
    b = ROOT / "build"
    b.mkdir(exist_ok=True)
    parts = (__version__.split(".") + ["0", "0", "0", "0"])[:4]
    nums = ", ".join(p if p.isdigit() else "0" for p in parts)
    (b / "version_info.txt").write_text(f"""# UTF-8
VSVersionInfo(
  ffi=FixedFileInfo(filevers=({nums}), prodvers=({nums}), mask=0x3f, flags=0x0,
                    OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040904B0', [
      StringStruct('CompanyName', '{APP_NAME_TH}'),
      StringStruct('FileDescription', '{APP_NAME_TH} - ระบบวิเคราะห์ภาพวงจรปิด'),
      StringStruct('FileVersion', '{__version__}'),
      StringStruct('InternalName', '{APP_NAME}'),
      StringStruct('OriginalFilename', '{APP_NAME}.exe'),
      StringStruct('ProductName', '{APP_NAME_TH}'),
      StringStruct('ProductVersion', '{__version__}')])]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
""", encoding="utf-8")


def zip_dir(src: Path, dest: Path, arc_root: str) -> None:
    if dest.exists():
        dest.unlink()
    n = 0
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as z:
        for p in sorted(src.rglob("*")):
            if p.is_file():
                z.write(p, f"{arc_root}/{p.relative_to(src).as_posix()}")
                n += 1
    out(f"  {dest.name}: {n:,} ไฟล์, {dest.stat().st_size / 1048576:,.0f} MB")


def make_source_zip() -> Path:
    dest = DIST / f"{APP_NAME}-{__version__}-source.zip"
    if dest.exists():
        dest.unlink()
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for item in SOURCE_ITEMS:
            p = ROOT / item
            if not p.exists():
                continue
            if p.is_dir():
                for f in sorted(p.rglob("*")):
                    if f.is_file() and "__pycache__" not in f.parts and f.suffix != ".pyc":
                        z.write(f, f"{APP_NAME}-source/{f.relative_to(ROOT).as_posix()}")
            else:
                z.write(p, f"{APP_NAME}-source/{item}")
    out(f"  {dest.name}: {dest.stat().st_size / 1024:,.0f} KB")
    return dest


def make_update_zip() -> Path:
    dest = DIST / f"{APP_NAME}-update-{__version__}.zip"
    if dest.exists():
        dest.unlink()
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for item in UPDATE_ITEMS:
            p = ROOT / item
            if not p.exists():
                continue
            if p.is_dir():
                for f in sorted(p.rglob("*")):
                    if f.is_file() and "__pycache__" not in f.parts and f.suffix != ".pyc":
                        z.write(f, f.relative_to(ROOT).as_posix())
            else:
                z.write(p, item)
    out(f"  {dest.name}: {dest.stat().st_size / 1024:,.0f} KB")
    return dest


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_site_json(update_zip: Path, source_zip: Path, full_zip: Path | None) -> Path:
    """ไฟล์ประกาศรุ่นสำหรับวางบนเว็บ (เติม url ของชุดเต็มจาก Google Drive เอง)"""
    dest = DIST / "klongthep.json"
    old = {}
    for cand in (dest, ROOT / "เว็บ" / "klongthep.json"):
        try:
            old = json.loads(cand.read_text(encoding="utf-8"))
            break
        except Exception:  # noqa: BLE001
            continue
    data = {
        "version": __version__,
        "released": time.strftime("%Y-%m-%d"),
        "notes": old.get("notes") if old.get("version") == __version__ else "",
        "url": old.get("url") or "",
        "size": (full_zip.stat().st_size if full_zip and full_zip.exists() else old.get("size") or 0),
        "sha256": (sha256(full_zip) if full_zip and full_zip.exists() else old.get("sha256") or ""),
        "source": f"{SITE_BASE}/{source_zip.name}",
        "update_url": f"{SITE_BASE}/{update_zip.name}",
        "update_size": update_zip.stat().st_size,
        "update_sha256": sha256(update_zip),
    }
    dest.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    out(f"  {dest.name}: รุ่น {data['version']} · update_url={data['update_url']}")
    if not data["url"]:
        out("  [ต้องทำ] เติมลิงก์ Google Drive ของชุดเต็มในช่อง \"url\" ก่อนอัปโหลด klongthep.json ขึ้นเว็บ")
    return dest


def find_iscc() -> str | None:
    for cand in (os.environ.get("ISCC"),
                 r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe",
                 r"C:\Program Files\Inno Setup 6\ISCC.exe",
                 shutil.which("ISCC"), shutil.which("iscc")):
        if cand and Path(cand).exists():
            return cand
    return None


def main() -> int:
    t0 = time.time()
    out("=" * 60)
    out(f"  สร้างชุดโปรแกรม {APP_NAME_TH} รุ่น {__version__}")
    out("=" * 60)
    if os.name != "nt":
        out("  [เตือน] ไม่ได้รันบน Windows — ผลลัพธ์จะใช้บน Windows ไม่ได้ (ทดสอบสูตรได้เท่านั้น)")

    out("\n[1/6] ตรวจเครื่องมือ")
    need("PyInstaller", "pyinstaller>=6.0")
    need("webview", "pywebview>=5.0")
    try:
        import torch
        out(f"  torch {torch.__version__} | การ์ดจอ: {torch.cuda.is_available()}")
        if not torch.cuda.is_available():
            out("  [เตือน] torch ในเครื่องนี้ไม่ใช่รุ่น CUDA — ชุดโปรแกรมที่ได้จะใช้ซีพียูอย่างเดียว")
    except ImportError:
        raise SystemExit("ยังไม่ได้ติดตั้ง torch — รัน setup_windows.bat ก่อน")
    make_icon()
    write_version_info()

    out("\n[2/6] PyInstaller (ใช้เวลาหลายนาที และต้องมีที่ว่างในดิสก์ ~10 GB)")
    if OUT.exists():
        shutil.rmtree(OUT, ignore_errors=True)
    rc = run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean",
              "--log-level", "WARN", str(ROOT / "klongthep.spec")])
    if rc != 0 or not (OUT / f"{APP_NAME}.exe").exists() and not (OUT / APP_NAME).exists():
        raise SystemExit("PyInstaller ล้มเหลว ดูข้อความด้านบน")

    out("\n[3/6] คัดลอกไฟล์ที่ต้องอยู่ข้าง .exe")
    for item in ("config.yaml", "README.md", "THIRD_PARTY.md"):
        if (ROOT / item).exists():
            shutil.copy2(ROOT / item, OUT / item)
    (OUT / "models").mkdir(exist_ok=True)
    for m in (ROOT / "models").glob("*.pt"):
        shutil.copy2(m, OUT / "models" / m.name)
        out(f"  โมเดล {m.name}")
    if (ROOT / "ffmpeg").exists():
        shutil.copytree(ROOT / "ffmpeg", OUT / "ffmpeg", dirs_exist_ok=True)
        out("  รวม ffmpeg จากโฟลเดอร์โปรเจกต์")
    elif shutil.which("ffmpeg"):
        # ffmpeg ที่ติดตั้งไว้ในเครื่อง (winget) — คัดลอกมาให้ชุดโปรแกรมพึ่งตัวเองได้
        (OUT / "ffmpeg" / "bin").mkdir(parents=True, exist_ok=True)
        for tool in ("ffmpeg", "ffprobe"):
            p = shutil.which(tool)
            if p:
                shutil.copy2(p, OUT / "ffmpeg" / "bin" / Path(p).name)
                out(f"  รวม {Path(p).name} จาก {p}")
    else:
        out("  [หมายเหตุ] ไม่พบ ffmpeg — เครื่องปลายทางต้องติดตั้ง ffmpeg เอง"
            " (วาง ffmpeg\\bin\\ffmpeg.exe ข้าง KlongThep.exe ก็ได้)")
    (OUT / "data").mkdir(exist_ok=True)
    (OUT / "data" / "อ่านก่อน.txt").write_text(
        "โฟลเดอร์นี้เก็บฐานข้อมูลและผลการวิเคราะห์ทั้งหมด\n"
        "ย้ายโปรแกรมไปเครื่องอื่น = คัดลอกทั้งโฟลเดอร์ KlongThep รวม data ไปด้วย\n", encoding="utf-8")

    out("\n[4/6] ซอร์สโค้ด (แจกคู่กับโปรแกรมตามเงื่อนไข AGPL-3.0 ของ ultralytics)")
    DIST.mkdir(exist_ok=True)
    src_zip = make_source_zip()
    shutil.copy2(src_zip, OUT / src_zip.name)

    out("\n[5/6] บีบอัดเป็น zip + ไฟล์อัปเดตย่อย + ไฟล์ประกาศรุ่น")
    full_zip = DIST / f"{APP_NAME}-{__version__}-win64.zip"
    zip_dir(OUT, full_zip, APP_NAME)
    upd = make_update_zip()
    write_site_json(upd, src_zip, full_zip)

    out("\n[6/6] ตัวติดตั้ง (Inno Setup)")
    iscc = find_iscc()
    if iscc and (ROOT / "installer.iss").exists():
        rc = run([iscc, f"/DMyAppVersion={__version__}", f"/DSourceDir={OUT}",
                  f"/DOutputDir={DIST}", str(ROOT / "installer.iss")])
        if rc == 0:
            out(f"  ได้ {APP_NAME}-{__version__}-setup.exe")
        else:
            out("  [เตือน] Inno Setup ล้มเหลว — ยังใช้ไฟล์ zip แจกได้")
    else:
        out("  ไม่พบ Inno Setup 6 (ติดตั้งฟรีจาก https://jrsoftware.org/isdl.php) — ข้ามการสร้าง setup.exe")

    total = sum(p.stat().st_size for p in OUT.rglob("*") if p.is_file())
    out("\n" + "=" * 60)
    out(f"  เสร็จใน {(time.time() - t0) / 60:.1f} นาที")
    out(f"  โฟลเดอร์โปรแกรม : {OUT}  ({total / 1073741824:.2f} GB)")
    for p in sorted(DIST.glob(f"{APP_NAME}-{__version__}-*")):
        out(f"  {p.name:<40} {p.stat().st_size / 1048576:,.0f} MB")
    out("=" * 60)
    out("ทดสอบก่อนแจก: ดับเบิลคลิก dist\\KlongThep\\KlongThep.exe บนเครื่องที่ไม่ได้ติดตั้ง Python")
    out("ขึ้นเว็บ: อัปโหลด KlongThep-update-*.zip, KlongThep-*-source.zip และ klongthep.json (เติม url ก่อน) ขึ้น GitHub Pages")
    out("         ชุดเต็ม win64.zip อัปโหลด Google Drive แล้วเอาลิงก์มาใส่ url ใน klongthep.json")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit as exc:
        if exc.code not in (None, 0):
            out(f"\n[ผิดพลาด] {exc.code}")
        raise
