#!/usr/bin/env python3
"""ติดตั้ง/ซ่อม PyTorch เวอร์ชันการ์ดจอ NVIDIA โดยเฉพาะ

ทำสามอย่างตามลำดับ
  1. ตรวจว่าเครื่องมีการ์ดจอ NVIDIA และไดรเวอร์จริงหรือไม่
  2. ไล่ถามเซิร์ฟเวอร์ PyTorch ว่ามีชุดติดตั้งที่ตรงกับ Python รุ่นนี้ไหม (ไม่โหลดจริง เร็ว)
  3. ถ้าไม่มี จะหา Python รุ่นอื่นในเครื่องแล้วเสนอสร้าง .venv ใหม่ด้วยรุ่นนั้นให้เลย
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENV = ROOT / ".venv"
LINE = "=" * 60
PT = "https://download.pytorch.org/whl/"
CUDA_INDEXES = ["cu130", "cu129", "cu128", "cu126", "cu124", "cu121"]
GOOD_PY = [(3, 13), (3, 12), (3, 11), (3, 10)]   # รุ่นที่ไลบรารีรองรับครบแน่ ๆ

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def out(s: str = "") -> None:
    print(s, flush=True)


def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def run(cmd: list, show: bool = True) -> int:
    if show:
        out("    $ " + " ".join(str(c) for c in cmd[2:]))
    try:
        return subprocess.run(cmd, cwd=str(ROOT)).returncode
    except FileNotFoundError:
        return 1


def quiet(cmd: list, timeout: int = 240) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=str(ROOT))
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as exc:  # noqa: BLE001
        return 1, str(exc)


def ask_yes(q: str) -> bool:
    while True:
        try:
            a = input(q + "  [y=ใช่ / n=ไม่ใช่]: ").strip().lower()
        except EOFError:
            return False
        if a in ("y", "yes", "ใช่"):
            return True
        if a in ("n", "no", "ไม่"):
            return False


def find_other_pythons() -> list[tuple[tuple[int, int], str]]:
    """หา Python รุ่นอื่นที่ติดตั้งไว้ในเครื่อง ผ่านตัวจัดการ py launcher"""
    found: dict[tuple[int, int], str] = {}
    code, txt = quiet(["py", "-0p"], timeout=30)
    if code == 0:
        for line in txt.splitlines():
            m = re.search(r"-V:(\d+)\.(\d+)(\S*)\s+\*?\s*(\S.*\.exe)", line)
            # ข้ามรุ่น free-threaded (ลงท้ายด้วย t) เพราะไลบรารีหลายตัวยังไม่รองรับ
            if m and not m.group(3).lstrip("-").startswith("t"):
                found.setdefault((int(m.group(1)), int(m.group(2))), m.group(4).strip())
    for ver in GOOD_PY:
        if ver in found:
            continue
        for base in (os.environ.get("LOCALAPPDATA", ""), "C:\\"):
            if not base:
                continue
            for pat in (f"Programs/Python/Python{ver[0]}{ver[1]}/python.exe",
                        f"Python{ver[0]}{ver[1]}/python.exe"):
                p = Path(base) / pat
                if p.exists():
                    found.setdefault(ver, str(p))
    return [(v, p) for v, p in sorted(found.items(), reverse=True) if v in GOOD_PY]


def main() -> int:
    out(LINE)
    out("  กล้องเทพ — ติดตั้งเวอร์ชันการ์ดจอ NVIDIA")
    out(LINE)

    py = str(venv_python())
    if not venv_python().exists():
        out("")
        out("[ผิดพลาด] ยังไม่ได้ติดตั้ง — ให้ดับเบิลคลิก setup_windows.bat ก่อน")
        return 1

    pyver = quiet([py, "-c", "import sys;print('%d.%d'%sys.version_info[:2])"])[1].strip()
    out(f"  Python ที่โปรแกรมใช้อยู่: {pyver}")

    # ------------------------------------------------- 1) มีการ์ดจอจริงไหม
    out("")
    out("[1/3] ตรวจการ์ดจอในเครื่อง")
    code, txt = quiet(["nvidia-smi", "--query-gpu=name,driver_version",
                       "--format=csv,noheader"], timeout=60)
    if code == 0 and txt.strip():
        out(f"    พบการ์ดจอ NVIDIA: {txt.strip().splitlines()[0]}")
    else:
        out("    ไม่พบคำสั่ง nvidia-smi")
        out("")
        out("    แปลว่าอย่างใดอย่างหนึ่ง:")
        out("      ก) เครื่องนี้ไม่มีการ์ดจอ NVIDIA (เช่นใช้การ์ดจอในตัวของ Intel/AMD)")
        out("      ข) มีการ์ดจอแต่ยังไม่ได้ลงไดรเวอร์ NVIDIA")
        out("")
        out("    วิธีเช็กเอง: กด Ctrl+Shift+Esc เปิด Task Manager -> แท็บ Performance")
        out("                 ดูว่ามี GPU ที่ชื่อขึ้นต้นด้วย NVIDIA หรือไม่")
        out("    ถ้าไม่มีการ์ด NVIDIA จริง ๆ ให้ใช้โหมดซีพียูต่อไปได้เลย ระบบทำงานได้ปกติ")
        out("    แค่ประมวลผลช้ากว่า — ชดเชยได้โดยแก้ config.yaml ให้ stride: 5 และ imgsz: 640")
        out("")
        if not ask_yes("    จะลองติดตั้งชุดการ์ดจอต่อไปไหม"):
            return 0

    cur = quiet([py, "-c", "import torch;print(torch.__version__, torch.cuda.is_available())"])[1].strip()
    out(f"    torch ตอนนี้: {cur or 'ยังไม่ได้ติดตั้ง'}")
    if cur.endswith("True"):
        out("    ใช้การ์ดจอได้อยู่แล้ว ไม่ต้องทำอะไรเพิ่ม")
        return 0

    # --------------------------------------- 2) มีชุดติดตั้งตรงรุ่นนี้ไหม
    out("")
    out(f"[2/3] ถามเซิร์ฟเวอร์ PyTorch ว่ามีชุดสำหรับ Python {pyver} ไหม (ยังไม่โหลดจริง)")
    usable = []
    for cu in CUDA_INDEXES:
        code, _ = quiet([py, "-m", "pip", "install", "--dry-run", "--no-deps",
                         "--quiet", "torch", "--index-url", PT + cu], timeout=300)
        mark = "มี" if code == 0 else "ไม่มี"
        out(f"    {cu:<7} {mark}")
        if code == 0:
            usable.append(cu)

    if usable:
        cu = usable[0]
        out("")
        out(f"[3/3] ติดตั้งด้วย {cu} (ไฟล์ใหญ่ราว 2-3 GB ใช้เวลาสักพัก)")
        if run([py, "-m", "pip", "install", "torch", "torchvision",
                "--index-url", PT + cu]) != 0:
            out("")
            out("[ผิดพลาด] ติดตั้งไม่สำเร็จ — มักเป็นเพราะเน็ตหลุด รันไฟล์นี้ใหม่ได้เลย")
            return 1
        res = quiet([py, "-c", "import torch;print(torch.cuda.is_available(),"
                              "torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')"])[1].strip()
        out("")
        out(LINE)
        if res.startswith("True"):
            out(f"  สำเร็จ — ใช้การ์ดจอได้แล้ว: {res[5:].strip()}")
            out("  เปิด run.bat ได้เลย มุมขวาบนจะขึ้นชื่อการ์ดจอแทนคำว่า 'ไม่พบการ์ดจอ'")
        else:
            out("  ติดตั้งแล้วแต่ยังเรียกใช้การ์ดจอไม่ได้")
            out("  มักเป็นเพราะไดรเวอร์ NVIDIA เก่าเกินไป — อัปเดตที่ nvidia.com/download")
        out(LINE)
        return 0

    # ------------------------------- 3) ไม่มีเลย -> หา Python รุ่นอื่นให้
    out("")
    out(f"    ไม่มีชุดการ์ดจอสำหรับ Python {pyver} เลยสักตัว")
    out(f"    Python {pyver} ใหม่เกินไป PyTorch ยังทำชุด CUDA ไม่ทัน")
    out("")
    out("[3/3] หา Python รุ่นอื่นในเครื่อง")
    others = find_other_pythons()
    if others:
        ver, path = others[0]
        out(f"    พบ Python {ver[0]}.{ver[1]} ที่ {path}")
        out("    สร้าง .venv ใหม่ด้วยรุ่นนี้แล้วติดตั้งทั้งหมดอีกครั้งได้เลย")
        out("    (ข้อมูลที่ประมวลผลไว้แล้วในโฟลเดอร์ data จะไม่หาย)")
        out("")
        if ask_yes("    ทำเลยไหม"):
            out("    ลบ .venv เดิม")
            shutil.rmtree(VENV, ignore_errors=True)
            return run([path, str(ROOT / "tools" / "setup.py")], show=False)
        return 0

    out("    ไม่พบ Python รุ่นอื่นในเครื่อง")
    out("")
    out(LINE)
    out("  ทางแก้ที่ได้ผลแน่นอน")
    out(LINE)
    out("  1. ลง Python 3.12 เพิ่ม (ไม่ต้องลบตัวเดิม ใช้ร่วมกันได้)")
    out("     https://www.python.org/downloads/release/python-3129/")
    out("     เลื่อนลงล่างสุด เลือก 'Windows installer (64-bit)'")
    out("     ตอนติดตั้งติ๊ก 'Add python.exe to PATH' ด้วย")
    out("  2. กลับมาดับเบิลคลิกไฟล์นี้อีกครั้ง มันจะจัดการที่เหลือให้เอง")
    out(LINE)
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        out("\nยกเลิก")
        sys.exit(1)
