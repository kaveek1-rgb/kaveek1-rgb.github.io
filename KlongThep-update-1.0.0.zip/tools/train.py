#!/usr/bin/env python3
"""สอนโมเดลด้วยภาพจากกล้องของหน่วยงานเอง

ใช้ภาพที่ติดป้ายไว้ในหน้า "สอนโมเดล" มาฝึกต่อยอดจากโมเดลสำเร็จรูป
ผลลัพธ์เป็นไฟล์ models/custom.pt ซึ่งเอาไปใส่ใน config.yaml ได้เลย

  python tools/train.py                 ฝึกด้วยค่าเริ่มต้น (100 รอบ)
  python tools/train.py --epochs 200    ฝึกนานขึ้น แม่นขึ้น ใช้เวลามากขึ้น
  python tools/train.py --base yolov8m.pt
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from app import config, dataset  # noqa: E402

LINE = "=" * 60


def out(s: str = "") -> None:
    print(s, flush=True)


def main() -> int:
    ap = argparse.ArgumentParser(description="สอนโมเดลด้วยภาพจากกล้องของหน่วยงาน")
    ap.add_argument("--epochs", type=int, default=100, help="จำนวนรอบการฝึก")
    ap.add_argument("--imgsz", type=int, default=None, help="ขนาดภาพ (ไม่ใส่ = ตามค่าใน config)")
    ap.add_argument("--base", default="yolov8s.pt",
                    help="โมเดลตั้งต้น (ใช้รุ่นตรวจจับธรรมดา ไม่ใช่ -seg เพราะป้ายเป็นกรอบสี่เหลี่ยม)")
    ap.add_argument("--batch", type=int, default=-1, help="ขนาดชุดต่อรอบ (-1 = ให้ระบบเลือกเอง)")
    ap.add_argument("--name", default="custom", help="ชื่อไฟล์โมเดลผลลัพธ์ใน models/")
    a = ap.parse_args()

    cfg = config.load()
    st = dataset.stats()

    out(LINE)
    out("  กล้องเทพ — สอนโมเดลด้วยภาพของหน่วยงานเอง")
    out(LINE)
    out(f"  ภาพที่ติดป้ายเสร็จแล้ว : {st['done']:,} ภาพ  ({st['boxes']:,} กรอบ)")
    out(f"  ยังรอติดป้าย           : {st['pending']:,} ภาพ")

    if st["done"] < 30:
        out("")
        out("[หยุด] ภาพน้อยเกินไป ต้องมีอย่างน้อย 30 ภาพจึงจะเริ่มฝึกได้")
        out("       และควรมี 300 ภาพขึ้นไปจึงจะเห็นผลชัด")
        out("       เปิดโปรแกรมแล้วไปที่แท็บ 'สอนโมเดล' เพื่อติดป้ายเพิ่ม")
        return 1
    if st["done"] < 100:
        out("")
        out(f"  [เตือน] มี {st['done']} ภาพ ซึ่งยังน้อย ผลอาจดีขึ้นไม่มาก")
        out("          แนะนำ 300 ภาพขึ้นไป และควรมีทั้งกลางวัน กลางคืน และวันฝนตก")

    out("")
    out("[1/3] จัดชุดข้อมูล")
    ex = dataset.export(cfg)
    if not ex.get("ok"):
        out(f"[ผิดพลาด] {ex.get('reason')}")
        return 1
    out(f"    ฝึก {ex['train']} ภาพ | ตรวจสอบ {ex['val']} ภาพ")
    out(f"    ประเภทวัตถุ: {', '.join(ex['classes'])}")

    imgsz = a.imgsz or int(cfg["detector"].get("imgsz", 1536))
    out("")
    out(f"[2/3] ฝึกโมเดล — ตั้งต้นจาก {a.base}, {a.epochs} รอบ, ขนาดภาพ {imgsz}")
    out("    ขั้นนี้ใช้เวลานาน เปิดทิ้งไว้ได้ ปิดหน้าต่างนี้จะเป็นการยกเลิก")
    out("")

    try:
        from ultralytics import YOLO
        from ultralytics import settings as ul_settings
        try:
            if ul_settings.get("sync", True):
                ul_settings.update({"sync": False})
        except Exception:  # noqa: BLE001
            pass
    except ImportError:
        out("[ผิดพลาด] ไม่พบ ultralytics — รัน setup_windows.bat ก่อน")
        return 1

    model = YOLO(a.base)
    try:
        model.train(
            data=ex["data_yaml"],
            epochs=int(a.epochs),
            imgsz=imgsz,
            batch=a.batch,
            project=str(config.DATA / "training"),
            name=a.name,
            exist_ok=True,
            patience=30,
            # ภาพจากกล้องนิ่งเป็นมุมเดิมตลอด จึงไม่ควรพลิกซ้ายขวาหรือหมุนแรง
            # แต่ควรเพิ่มความหลากหลายของแสงเพราะกล้องเจอทั้งเช้า กลางวัน และกลางคืน
            fliplr=0.0, degrees=0.0, perspective=0.0,
            hsv_h=0.015, hsv_s=0.6, hsv_v=0.5,
            verbose=True,
        )
    except Exception as exc:  # noqa: BLE001
        out("")
        out(f"[ผิดพลาด] ฝึกไม่สำเร็จ: {type(exc).__name__}: {exc}")
        out("  ถ้าเป็นเรื่องหน่วยความจำการ์ดจอไม่พอ ให้ลอง:")
        out(f"     python tools/train.py --imgsz 960 --batch 4")
        return 1

    best = config.DATA / "training" / a.name / "weights" / "best.pt"
    if not best.exists():
        out(f"[ผิดพลาด] ไม่พบไฟล์ผลลัพธ์ที่ {best}")
        return 1

    dest = config.DIR_MODELS / f"{a.name}.pt"
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(best, dest)

    out("")
    out(LINE)
    out("[3/3] เสร็จแล้ว")
    out(LINE)
    out(f"  โมเดลใหม่: models/{a.name}.pt")
    out("")
    out("  วิธีเอาไปใช้ — แก้ config.yaml สองบรรทัด:")
    out(f"      model: models/{a.name}.pt")
    out("      mask_model: models/yolov8s-seg.pt")
    out("")
    out("  บรรทัดที่สองทำให้วิดีโอย่อยังตัดวัตถุตามรูปทรงจริงได้")
    out("  (โมเดลที่เพิ่งฝึกเป็นรุ่นตรวจจับกรอบ ไม่มีรูปทรง)")
    out("")
    out("  จากนั้นสั่งประมวลผลวิดีโอเดิมใหม่ แล้วเทียบดูว่าเจอวัตถุมากขึ้นแค่ไหน")
    out(f"  กราฟผลการฝึกดูได้ที่ {config.DATA / 'training' / a.name}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        out("\nยกเลิกการฝึก")
        sys.exit(1)
