"""สร้างวิดีโอทดสอบสังเคราะห์ - ใช้ตรวจว่าระบบทำงานครบวงจรหรือไม่

วัตถุแต่ละตัวปรากฏคนละช่วงเวลา ไม่มีตัวไหนอยู่พร้อมกันเลย
ถ้าวิดีโอย่อทำงานถูกต้อง ผลลัพธ์จะเห็นทุกตัวพร้อมกันและสั้นกว่าต้นฉบับหลายเท่า

  python tools/make_test_video.py data/test.mp4
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np

W, H, FPS, SECONDS = 640, 360, 25, 60


def background() -> np.ndarray:
    bg = np.zeros((H, W, 3), np.uint8)
    bg[:, :] = (58, 64, 60)
    bg[H // 2:, :] = (72, 74, 78)                       # ถนน
    cv2.rectangle(bg, (0, H // 2 - 8), (W, H // 2), (96, 104, 92), -1)
    for x in range(20, W, 90):                          # เส้นแบ่งเลน
        cv2.rectangle(bg, (x, H - 60), (x + 45, H - 55), (170, 172, 175), -1)
    for x in (70, 300, 520):                            # ต้นไม้
        cv2.circle(bg, (x, H // 2 - 34), 22, (48, 92, 56), -1)
        cv2.rectangle(bg, (x - 4, H // 2 - 22), (x + 4, H // 2), (52, 62, 84), -1)
    noise = np.random.default_rng(7).normal(0, 3, bg.shape)
    return np.clip(bg.astype(np.float32) + noise, 0, 255).astype(np.uint8)


OBJECTS = [
    # (เริ่มวินาที, ยาววินาที, สี BGR, กว้าง, สูง, y, ทิศทาง)
    (3,  7, (40, 40, 200), 22, 52, 250, +1),
    (14, 6, (200, 150, 40), 60, 34, 285, -1),
    (24, 8, (60, 190, 90), 20, 48, 235, +1),
    (36, 5, (200, 80, 200), 44, 30, 300, -1),
    (46, 9, (40, 190, 220), 24, 56, 265, +1),
    (50, 6, (220, 220, 220), 18, 46, 240, -1),
]


def main() -> None:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "data/test.mp4")
    out.parent.mkdir(parents=True, exist_ok=True)
    raw = out.with_suffix(".raw.avi")

    bg = background()
    vw = cv2.VideoWriter(str(raw), cv2.VideoWriter_fourcc(*"MJPG"), FPS, (W, H))
    total = FPS * SECONDS
    for f in range(total):
        frame = bg.copy()
        t = f / FPS
        for (t0, dur, col, w, h, y, d) in OBJECTS:
            if not (t0 <= t < t0 + dur):
                continue
            p = (t - t0) / dur
            x = int((W + 80) * p) - 60 if d > 0 else int(W - (W + 80) * p) - 20
            cv2.rectangle(frame, (x, y - h), (x + w, y), col, -1)
            cv2.circle(frame, (x + w // 2, y - h - 6), max(5, w // 4),
                       tuple(int(c * 0.75) for c in col), -1)
        vw.write(frame)
    vw.release()

    try:
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw),
                        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
                        "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out)], check=True)
        raw.unlink()
    except Exception:  # noqa: BLE001
        out = raw
    print(f"สร้างวิดีโอทดสอบแล้ว: {out}  ({SECONDS} วินาที, วัตถุ {len(OBJECTS)} ตัว คนละช่วงเวลา)")


if __name__ == "__main__":
    main()
